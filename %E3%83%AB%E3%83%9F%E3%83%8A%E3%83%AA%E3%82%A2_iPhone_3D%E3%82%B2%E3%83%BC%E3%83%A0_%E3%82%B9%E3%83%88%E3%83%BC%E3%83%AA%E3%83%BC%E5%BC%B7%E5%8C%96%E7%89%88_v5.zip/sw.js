const CACHE='lumoria-iphone-3d-story-v5';
const CORE=["./","./index.html","./style.css","./game.js","./manifest.webmanifest","./icon-180.png","./icon-192.png","./icon-512.png","./assets/audio/boss.m4a","./assets/audio/capture.m4a","./assets/audio/catch_fail.m4a","./assets/audio/chest.m4a","./assets/audio/dodge.m4a","./assets/audio/evolution.m4a","./assets/audio/exploration.m4a","./assets/audio/impact.m4a","./assets/audio/level_up.m4a","./assets/audio/pickup.m4a","./assets/audio/skill.m4a","./assets/audio/swing.m4a","./assets/audio/ui.m4a","./assets/meshes/fire_ascended.bin","./assets/meshes/fire_young.bin","./assets/meshes/forest_ascended.bin","./assets/meshes/forest_young.bin","./assets/meshes/hero_arm_l.bin","./assets/meshes/hero_arm_r.bin","./assets/meshes/hero_body.bin","./assets/meshes/hero_leg_l.bin","./assets/meshes/hero_leg_r.bin","./assets/meshes/storm_ascended.bin","./assets/meshes/storm_young.bin","./assets/meshes/water_ascended.bin","./assets/meshes/water_young.bin","./assets/portraits/fire_ascended.webp","./assets/portraits/fire_young.webp","./assets/portraits/forest_ascended.webp","./assets/portraits/forest_young.webp","./assets/portraits/hero.webp","./assets/portraits/storm_ascended.webp","./assets/portraits/storm_young.webp","./assets/portraits/water_ascended.webp","./assets/portraits/water_young.webp","./assets/cinematics/04_bond.webp","./assets/cinematics/03_oath.webp","./assets/cinematics/02_oblivion.webp","./assets/cinematics/01_starlight.webp","./assets/cinematics/prologue.mp4","./assets/cinematics/01_starlight.webp","./assets/cinematics/02_oblivion.webp","./assets/cinematics/03_oath.webp","./assets/cinematics/04_bond.webp","./assets/cinematics/prologue.mp4"];
self.addEventListener('install', event=>{event.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',event=>{
 const req=event.request;
 if(req.method!=='GET'||new URL(req.url).origin!==self.location.origin)return;
 // iOS Safari may issue Range requests when seeking through the 19-second intro video.
 // Respond with genuine 206 data sliced from the cached complete MP4 so seeking works offline.
 if(req.headers.has('range')&&new URL(req.url).pathname.endsWith('/assets/cinematics/prologue.mp4')){
  event.respondWith((async()=>{
   const full=await caches.match(req.url,{ignoreSearch:true});
   if(!full)return fetch(req);
   const data=await full.arrayBuffer(),length=data.byteLength;
   const match=/bytes=(\d+)-(\d*)/.exec(req.headers.get('range'));
   if(!match)return full;
   const first=Number(match[1]);const last=match[2]?Math.min(length-1,Number(match[2])):length-1;
   if(!Number.isSafeInteger(first)||first>=length||last<first)return new Response(null,{status:416,headers:{'Content-Range':'bytes */'+length}});
   return new Response(data.slice(first,last+1),{status:206,headers:{'Content-Type':'video/mp4','Accept-Ranges':'bytes','Content-Range':`bytes ${first}-${last}/${length}`,'Content-Length':String(last-first+1)}});
  })());return;
 }
 event.respondWith(req.mode==='navigate'?
  fetch(req).then(r=>{if(r.ok){const clone=r.clone();caches.open(CACHE).then(c=>c.put(req,clone)).catch(()=>{})}return r}).catch(()=>caches.match(req)):
  caches.match(req).then(hit=>hit||fetch(req).then(r=>{if(r.ok&&r.status===200){const clone=r.clone();caches.open(CACHE).then(c=>c.put(req,clone)).catch(()=>{})}return r})));
});
