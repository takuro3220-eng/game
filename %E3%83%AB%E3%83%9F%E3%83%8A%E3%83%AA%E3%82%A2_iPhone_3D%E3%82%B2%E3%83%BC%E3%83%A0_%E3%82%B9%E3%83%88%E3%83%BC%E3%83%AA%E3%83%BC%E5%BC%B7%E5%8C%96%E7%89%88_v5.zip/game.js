/* LUMORIA — a self-contained, original WebGL creature RPG. No external runtime libraries. */
(()=>{'use strict';
const $=id=>document.getElementById(id), canvas=$('scene'), gl=canvas.getContext('webgl',{antialias:true,alpha:false,depth:true,preserveDrawingBuffer:false,powerPreference:'high-performance'});
if(!gl){$('splash').querySelector('.splash-content').innerHTML='<h2>WebGLに対応していません</h2><p>最新のSafariで開き直してください。</p>';return;}
const VSH=`attribute vec3 a_pos;attribute vec3 a_norm;attribute vec3 a_col;uniform mat4 u_projection,u_view,u_model;uniform vec3 u_tint;varying vec3 v_col;varying float v_fog;varying float v_light;varying float v_rim;varying float v_height;void main(){vec4 world=u_model*vec4(a_pos,1.);vec4 v=u_view*world;gl_Position=u_projection*v;v_fog=clamp((-v.z-25.)/100.,0.,1.);vec3 n=normalize(mat3(u_model)*a_norm);v_light=.61+.40*max(0.,dot(n,normalize(vec3(.53,.82,.36))));v_height=world.y;vec3 eye=normalize(-v.xyz);vec3 vn=normalize(mat3(u_view)*n);v_rim=pow(1.-clamp(dot(eye,vn),0.,1.),2.0);v_col=a_col*u_tint;}`;
const FSH=`precision mediump float;varying vec3 v_col;varying float v_fog;varying float v_light;varying float v_rim;varying float v_height;uniform vec3 u_fog_color;uniform float u_day;void main(){vec3 color=v_col*v_light*(.81+.19*u_day);color+=v_col*v_rim*.14;float glow=clamp(v_col.b-v_col.r*.7,.0,.6);color+=vec3(.22,.24,.45)*glow*.08;color=mix(color,u_fog_color,smoothstep(0.,1.,v_fog)*.91);gl_FragColor=vec4(pow(max(color,vec3(.002)),vec3(.88)),1.);}`;
function shader(type,source){const s=gl.createShader(type);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s;}
const prog=gl.createProgram();gl.attachShader(prog,shader(gl.VERTEX_SHADER,VSH));gl.attachShader(prog,shader(gl.FRAGMENT_SHADER,FSH));gl.linkProgram(prog);if(!gl.getProgramParameter(prog,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(prog));gl.useProgram(prog);
const loc={pos:gl.getAttribLocation(prog,'a_pos'),norm:gl.getAttribLocation(prog,'a_norm'),col:gl.getAttribLocation(prog,'a_col'),view:gl.getUniformLocation(prog,'u_view'),proj:gl.getUniformLocation(prog,'u_projection'),fog:gl.getUniformLocation(prog,'u_fog_color'),day:gl.getUniformLocation(prog,'u_day'),model:gl.getUniformLocation(prog,'u_model'),tint:gl.getUniformLocation(prog,'u_tint')};
gl.enableVertexAttribArray(loc.pos);gl.enableVertexAttribArray(loc.norm);gl.enableVertexAttribArray(loc.col);gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.disable(gl.CULL_FACE);
// CINEMATIC SKY: hand-written WebGL1 shader. No textures, no network, no external runtime.
const SKY_VSH=`attribute vec2 a_sky;varying vec2 v_uv;void main(){v_uv=a_sky*.5+.5;gl_Position=vec4(a_sky,1.,1.);}`;
const SKY_FSH=`precision mediump float;varying vec2 v_uv;uniform float u_clock;uniform float u_sun;uniform float u_mist;float hs(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}float field(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hs(i),hs(i+vec2(1.,0.)),f.x),mix(hs(i+vec2(0.,1.)),hs(i+1.),f.x),f.y);}void main(){float y=v_uv.y;float light=clamp(.34+.69*u_sun,0.,1.);vec3 horizon=mix(vec3(.16,.18,.38),vec3(.88,.70,.56),light);vec3 zenith=mix(vec3(.015,.035,.11),vec3(.20,.50,.78),light);vec3 col=mix(horizon,zenith,smoothstep(.12,1.,y));float haze=1.-smoothstep(.10,.53,y);col=mix(col,vec3(.56,.69,.77)*light+.10,haze*.20+u_mist*.06);vec2 cloudP=v_uv*vec2(5.,6.)+vec2(u_clock*.0013,0.);float cloud=field(cloudP)+.46*field(cloudP*2.1)-.82;cloud=smoothstep(.08,.46,cloud)*smoothstep(.20,.53,y)*(1.-smoothstep(.75,.96,y));col=mix(col,mix(vec3(.36,.47,.57),vec3(1.,.96,.83),light),cloud*(.27+.40*light));vec2 sunpos=vec2(.78,.62+.14*u_sun);float sd=distance(v_uv,sunpos*vec2(1.,.82));float glow=exp(-sd*sd*31.)*light;col+=vec3(.72,.53,.34)*glow*.44;col+=vec3(1.,.88,.59)*(1.-smoothstep(.022,.031,sd))*light*.68;float stars=step(.9968,hs(floor(v_uv*vec2(270.,140.))))*smoothstep(.44,.90,y)*(1.-light);col+=vec3(.75,.88,1.)*stars*.86;gl_FragColor=vec4(col,1.);}`;
const skyProg=gl.createProgram();gl.attachShader(skyProg,shader(gl.VERTEX_SHADER,SKY_VSH));gl.attachShader(skyProg,shader(gl.FRAGMENT_SHADER,SKY_FSH));gl.linkProgram(skyProg);if(!gl.getProgramParameter(skyProg,gl.LINK_STATUS))throw Error('Sky shader: '+gl.getProgramInfoLog(skyProg));
const skyLoc={pos:gl.getAttribLocation(skyProg,'a_sky'),clock:gl.getUniformLocation(skyProg,'u_clock'),sun:gl.getUniformLocation(skyProg,'u_sun'),mist:gl.getUniformLocation(skyProg,'u_mist')};const skyBuffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,skyBuffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),gl.STATIC_DRAW);
function drawSky(sun,mist){gl.disable(gl.DEPTH_TEST);gl.useProgram(skyProg);gl.bindBuffer(gl.ARRAY_BUFFER,skyBuffer);gl.enableVertexAttribArray(skyLoc.pos);gl.vertexAttribPointer(skyLoc.pos,2,gl.FLOAT,false,0,0);gl.uniform1f(skyLoc.clock,gameTime);gl.uniform1f(skyLoc.sun,sun);gl.uniform1f(skyLoc.mist,mist);gl.drawArrays(gl.TRIANGLES,0,3);gl.enable(gl.DEPTH_TEST);gl.useProgram(prog);}

const SPECIES=[
{id:0,name:'モコル',evolved:'モコリオン',type:'森',emoji:'🌿',color:[.56,.84,.57],highlight:[.89,.96,.72],accent:[.33,.66,.45]},
{id:1,name:'フレノ',evolved:'フレナイト',type:'炎',emoji:'🔥',color:[.98,.53,.36],highlight:[1,.88,.55],accent:[.88,.28,.29]},
{id:2,name:'ミズリ',evolved:'ミズリア',type:'水',emoji:'💧',color:[.42,.76,.93],highlight:[.78,.96,1],accent:[.27,.53,.88]},
{id:3,name:'ピリカ',evolved:'ピリクシア',type:'雷',emoji:'⚡',color:[.77,.62,.97],highlight:[1,.91,.61],accent:[.57,.40,.82]}
];
const KEY='lumoria-save-v2'; // backwards-compatible with the earlier iPhone edition
const startState=()=>({x:0,z:3,yaw:0,lv:1,xp:0,hp:100,orbs:8,shards:15,party:[{id:0,level:2,xp:0,evolved:false,uid:1}],active:1,nextUid:2,caught:1,kills:0,distance:0,boss:false,evolutions:0,day:0.21,box:[],chests:[],waypoints:[0],audioEnabled:true,quality:'auto',questsDone:0,forageCount:0,trials:[],sideRewards:[],storySeen:[]});
let save=startState();try{let raw=JSON.parse(localStorage.getItem(KEY)||'null');if(raw&&Array.isArray(raw.party)&&Number.isFinite(raw.x)&&Number.isFinite(raw.z)){save={...save,...raw};save.party=save.party.filter(p=>p&&Number.isInteger(p.id)&&p.id>=0&&p.id<4&&Number.isFinite(p.level)&&p.level>0&&p.level<500&&Number.isFinite(p.uid)).slice(0,6);if(save.party.length===0)save.party=startState().party;save.box=Array.isArray(save.box)?save.box.filter(p=>p&&Number.isInteger(p.id)&&p.id>=0&&p.id<4&&Number.isFinite(p.uid)).slice(0,200):[];save.orbs=Number.isFinite(save.orbs)?Math.max(0,Math.min(9999,save.orbs)):8;save.shards=Number.isFinite(save.shards)?Math.max(0,Math.min(99999,save.shards)):15;save.hp=Number.isFinite(save.hp)?Math.max(1,Math.min(9999,save.hp)):100;save.trials=Array.isArray(save.trials)?save.trials.filter(i=>Number.isInteger(i)&&i>=0&&i<3):[];save.sideRewards=Array.isArray(save.sideRewards)?save.sideRewards.filter(i=>typeof i==='string'):[];save.active=save.party.some(p=>p.uid===save.active)?save.active:save.party[0].uid;}}catch(e){}
let storySeen=new Set(Array.isArray(save.storySeen)?save.storySeen.filter(s=>typeof s==='string'):[]),storyPlaying=false,storyId=null,storyIndex=0,storyReplay=false,storyVideoFailed=false;
let player={x:save.x,z:save.z,y:0,jumpY:0,jumpV:0,dir:0,anim:0,hp:save.hp,level:save.lv,xp:save.xp,dodge:0,hitFlash:0,invuln:0},yaw=save.yaw||0,camX=0,camY=8,camZ=13,camTarget=[0,0,0],cameraView=null,cameraProjection=null;
let lastStrikeAt=-10,orbs=save.orbs,shards=save.shards,party=save.party,box=save.box||[],chests=new Set(save.chests||[]),waypoints=new Set(save.waypoints||[0]),audioEnabled=save.audioEnabled!==false,quality=save.quality||'auto',skillTimer=0,combatCombo=0,playerAttackAnim=0,cameraTilt=0,sprinting=false,active=save.active,caught=save.caught,kills=save.kills,totalDistance=save.distance,bossDefeated=save.boss,evolutions=save.evolutions,gameTime=save.day*320,now=0,uiNow=0,lastSave=0,attackTimer=0,petTimer=0,screenWidth=1,screenHeight=1,panelOpen=false,started=false,paused=false,renderCount=0;
let forageCount=Number.isFinite(save.forageCount)?save.forageCount:0,trialsCleared=new Set(save.trials||[]),sideRewards=new Set(save.sideRewards||[]),activeTrials=new Set(),padMove={x:0,y:0},gamepadButtons=new Set(),gamepadConnected=false,perfFps=60,perfTimer=0,perfFrames=0,autoResolution=1.25,checkpointTimer=0;
let mobs=[],particles=[],pickups=[],effects=[],boss=null,target=null,areas=new Map(),mobSerial=1,coinSerial=1,queuedDamage=[],hintShown=false,regionNow='はじまりの草原',audio=null,keys=new Set(),joystick={x:0,y:0,active:false,pointer:null},drag={on:false,x:0,y:0,pointer:null};
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v)), mix=(a,b,t)=>a+(b-a)*t, smooth=t=>t*t*(3-2*t), dist=(x,z,a,b)=>Math.hypot(x-a,z-b), lerpColor=(a,b,t)=>a.map((v,i)=>mix(v,b[i],t));
function rand(x,z,k=0){let s=Math.sin(x*127.17+z*311.73+k*37.17)*43758.5453;return s-Math.floor(s)}
function noise(x,z){let X=Math.floor(x),Z=Math.floor(z),u=smooth(x-X),v=smooth(z-Z);return mix(mix(rand(X,Z),rand(X+1,Z),u),mix(rand(X,Z+1),rand(X+1,Z+1),u),v)}
function h(x,z){const b=(noise(x*.027,z*.027)-.5)*5+(noise(x*.008+53,z*.008+18)-.5)*8+Math.sin(x*.019)*.9+Math.sin(z*.028)*.85;
 const lake=clamp(1-dist(x,z,81,74)/39,0,1);let y=b-lake*6;const home=clamp(dist(x,z,0,0)/19,0,1);y=mix(.7,y,smooth(home));const shrine=clamp(dist(x,z,111,-83)/19,0,1);y=mix(1.1,y,smooth(shrine));return y;}
function isLake(x,z){return dist(x,z,81,74)<25}
function isShrine(x,z){return dist(x,z,111,-83)<20}
function biome(x,z){if(isLake(x,z))return 'lake';if(isShrine(x,z))return 'shrine';if(x< -58&&z<30)return 'crystal';if(z>95||x>105)return 'wood';if(noise(x*.014+80,z*.014-22)>.65)return 'wood';return 'meadow';}
function regionName(x,z){if(isShrine(x,z))return '星の神殿';if(isLake(x,z))return '月雫の湖';if(biome(x,z)==='crystal')return '星晶の谷';if(biome(x,z)==='wood')return '風唄いの森';return 'はじまりの草原';}
const vec=(x,y,z)=>[x,y,z];
function normal(a,b,c){const u=[b[0]-a[0],b[1]-a[1],b[2]-a[2]],v=[c[0]-a[0],c[1]-a[1],c[2]-a[2]],n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]],s=Math.hypot(...n)||1;return n.map(x=>x/s)}
function unit(a){const d=Math.hypot(...a)||1;return a.map(v=>v/d)}
function makeIco(subdiv=0){let t=(1+Math.sqrt(5))/2,vs=[[-1,t,0],[1,t,0],[-1,-t,0],[1,-t,0],[0,-1,t],[0,1,t],[0,-1,-t],[0,1,-t],[t,0,-1],[t,0,1],[-t,0,-1],[-t,0,1]].map(unit),faces=[[0,11,5],[0,5,1],[0,1,7],[0,7,10],[0,10,11],[1,5,9],[5,11,4],[11,10,2],[10,7,6],[7,1,8],[3,9,4],[3,4,2],[3,2,6],[3,6,8],[3,8,9],[4,9,5],[2,4,11],[6,2,10],[8,6,7],[9,8,1]];if(subdiv)faces=faces.flatMap(f=>{let[a,b,c]=f.map(i=>vs[i]),ab=unit(a.map((v,i)=>v+b[i])),bc=unit(b.map((v,i)=>v+c[i])),ca=unit(c.map((v,i)=>v+a[i])),base=vs.length;vs.push(ab,bc,ca);return[[f[0],base,base+2],[f[1],base+1,base],[f[2],base+2,base+1],[base,base+1,base+2]]});return faces.map(f=>f.map(i=>vs[i]));}
function coneShape(n=9){const out=[];for(let i=0;i<n;i++){let a=i*Math.PI*2/n,b=(i+1)*Math.PI*2/n;let p=[Math.cos(a),0,Math.sin(a)],q=[Math.cos(b),0,Math.sin(b)];out.push([p,[0,1,0],q]);out.push([[0,0,0],q,p]);}return out}
function cylinderShape(n=9){const out=[];for(let i=0;i<n;i++){let a=i*Math.PI*2/n,b=(i+1)*Math.PI*2/n,p=[Math.cos(a),0,Math.sin(a)],q=[Math.cos(b),0,Math.sin(b)],P=[p[0],1,p[2]],Q=[q[0],1,q[2]];out.push([p,P,q],[P,Q,q],[[0,1,0],Q,P],[[0,0,0],p,q]);}return out}
const shape={ball:makeIco(1),stone:makeIco(0),cone:coneShape(8),stem:cylinderShape(7),blade:[[[0,0,-.3],[0,1,0],[.1,0,.3]],[[-.1,0,.3],[0,1,0],[0,0,-.3]]],diamond:[[[0,1,0],[1,0,0],[0,0,1]],[[0,1,0],[0,0,1],[-1,0,0]],[[0,1,0],[-1,0,0],[0,0,-1]],[[0,1,0],[0,0,-1],[1,0,0]],[[0,-1,0],[0,0,1],[1,0,0]],[[0,-1,0],[-1,0,0],[0,0,1]],[[0,-1,0],[0,0,-1],[-1,0,0]],[[0,-1,0],[1,0,0],[0,0,-1]]]};
class Builder{constructor(){this.v=[]}tri(a,b,c,color,norm){const n=norm||normal(a,b,c);for(let p of[a,b,c])this.v.push(...p,...n,...color)} add(sh,x,y,z,sx,sy,sz,color,ry=0,rx=0){let cs=Math.cos(ry),ss=Math.sin(ry),cx=Math.cos(rx),sn=Math.sin(rx);for(const tri of sh){let ps=tri.map(p=>{let px=p[0]*sx,py=p[1]*sy,pz=p[2]*sz;let vy=py*cx-pz*sn,vz=py*sn+pz*cx;return[x+px*cs+vz*ss,y+vy,z-px*ss+vz*cs]});this.tri(...ps,color)}} get count(){return this.v.length/9} asFloat(){return new Float32Array(this.v)}}
function upload(builder,existing,dynamic=false){let arr=builder.asFloat(),buffer=existing?.buffer||gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.bufferData(gl.ARRAY_BUFFER,arr,dynamic?gl.DYNAMIC_DRAW:gl.STATIC_DRAW);return{buffer,count:builder.count};}
function drawMesh(mesh){if(!mesh||!mesh.count)return;gl.bindBuffer(gl.ARRAY_BUFFER,mesh.buffer);if(mesh.packed){gl.vertexAttribPointer(loc.pos,3,gl.FLOAT,false,20,0);gl.vertexAttribPointer(loc.norm,3,gl.BYTE,true,20,12);gl.vertexAttribPointer(loc.col,3,gl.UNSIGNED_BYTE,true,20,16)}else{gl.vertexAttribPointer(loc.pos,3,gl.FLOAT,false,36,0);gl.vertexAttribPointer(loc.norm,3,gl.FLOAT,false,36,12);gl.vertexAttribPointer(loc.col,3,gl.FLOAT,false,36,24)}gl.drawArrays(gl.TRIANGLES,0,mesh.count)}
const C={grass:[.38,.69,.43],brightGrass:[.52,.79,.48],meadow:[.59,.77,.49],wood:[.24,.55,.43],earth:[.57,.62,.42],stone:[.61,.69,.69],stone2:[.40,.52,.59],tree:[.42,.29,.24],leaf:[.29,.65,.41],leaf2:[.47,.82,.53],leaf3:[.26,.49,.49],gold:[1,.82,.43],pink:[.99,.60,.74],crystal:[.49,.85,.96],crystal2:[.77,.61,1],water:[.36,.67,.84],shadow:[.19,.40,.34]};
function groundColor(x,z,y){let b=biome(x,z),v=noise(x*.085+2,z*.085+12),a=b==='wood'?C.wood:b==='crystal'?[.36,.54,.54]:b==='shrine'?[.53,.63,.50]:b==='lake'?[.42,.72,.67]:C.grass;let color=lerpColor(a,C.brightGrass,v*.32);if(isLake(x,z)&&y<.2)color=lerpColor(color,C.water,.7);return color;}
function worldChunk(cx,cz){const builder=new Builder(),SIZE=36,grid=12,startX=cx*SIZE,startZ=cz*SIZE,step=SIZE/grid;for(let iz=0;iz<grid;iz++)for(let ix=0;ix<grid;ix++){let x=startX+ix*step,z=startZ+iz*step,p0=vec(x,h(x,z),z),p1=vec(x+step,h(x+step,z),z),p2=vec(x+step,h(x+step,z+step),z+step),p3=vec(x,h(x,z+step),z+step),col=groundColor(x+step/2,z+step/2,h(x+step/2,z+step/2));builder.tri(p0,p2,p1,col);builder.tri(p0,p3,p2,col)}
 for(let i=0;i<18;i++){let x=startX+2+rand(cx*33+i,cz*21+i,3)*(SIZE-4),z=startZ+2+rand(cx*23+i,cz*37+i,4)*(SIZE-4),nearHome=dist(x,z,0,0)<13,nearShrine=isShrine(x,z),nearLake=isLake(x,z),b=biome(x,z),v=rand(cx*21+i,cz*17+i,6),y=h(x,z);if(nearHome||nearShrine||nearLake)continue;
 if(v<.33){let sc=.76+rand(cx*19+i,cz*27+i,7)*.85,trunk=2.5*sc;builder.add(shape.stem,x,y,z,.25*sc,trunk,.25*sc,C.tree);if(b==='crystal'){builder.add(shape.diamond,x,y+trunk*.72,z,.9*sc,2.4*sc,.9*sc,C.crystal2);builder.add(shape.diamond,x+.5*sc,y+trunk*.58,z,.38*sc,1.1*sc,.4*sc,C.crystal)}else if(b==='wood'){builder.add(shape.cone,x,y+trunk*.56,z,1.7*sc,3.4*sc,1.7*sc,C.leaf3);builder.add(shape.cone,x,y+trunk*.98,z,1.3*sc,2.8*sc,1.3*sc,C.leaf);builder.add(shape.cone,x,y+trunk*1.33,z,.87*sc,2.1*sc,.87*sc,C.leaf2)}else{builder.add(shape.ball,x,y+trunk*.85,z,1.8*sc,1.6*sc,1.65*sc,C.leaf);builder.add(shape.ball,x+.9*sc,y+trunk*.9,z,.9*sc,1.05*sc,.92*sc,C.leaf2);builder.add(shape.ball,x-.6*sc,y+trunk*1.34,z,.9*sc,.8*sc,.9*sc,C.leaf2)}}
 else if(v<.46){let s=.5+rand(cx+i,cz+i,9)*1.2;builder.add(shape.stone,x,y+.15*s,z,.9*s,.44*s,.75*s,rand(cx,i,3)>.5?C.stone:C.stone2)}
 else{let flower=rand(i,cx,7)>.66,sz=.45+rand(i,cz,6)*.45;for(let n=0;n<3;n++){let ox=x+Math.cos(n*2.1)*.2,oz=z+Math.sin(n*2.1)*.2;builder.add(shape.blade,ox,y,oz,.38*sz,.65*sz,.5*sz,rand(i,n,10)>.4?C.brightGrass:C.leaf,rand(i,n,4)*6)}if(flower){builder.add(shape.stem,x,y,z,.04,.43,.04,C.leaf);builder.add(shape.ball,x,y+.49,z,.22,.18,.22,rand(i,cz,8)>.5?C.pink:C.gold)}}
 }
 // Moon-drop lake water surface; its opaque geometry occupies the lower basin.
 if(cx===2&&cz===2){let center=[81,-1.53,74],segments=50;for(let i=0;i<segments;i++){let a=i*2*Math.PI/segments,b=(i+1)*2*Math.PI/segments;let c1=[81+Math.cos(a)*25,-1.53,74+Math.sin(a)*25],c2=[81+Math.cos(b)*25,-1.53,74+Math.sin(b)*25];builder.tri(center,c2,c1,lerpColor(C.water,[.46,.83,.91],.1+.10*Math.sin(i*.8)))}}
 // Tiny fairy-trail stepping stones near the starting area
 if(cx===0&&cz===0){for(let i=0;i<4;i++){let xx=8+i*6,zz=-3-i*5;builder.add(shape.stone,xx,h(xx,zz)+.05,zz,1.4,.10,1.2,C.stone)}}
 // The ancient star sanctuary, a visible fixed world landmark
 if(Math.abs(cx-3)<=1&&Math.abs(cz+2)<=1){const sx=111,sz=-83;if(Math.floor(sx/SIZE)===cx&&Math.floor(sz/SIZE)===cz){let y=h(sx,sz);builder.add(shape.stem,sx,y-.25,sz,6,.55,6,C.stone2);builder.add(shape.stem,sx,y+.24,sz,4.5,.23,4.5,C.stone);for(let n=0;n<6;n++){let a=n*2*Math.PI/6,x=sx+Math.cos(a)*5,z=sz+Math.sin(a)*5;builder.add(shape.stem,x,y,z,.61,5.2,.61,C.stone2);builder.add(shape.diamond,x,y+5.2,z,.54,.9,.54,C.crystal2)}builder.add(shape.diamond,sx,y+1.7,sz,1.8,2.4,1.8,C.crystal2);builder.add(shape.diamond,sx,y+4.2,sz,.65,1.3,.65,C.gold)}}
 // White stone on spawn as a directional visual cue
 if(cx===0&&cz===0){let y=h(3,-9);builder.add(shape.stone,3,y,-9,.8,1.5,.6,C.stone2);builder.add(shape.diamond,3,y+1.4,-9,.53,.83,.51,C.gold)}
 // Traveler's camp: tents, torchlight, notice board, standing stones and stepping path.
 if(cx===0&&cz===0){
   const base=(x,z)=>h(x,z),earth=[.45,.48,.37],wood=[.43,.30,.25],cream=[.84,.72,.52];
   for(let i=0;i<7;i++){let x=5+i*4.4,z=3-i*2.4;builder.add(shape.stone,x,base(x,z)+.08,z,1.55,.10,1.30,[.66,.63,.50]);}
   for(const [x,z,ang] of [[-9,5,.35],[12,11,-.4]]){
     const y=base(x,z);builder.add(shape.cone,x,y,z,3.1,3.25,2.6,cream,ang);builder.add(shape.stem,x,y+.02,z,2.7,.19,2.3,wood,ang);builder.add(shape.diamond,x,y+2.75,z,.25,.45,.25,C.gold);
   }
   for(let a=0;a<9;a++){let ang=a*Math.PI*2/9,x=0+Math.cos(ang)*1.4,z=-3+Math.sin(ang)*1.4;builder.add(shape.stone,x,base(x,z)+.10,z,.49,.27,.42,C.stone2)}
   builder.add(shape.cone,0,base(0,-3)+.12,-3,.53,1.45,.45,[1,.55,.23]);builder.add(shape.cone,0,base(0,-3)+.6,-3,.3,1.3,.3,C.gold);
   for(const [x,z] of [[7,-9],[-5,-14],[16,1]]){const y=base(x,z);builder.add(shape.stem,x,y,z,.12,1.9,.12,wood);builder.add(shape.diamond,x,y+2.2,z,.26,.48,.26,[1,.84,.43]);builder.add(shape.stone,x,y+.1,z,.38,.32,.4,C.stone)}
   builder.add(shape.stem,-2,base(-2,9),9,2.4,1.0,.19,wood);builder.add(shape.stem,-2,base(-2,9)+1.03,9,2.4,.11,.25,C.gold);
 }
 // Mineral spires in the crystal valley create a unique landmark silhouette.
 if(cx===-2&&cz===-1){for(let i=0;i<7;i++){let x=-69+Math.cos(i*2.40)*10,z=-24+Math.sin(i*2.40)*9,y=h(x,z),sz=2.4+rand(i,99)*4;builder.add(shape.diamond,x,y,z,.7+rand(i,3),sz,.7+rand(i,4),i%2?C.crystal2:C.crystal)}}
 // A huge, deliberately readable old tower is visible at the edge of the forest.
 if(cx===3&&cz===3){const x=118,z=115,y=h(x,z);builder.add(shape.stem,x,y,z,3.1,11,3.1,C.stone2);builder.add(shape.cone,x,y+10.8,z,4.2,5.4,4.2,[.27,.47,.59]);for(let j=0;j<4;j++){let a=j*Math.PI/2,xx=x+Math.cos(a)*3,zz=z+Math.sin(a)*3;builder.add(shape.stem,xx,y,zz,.5,10,.5,C.stone);builder.add(shape.diamond,xx,y+11,zz,.5,1.15,.5,C.gold)}}
 return upload(builder);}
let meshCache=new Map();function syncChunks(){const cx=Math.floor(player.x/36),cz=Math.floor(player.z/36),need=new Set();for(let dz=-(quality==='low'?2:3);dz<=(quality==='low'?2:3);dz++)for(let dx=-(quality==='low'?2:3);dx<=(quality==='low'?2:3);dx++){const key=(cx+dx)+','+(cz+dz);need.add(key);if(!meshCache.has(key))meshCache.set(key,worldChunk(cx+dx,cz+dz))}for(let [key,m]of meshCache){if(!need.has(key)){gl.deleteBuffer(m.buffer);meshCache.delete(key)}}}
function spawnMob(x,z,id,level){return{id,level,x,z,y:h(x,z),windup:0,hp:level*24+24,maxHp:level*24+24,state:'wander',walkT:rand(x,z,2)*10,angle:rand(x,z,3)*Math.PI*2,attack:rand(x,z,4)*1.3,serial:mobSerial++,flash:0,dead:false,boss:false,dir:0};}
function spawnWorld(){const nearby=mobs.filter(m=>!m.dead&&dist(m.x,m.z,player.x,player.z)<105).length;if(nearby>=25)return;for(let i=0;i<Math.min(10,27-nearby);i++){let angle=rand(Math.floor(player.x/36)+i*71,Math.floor(player.z/36),1)*Math.PI*2,dd=18+rand(i,Math.floor(player.z),2)*74,x=player.x+Math.cos(angle)*dd,z=player.z+Math.sin(angle)*dd;if(isLake(x,z)||isShrine(x,z)||dist(x,z,0,0)<7)continue;let species=Math.floor(rand(x,z,7)*4),lvl=clamp(1+Math.floor(Math.hypot(x,z)/70)+Math.floor(rand(x,z,9)*2),1,12);mobs.push(spawnMob(x,z,species,lvl));}}
function spawnPickups(){if(pickups.filter(p=>!p.taken&&dist(p.x,p.z,player.x,player.z)<100).length>18)return;for(let i=0;i<14;i++){let a=rand(i+23,Math.floor(player.x/36),2)*Math.PI*2,d=17+rand(i,Math.floor(player.z/36),3)*78,x=player.x+Math.cos(a)*d,z=player.z+Math.sin(a)*d;if(isLake(x,z)||isShrine(x,z))continue;pickups.push({x,z,y:h(x,z),angle:rand(x,z,4)*6,kind:rand(x,z,5)>.22?'crystal':'bloom',taken:false,serial:coinSerial++})}}
function addShadow(b,x,y,z,r){b.add(shape.ball,x,y+.015,z,r,.045,r,C.shadow)}
function part(b,sh,x,y,z,sx,sy,sz,color,heading=0,rx=0){b.add(sh,x,y,z,sx,sy,sz,color,heading,rx)}
function petFigure(b,id,x,y,z,scale,dir=0,evolved=false,t=0,flash=false){const sp=SPECIES[id],s=scale*(evolved?1.2:1),bob=Math.sin(t*3.8+id)*.065,body=flash?[1,.97,.91]:sp.color,accent=sp.accent,hi=sp.highlight;
 addShadow(b,x,y,z,s*.9);const ang=dir;const p=(ox,oy,oz)=>[x+(ox*Math.cos(ang)+oz*Math.sin(ang))*s,y+(oy+bob)*s,z+(-ox*Math.sin(ang)+oz*Math.cos(ang))*s];function obj(sh,ox,oy,oz,sx,sy,sz,col,ry=0,rx=0){const q=p(ox,oy,oz);part(b,sh,...q,sx*s,sy*s,sz*s,col,ang+ry,rx)}
 obj(shape.ball,0,.70,0,.72,.67,.64,body);obj(shape.ball,0,1.25,-.22,.62,.58,.60,hi);
 obj(shape.stone,-.235,1.31,-.76,.105,.132,.105,[.12,.19,.25]);obj(shape.stone,.235,1.31,-.76,.105,.132,.105,[.12,.19,.25]);obj(shape.ball,0,1.11,-.79,.13,.1,.10,accent);
 obj(shape.ball,-.46,.27,-.23,.26,.3,.29,body);obj(shape.ball,.46,.27,-.23,.26,.3,.29,body);
 if(id===0){obj(shape.cone,-.43,1.57,-.08,.25,.95,.29,accent,0,.5);obj(shape.cone,.45,1.54,-.06,.23,1.02,.32,accent,0,-.5);obj(shape.ball,0,.74,.73,.38,.39,.55,hi);if(evolved){obj(shape.cone,0,1.83,.05,.45,.9,.38,C.gold);obj(shape.cone,-.64,.97,.4,.26,.68,.24,accent)}}
 if(id===1){obj(shape.cone,-.45,1.52,-.02,.32,.93,.32,accent,0,-.15);obj(shape.cone,.45,1.52,-.02,.32,.93,.32,accent,0,.15);obj(shape.cone,0,1.74,.16,.28,.82,.25,C.gold);obj(shape.ball,0,.58,.74,.47,.38,.67,accent);obj(shape.cone,0,.74,1.19,.27,.83,.28,hi,0,1.05);if(evolved){obj(shape.cone,-.4,.8,.77,.28,.82,.30,C.gold,0,1)}}
 if(id===2){obj(shape.ball,-.73,.94,-.02,.40,.19,.51,accent);obj(shape.ball,.73,.94,-.02,.40,.19,.51,accent);obj(shape.cone,0,1.82,.18,.40,.64,.23,hi,0,.32);obj(shape.ball,0,.48,.82,.33,.20,.52,accent);if(evolved){obj(shape.cone,-.7,.9,.17,.29,.94,.33,hi);obj(shape.cone,.7,.9,.17,.29,.94,.33,hi)}}
 if(id===3){obj(shape.cone,-.53,1.60,-.05,.27,.88,.30,accent,0,-.3);obj(shape.cone,.54,1.60,-.05,.28,.88,.30,accent,0,.3);obj(shape.diamond,0,1.85,0,.33,.52,.33,C.gold);obj(shape.ball,0,.65,.7,.43,.4,.45,hi);if(evolved){obj(shape.diamond,-.79,1.13,.1,.22,.40,.22,accent);obj(shape.diamond,.79,1.13,.1,.22,.40,.22,accent)}}}
function playerFigure(b,t,asModel=false){const s=1,px=asModel?0:player.x,py=asModel?0:h(player.x,player.z),pz=asModel?0:player.z,dir=asModel?0:player.dir,bob=asModel?0:Math.sin(player.anim*8)*.045;addShadow(b,px,py,pz,.69);const p=(ox,oy,oz)=>[px+ox*Math.cos(dir)+oz*Math.sin(dir),py+oy+bob,pz-ox*Math.sin(dir)+oz*Math.cos(dir)];const obj=(sh,ox,oy,oz,sx,sy,sz,col,ry=0,rx=0)=>part(b,sh,...p(ox,oy,oz),sx,sy,sz,col,dir+ry,rx);
 const moving=!asModel&&(joystick.active||keys.has('KeyW')||keys.has('ArrowUp')||keys.has('KeyA')||keys.has('KeyD')||keys.has('KeyS')),leg=Math.sin(player.anim*9)*(moving?.16:0);obj(shape.ball,0,1.14,.12,.39,.55,.30,[.24,.53,.64]);obj(shape.cone,0,.45,.24,.63,1.20,.54,[.20,.37,.56],0,3.14);obj(shape.ball,0,1.83,0,.32,.34,.31,[.99,.79,.62]);obj(shape.ball,0,2.03,.09,.36,.24,.35,[.20,.25,.34]);obj(shape.ball,-.39,1.18,-.01,.18,.42,.17,[.97,.78,.62],0,leg*.45);obj(shape.ball,.39,1.18,-.01,.18,.42,.17,[.97,.78,.62],0,-leg*.45);obj(shape.ball,-.18,.43,.03+leg,.20,.39,.23,[.15,.28,.37]);obj(shape.ball,.18,.43,.03-leg,.20,.39,.23,[.15,.28,.37]);obj(shape.ball,-.19,.12,-.1+leg,.23,.15,.36,[.16,.20,.28]);obj(shape.ball,.19,.12,-.1-leg,.23,.15,.36,[.16,.20,.28]);obj(shape.ball,-.12,1.88,-.285,.045,.055,.04,[.17,.22,.24]);obj(shape.ball,.12,1.88,-.285,.045,.055,.04,[.17,.22,.24]);obj(shape.cone,0,2.14,.06,.26,.53,.25,[.18,.37,.43],0,.18);obj(shape.ball,.53,1.85,-.05,.06,.55,.07,[.74,.57,.39],0,-.14);obj(shape.diamond,.55,2.35,-.02,.19,.32,.19,[.67,.95,.99]);if(!asModel&&player.invuln>.1){obj(shape.ball,0,1.2,0,.9,1.5,.9,[.78,.98,.96])}}
function bossFigure(b,t,asModel=false){if(!boss||(boss.dead&&!asModel))return;const x=asModel?0:boss.x,z=asModel?0:boss.z,y=asModel?0:h(x,z),bob=asModel?0:Math.sin(t*1.9)*.35;addShadow(b,x,y,z,2.6);part(b,shape.ball,x,y+3.0+bob,z,2.4,2.3,2.3,[.35,.32,.59]);part(b,shape.ball,x,y+4.75+bob,z,1.7,1.5,1.6,[.46,.39,.72]);part(b,shape.diamond,x,y+6.4+bob,z,1.1,1.8,1.1,[.74,.6,.98]);part(b,shape.diamond,x-2,y+4+bob,z,1,1.9,1,[.67,.51,.88],0,-.5);part(b,shape.diamond,x+2,y+4+bob,z,1,1.9,1,[.67,.51,.88],0,.5);part(b,shape.ball,x-.64,y+5+bob,z-1.4,.23,.29,.16,[1,.82,.60]);part(b,shape.ball,x+.64,y+5+bob,z-1.4,.23,.29,.16,[1,.82,.60]);part(b,shape.diamond,x,y+3.2+bob,z-2,.6,.9,.4,[1,.75,.46]);}
function effectParticle(b,p,t){let size=p.size*(1-p.age/p.life)*(.8+Math.sin(t*5+p.seed)*.12);if(size<=0)return;part(b,p.kind==='shard'?shape.diamond:shape.stone,p.x,p.y,p.z,size,size*1.5,size,p.color,p.age*3)}
const I4=new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]);
let petModels=[],playerModel=null,bossModel=null,pickupModels=[],particleMesh=null;
// Original 3D assets authored in Godot and converted offline to low-overhead WebGL buffers.
// No CDN is required at runtime, including in an installed Home Screen Web App.
const advancedModels=Object.create(null);
const speciesKeys=['forest','fire','water','storm'];
const treasurePositions=[[-12,-8],[7,-28],[-32,11],[28,29],[-44,-24],[34,-53],[-83,4],[-61,44],[68,14],[54,93],[88,66],[123,10],[103,-64],[119,-96]];
const transferPoints=[{x:0,z:3,name:'星風のキャンプ'},{x:-55,z:12,name:'星晶の谷'},{x:70,z:60,name:'月雫の湖'},{x:106,z:91,name:'風唄いの森'},{x:109,z:-77,name:'星の神殿'}];
const npcPoints=[{x:5,z:6,name:'旅商人リオ',kind:'shop'},{x:-7,z:8,name:'研究者ミナ',kind:'research'},{x:2,z:-8,name:'星守りセラ',kind:'healer'}];
const trialPoints=[{x:-71,z:-20,name:'星晶の試練',id:3,level:6},{x:92,z:117,name:'風守りの試練',id:0,level:8},{x:59,z:41,name:'水鏡の試練',id:2,level:7}];
let interaction=null,sceneProps=null,hasAdvanced=false,worldDiscoveries=new Set();
async function loadAdvancedModels(){
 const files=['hero_body','hero_arm_l','hero_arm_r','hero_leg_l','hero_leg_r',...speciesKeys.flatMap(n=>[n+'_young',n+'_ascended'])];
 let loaded=0; const load=async name=>{
  const response=await fetch('./assets/meshes/'+name+'.bin');
  if(!response.ok)throw new Error('モデル読み込み失敗: '+name);
  const bytes=new Uint8Array(await response.arrayBuffer());
  if(bytes.byteLength%20)throw new Error('モデル形式が不正: '+name);
  const buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.bufferData(gl.ARRAY_BUFFER,bytes,gl.STATIC_DRAW);
  advancedModels[name]={buffer,count:bytes.byteLength/20,packed:true};
  loaded++;$('loading-progress').style.width=(loaded/files.length*100).toFixed(0)+'%';
 };
 await Promise.all(files.map(load));hasAdvanced=true;
}
function matrixPart(x,y,z,heading,localX,localY,localZ,pitch,scale=1){
 const c=Math.cos(heading),s=Math.sin(heading),cp=Math.cos(pitch),sp=Math.sin(pitch);
 return new Float32Array([c*scale,0,-s*scale,0,s*sp*scale,cp*scale,c*sp*scale,0,s*cp*scale,-sp*scale,c*cp*scale,0,x+c*localX+s*localZ,y+localY,z-s*localX+c*localZ,1]);
}
function drawArt(mesh,x,y,z,scale,rot=0,pitch=0,lx=0,ly=0,lz=0,tint=[1,1,1]){
 if(!mesh)return;gl.uniformMatrix4fv(loc.model,false,matrixPart(x,y,z,rot,lx,ly,lz,pitch,scale));gl.uniform3fv(loc.tint,tint);drawMesh(mesh);
}
function drawEnhancedHero(){
 const y=h(player.x,player.z)+player.jumpY+Math.sin(player.anim*7.4)*.038;
 const heading=-player.dir, moving=joystick.active||keys.has('KeyW')||keys.has('ArrowUp')||keys.has('KeyA')||keys.has('KeyD')||keys.has('KeyS');
 const cycle=Math.sin(player.anim*8),swing=moving?cycle*.55:Math.sin(now*1.1)*.035;
 const attackPose=playerAttackAnim>0?Math.sin((.42-playerAttackAnim)/.42*Math.PI)*1.1:0;
 const color=player.hitFlash>.01?[1.25,.77,.77]:[1,1,1];
 drawArt(advancedModels.hero_body,player.x,y,player.z,1,heading,0,0,0,0,color);
 drawArt(advancedModels.hero_arm_l,player.x,y,player.z,1,heading,swing,-.43,1.71,.02,color);
 drawArt(advancedModels.hero_arm_r,player.x,y,player.z,1,heading,-swing-attackPose,.43,1.71,.02,color);
 drawArt(advancedModels.hero_leg_l,player.x,y,player.z,1,heading,-swing,.21*-1,.99,.03,color);
 drawArt(advancedModels.hero_leg_r,player.x,y,player.z,1,heading,swing,.21,.99,.03,color);
}
function drawEnhancedCreature(id,evolved,x,y,z,scale,rot,flash=false){
 const name=speciesKeys[id]+(evolved?'_ascended':'_young');
 drawArt(advancedModels[name],x,y,z,scale*(evolved?1.05:1),-rot,0,0,0,0,flash?[1.38,1.17,1.16]:[1,1,1]);
}
function initSceneProps(){
 const make=fn=>{let b=new Builder();fn(b);return upload(b)};
 sceneProps={
 shadow:make(b=>{b.add(shape.ball,0,.02,0,.73,.055,.58,[.14,.31,.28])}),
 chest:make(b=>{b.add(shape.stone,0,.39,0,.72,.48,.52,[.31,.37,.42]);b.add(shape.stone,0,.75,0,.79,.12,.55,[.66,.49,.30]);b.add(shape.diamond,0,.78,-.52,.18,.25,.12,C.gold);b.add(shape.stem,0,0,-.48,.09,.8,.08,C.gold)}),
 obelisk:make(b=>{b.add(shape.stem,0,0,0,.68,2.65,.68,[.34,.42,.54]);b.add(shape.diamond,0,2.6,0,.50,.98,.51,[.52,.90,1]);b.add(shape.diamond,0,3.55,0,.30,.48,.30,[.95,.75,1]);b.add(shape.stone,0,0,0,1.15,.32,1.15,[.58,.64,.62])}),
 trial:make(b=>{b.add(shape.stem,0,.08,0,1.8,.42,1.8,[.35,.52,.62]);for(let i=0;i<6;i++){let a=i*Math.PI/3;b.add(shape.diamond,Math.cos(a)*1.25,.52,Math.sin(a)*1.25,.26,.53,.26,C.crystal)}b.add(shape.diamond,0,.55,0,.74,1.25,.74,[.67,.52,1]);b.add(shape.diamond,0,2.22,0,.36,.5,.36,C.gold)}),
 npc:make(b=>{b.add(shape.stem,0,.4,0,.40,1.25,.27,[.23,.51,.66]);b.add(shape.ball,0,2.05,0,.40,.48,.37,[.95,.73,.58]);b.add(shape.cone,0,2.25,0,.44,.48,.46,[.24,.28,.41]);b.add(shape.ball,0,1.0,-.15,.40,.50,.21,[.29,.38,.58]);b.add(shape.diamond,0,2.9,0,.19,.28,.18,C.gold)}),warning:make(b=>{for(let i=0;i<18;i++){let a=i*Math.PI/9,c=(i+1)*Math.PI/9,ra=2.32,rb=2.82;b.tri([Math.sin(a)*ra,.04,Math.cos(a)*ra],[Math.sin(c)*ra,.04,Math.cos(c)*ra],[Math.sin(a)*rb,.04,Math.cos(a)*rb],[.97,.35,.24],[0,1,0]);b.tri([Math.sin(c)*ra,.04,Math.cos(c)*ra],[Math.sin(c)*rb,.04,Math.cos(c)*rb],[Math.sin(a)*rb,.04,Math.cos(a)*rb],[.97,.35,.24],[0,1,0])}})
 };
}
function renderWorldInteractables(){
 if(!sceneProps)return;
 for(let i=0;i<treasurePositions.length;i++){
  if(chests.has(i))continue;const [x,z]=treasurePositions[i];if(dist(x,z,player.x,player.z)>88)continue;
  drawAt(sceneProps.chest,x,h(x,z),z,1.0,0);
 }
 for(let i=0;i<transferPoints.length;i++){
  const p=transferPoints[i];if(dist(p.x,p.z,player.x,player.z)>91)continue;
  drawAt(sceneProps.obelisk,p.x,h(p.x,p.z),p.z,.8,now*.12);
 }
 for(let p of npcPoints){if(dist(p.x,p.z,player.x,player.z)>80)continue;drawAt(sceneProps.npc,p.x,h(p.x,p.z),p.z,.85,0)}
 for(let i=0;i<trialPoints.length;i++){const p=trialPoints[i];if(dist(p.x,p.z,player.x,player.z)<98)drawAt(sceneProps.trial,p.x,h(p.x,p.z),p.z,trialsCleared.has(i)?.58:1,now*.17,trialsCleared.has(i)?[.54,.75,.73]:[1,1,1])}
}
function getInteraction(){let closest=null,min=4.7;
 for(let i=0;i<treasurePositions.length;i++){
  if(chests.has(i))continue;let [x,z]=treasurePositions[i],d=dist(x,z,player.x,player.z);
  if(d<min){min=d;closest={kind:'chest',id:i,name:'宝箱を開ける'}}
 }
 for(let i=0;i<transferPoints.length;i++){let p=transferPoints[i],d=dist(p.x,p.z,player.x,player.z);if(d<min){min=d;closest={kind:'warp',id:i,name:'転移石碑を調べる'}}}
 for(let i=0;i<npcPoints.length;i++){let p=npcPoints[i],d=dist(p.x,p.z,player.x,player.z);if(d<min){min=d;closest={kind:'npc',id:i,name:p.name+'と話す'}}}
 for(let i=0;i<trialPoints.length;i++){let p=trialPoints[i],d=dist(p.x,p.z,player.x,player.z);if(d<min&&!trialsCleared.has(i)){min=d;closest={kind:'trial',id:i,name:p.name+'に挑む'}}}
 return closest;
}
function interact(){
 const item=getInteraction();if(!item){toast('近くに調べられるものはありません');return}
 if(item.kind==='chest'){
  chests.add(item.id);shards+=9;orbs+=2;awardXp(35);toast('宝箱発見！ 星のかけら +9 / オーブ +2');playSound('chest');fanfare();refreshHUD();persist();
 }else if(item.kind==='warp'){
  waypoints.add(item.id);toast('転移地点「'+transferPoints[item.id].name+'」を登録');playSound('ui');openPanel('world-panel');
 }else if(item.kind==='trial'){startTrial(item.id);
 }else if(item.kind==='npc'){
  if(item.id===0){openPanel('shop-panel');refreshShop()}
  if(item.id===1){showStory('researcher')}
  if(item.id===2){player.hp=maxHp();toast('星守りセラ：大丈夫、星紋の灯はまだ消えていません。傷を癒やしました。');playSound('level_up');refreshHUD();}
 }
}
function startTrial(i){
 if(trialsCleared.has(i)){toast('すでに試練を突破しています');return}
 if(activeTrials.has(i)){toast('試練の守護星獣を倒そう');return}
 const point=trialPoints[i],enemy=spawnMob(point.x+5,point.z+3,point.id,point.level);
 enemy.trialId=i;enemy.elite=true;enemy.hp=Math.round(enemy.hp*3.5);enemy.maxHp=enemy.hp;enemy.attack=.7;
 mobs.push(enemy);activeTrials.add(i);target=enemy;
 toast('⚔ '+point.name+'：守護星獣が目覚めた！');playSound('boss');addParticles(point.x,h(point.x,point.z)+2,point.z,C.crystal2,45,'crystal');refreshHUD();
}
function warpTo(i){
 if(!waypoints.has(i)){toast('まだ転移石碑を発見していません','warn');return}
 const p=transferPoints[i];player.x=p.x+3;player.z=p.z+3;player.hp=Math.min(player.hp,maxHp());camX=player.x;camZ=player.z+12;
 syncChunks();spawnWorld();spawnPickups();closePanels();toast('✧ '+p.name+' に転移しました');playSound('skill');persist();
}
async function exportSave(){
 persist();let payload=localStorage.getItem(KEY)||JSON.stringify(save);
 const blob=new Blob([payload],{type:'application/json'}),file=new File([blob],'lumoria-save.json',{type:'application/json'});
 if(navigator.canShare&&navigator.canShare({files:[file]})){
  try{await navigator.share({files:[file],title:'ルミナリア 冒険の記録'});return}catch(e){if(e.name==='AbortError')return}
 }
 const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='lumoria-save.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),10000);
 toast('セーブデータをファイルに書き出しました');
}
async function importSaveFile(file){
 if(!file||file.size>128000){toast('有効なセーブファイルを選択してください','warn');return}
 try{
  const decoded=JSON.parse(await file.text());
  if(!decoded||!Number.isFinite(decoded.x)||!Number.isFinite(decoded.z)||Math.abs(decoded.x)>50000||Math.abs(decoded.z)>50000||!Array.isArray(decoded.party)||decoded.party.length<1||decoded.party.length>6||!decoded.party.every(p=>Number.isInteger(p.id)&&p.id>=0&&p.id<4&&Number.isFinite(p.level)&&p.level>0&&p.level<500))throw Error('形式エラー');
  const safe={...startState(),...decoded};safe.box=Array.isArray(safe.box)?safe.box.filter(p=>p&&Number.isInteger(p.id)&&p.id>=0&&p.id<4).slice(0,200):[];
  safe.chests=Array.isArray(safe.chests)?safe.chests.filter(n=>Number.isInteger(n)&&n>=0&&n<treasurePositions.length):[];
  safe.waypoints=Array.isArray(safe.waypoints)?safe.waypoints.filter(n=>Number.isInteger(n)&&n>=0&&n<transferPoints.length):[0];
  localStorage.setItem(KEY,JSON.stringify(safe));location.reload();
 }catch(e){toast('読み込みに失敗しました。ルミナリアのセーブデータを選択してください。','warn')}
}
function audioObject(){return audioEnabled?document.getElementById('bgm'):null}
function playSound(name){if(!audioEnabled)return;let a=new Audio('./assets/audio/'+name+'.m4a');a.volume=name==='impact'?.3:.42;a.play().catch(()=>{});}
function initBgm(){let b=audioObject();if(!b)return;b.volume=.18;b.loop=true;b.play().catch(()=>{});}
function skillsText(){return ['森の疾風','焔の一閃','蒼波の槍','雷鳴の爪'][activePet()?.id||0]}
function useSkill(){
 if(!started||panelOpen||storyPlaying||skillTimer>0)return;skillTimer=6.6;
 let pet=activePet(),type=pet?.id||0,damage=34+(pet?.level||1)*9+(pet?.evolved?25:0),hit=0;
 const targets=mobs.filter(m=>!m.dead&&dist(player.x,player.z,m.x,m.z)<12);
 if(boss&&!boss.dead&&dist(player.x,player.z,boss.x,boss.z)<15)targets.push(boss);
 for(let m of targets){let mul=typeMultiplier(type,m.id);let dealt=Math.ceil(damage*mul);
  m.hp-=dealt;m.flash=.20;damagePop(m.x,h(m.x,m.z)+2.6,m.z,dealt,mul>1?'#fff5a4':'#a4f5f0');
  addParticles(m.x,h(m.x,m.z)+1.7,m.z,SPECIES[type].accent,14,'crystal');if(m.hp<=0)killMob(m);hit++;
 }
 addParticles(player.x,h(player.x,player.z)+1.3,player.z,SPECIES[type].accent,23,'crystal');
 toast('✦ '+skillsText()+(hit?' · '+hit+'体に命中！':' 発動！'));
 playSound('skill');if(navigator.vibrate)navigator.vibrate(20);
 refreshSkillButton();
}
function typeMultiplier(a,b){return ([[1,1.4,.72,1],[.72,1,1.4,1],[1.4,.72,1,.82],[1,1.1,1.5,1]])[a]?.[b]||1}
function refreshSkillButton(){const b=$('btn-skill'),cd=$('skill-cd');if(!b)return;cd.textContent=skillTimer>0?Math.ceil(skillTimer)+'s':'';b.classList.toggle('cooldown',skillTimer>0);$('skill-name').textContent=skillsText();}
function renderWarpList(){const el=$('warp-list');el.innerHTML=transferPoints.map((p,i)=>'<button data-warp="'+i+'" '+(waypoints.has(i)?'':'disabled')+' class="warp-button">'+(waypoints.has(i)?'✦ ':'◇ ')+p.name+(waypoints.has(i)?'　›':' · 未解放')+'</button>').join('')}
function refreshShop(){ $('shop-details').innerHTML='<div class="shop-intro">星晶を使って旅の準備を整えよう。</div><button class="menu-option" data-buy="orb">◈ 捕獲オーブ ×3 <b>✦ 12</b></button><button class="menu-option" data-buy="heal">✚ HPを全回復 <b>✦ 5</b></button><button class="menu-option" data-buy="exp">★ 星獣に経験値 +150 <b>✦ 20</b></button>'}
function doShop(action){let price=action==='orb'?12:action==='heal'?5:20;if(shards<price){toast('星のかけらが足りません','warn');return}shards-=price;
 if(action==='orb')orbs+=3;if(action==='heal')player.hp=maxHp();if(action==='exp')awardPetXp(activePet(),150);
 toast('交換しました！');playSound('ui');refreshHUD();persist();}
function showBestiary(){const list=$('bestiary-list');list.innerHTML='';for(let i=0;i<4;i++){
  const p=SPECIES[i],seen=party.some(a=>a.id===i)||box.some(a=>a.id===i);
  const evolved=party.some(a=>a.id===i&&a.evolved)||box.some(a=>a.id===i&&a.evolved);
  const row=document.createElement('div');row.className='dex-row'+(seen?'':' undiscovered');
  row.innerHTML='<img src="assets/portraits/'+speciesKeys[i]+'_ascended.webp" alt="'+p.name+'"><div><b>No.0'+(i+1)+'　'+(seen?p.name:'？？？')+'</b><small>'+p.type+'属性　'+(evolved?'最終進化を発見':seen?'進化を目指して育成しよう':'野生で出会うと記録されます')+'</small><span>'+ (seen?'進化後：'+p.evolved:'未発見')+'</span></div>';
  list.appendChild(row);
 }}
function showStorage(){const list=$('storage-list');list.innerHTML='';
 if(!box.length){list.innerHTML='<p class="empty-message">控えの星獣はまだいません。編成が6体になると、捕獲した星獣はここに送られます。</p>';return}
 for(let p of box){let div=document.createElement('div');div.className='pet-entry';div.innerHTML='<img class="storage-face" src="assets/portraits/'+speciesKeys[p.id]+'_'+(p.evolved?'ascended':'young')+'.webp"><div class="pet-entry-main"><strong>'+ (p.evolved?SPECIES[p.id].evolved:SPECIES[p.id].name)+'</strong><small>Lv.'+p.level+'</small><div class="pet-entry-actions"><button data-box="'+p.uid+'">編成へ移す</button></div></div>';list.appendChild(div)}
}

function modelMatrix(x,y,z,s=1,ry=0){const co=Math.cos(ry)*s,si=Math.sin(ry)*s;return new Float32Array([co,0,-si,0,0,s,0,0,si,0,co,0,x,y,z,1]);}
function drawAt(mesh,x,y,z,scale=1,rot=0,tint=[1,1,1]){if(!mesh)return;gl.uniformMatrix4fv(loc.model,false,modelMatrix(x,y,z,scale,rot));gl.uniform3fv(loc.tint,tint);drawMesh(mesh)}
function generateModels(){const make=fn=>{const b=new Builder();fn(b);return upload(b)};for(let id=0;id<4;id++)for(let ev=0;ev<2;ev++)petModels[id*2+ev]=make(b=>petFigure(b,id,0,0,0,1,0,!!ev,0,false));playerModel=make(b=>playerFigure(b,0,true));bossModel=make(b=>bossFigure(b,0,true));
 pickupModels[0]=make(b=>{part(b,shape.diamond,0,1.1,0,.38,.8,.39,C.crystal2);part(b,shape.diamond,-.3,.42,0,.22,.38,.22,C.crystal)});pickupModels[1]=make(b=>{part(b,shape.stem,0,0,0,.07,.84,.07,C.leaf);part(b,shape.ball,0,.82,0,.4,.25,.36,C.pink);part(b,shape.ball,0,.88,0,.16,.15,.15,C.gold)})}
function renderActors(){
 if(hasAdvanced){if(sceneProps)drawAt(sceneProps.shadow,player.x,h(player.x,player.z)+.01,player.z,1);drawEnhancedHero()}else drawAt(playerModel,player.x,h(player.x,player.z)+player.jumpY+Math.sin(player.anim*8)*.045,player.z,1,player.dir,player.hitFlash>.01?[1.3,.7,.7]:[1,1,1]);
 const pet=activePet();if(pet){const f=followPosition();if(hasAdvanced){if(sceneProps)drawAt(sceneProps.shadow,f.x,h(f.x,f.z)+.01,f.z,.8);drawEnhancedCreature(pet.id,pet.evolved,f.x,h(f.x,f.z)+Math.sin(gameTime*3.8)*.09,f.z,.57,player.dir);}else drawAt(petModels[pet.id*2+Number(pet.evolved)],f.x,h(f.x,f.z)+Math.sin(gameTime*3.8)*.09,f.z,.64,player.dir)}
 for(let m of mobs){if(m.dead||dist(m.x,m.z,player.x,player.z)>66)continue;
  if(hasAdvanced){if(sceneProps)drawAt(sceneProps.shadow,m.x,h(m.x,m.z)+.01,m.z,.74);drawEnhancedCreature(m.id,false,m.x,h(m.x,m.z)+Math.sin(gameTime*3.8+m.serial)*.10,m.z,.53+m.level*.008,m.dir,m.flash>.01);}
  else drawAt(petModels[m.id*2],m.x,h(m.x,m.z)+Math.sin(gameTime*3.8+m.serial)*.10,m.z,.60+m.level*.015,m.dir,m.flash>.01?[1.4,1.2,1.2]:[1,1,1])
 }
 if(boss&&!boss.dead&&dist(boss.x,boss.z,player.x,player.z)<110){if(hasAdvanced){if(sceneProps)drawAt(sceneProps.shadow,boss.x,h(boss.x,boss.z)+.01,boss.z,3);drawArt(advancedModels.storm_ascended,boss.x,h(boss.x,boss.z)+Math.sin(gameTime*1.9)*.23,boss.z,2.15,Math.sin(gameTime*.3),0,0,0,0,boss.flash>.01?[1.4,.9,.9]:[.70,.60,1.20])}else drawAt(bossModel,boss.x,h(boss.x,boss.z)+Math.sin(gameTime*1.9)*.35,boss.z)}
 renderWorldInteractables();if(sceneProps){for(let m of mobs){if(m.windup>0&&!m.dead&&dist(m.x,m.z,player.x,player.z)<35)drawAt(sceneProps.warning,m.x,h(m.x,m.z)+.03,m.z,1+m.windup*.12)}if(boss&&!boss.dead&&boss.windup>0)drawAt(sceneProps.warning,boss.x,h(boss.x,boss.z)+.03,boss.z,1.6)}
 for(let item of pickups)if(!item.taken&&dist(item.x,item.z,player.x,player.z)<85){let y=item.y+Math.sin(gameTime*2+item.angle)*.16;drawAt(pickupModels[item.kind==='crystal'?0:1],item.x,y,item.z,1,gameTime*.2)}
 if(particles.length){const b=new Builder();for(let p of particles)effectParticle(b,p,gameTime);particleMesh=upload(b,particleMesh,true);drawAt(particleMesh,0,0,0)}
}
function perspective(fovy,aspect,near,far){let f=1/Math.tan(fovy/2),d=1/(near-far);return new Float32Array([f/aspect,0,0,0,0,f,0,0,0,0,(far+near)*d,-1,0,0,far*near*2*d,0])}
function lookAt(eye,at){let z=unit(eye.map((a,i)=>a-at[i])),x=unit([z[2],0,-z[0]]),y=[z[1]*x[2]-z[2]*x[1],z[2]*x[0]-z[0]*x[2],z[0]*x[1]-z[1]*x[0]];return new Float32Array([x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-(x[0]*eye[0]+x[1]*eye[1]+x[2]*eye[2]),-(y[0]*eye[0]+y[1]*eye[1]+y[2]*eye[2]),-(z[0]*eye[0]+z[1]*eye[1]+z[2]*eye[2]),1])}
function mulPoint(m,p){return[m[0]*p[0]+m[4]*p[1]+m[8]*p[2]+m[12]*p[3],m[1]*p[0]+m[5]*p[1]+m[9]*p[2]+m[13]*p[3],m[2]*p[0]+m[6]*p[1]+m[10]*p[2]+m[14]*p[3],m[3]*p[0]+m[7]*p[1]+m[11]*p[2]+m[15]*p[3]]}
function project(x,y,z){let clip=mulPoint(cameraProjection,mulPoint(cameraView,[x,y,z,1]));if(clip[3]<=0)return null;return{x:(clip[0]/clip[3]*.5+.5)*screenWidth,y:(1-(clip[1]/clip[3]*.5+.5))*screenHeight};}
function resize(){let ratio=Math.min(window.devicePixelRatio||1,quality==='low'?.95:quality==='high'?1.7:autoResolution),w=Math.floor(canvas.clientWidth*ratio),ht=Math.floor(canvas.clientHeight*ratio);if(canvas.width!==w||canvas.height!==ht){canvas.width=w;canvas.height=ht;gl.viewport(0,0,w,ht)}screenWidth=canvas.clientWidth;screenHeight=canvas.clientHeight;cameraProjection=perspective(Math.PI/3.1,Math.max(.9,w/ht),.14,250);}
function render(){if(!started)return;resize();let day=.72+.28*Math.sin(gameTime/320*2*Math.PI);let sky=[.56,.76,.85].map(v=>v*day),fog=[.59,.74,.72].map(v=>v*day);if(biome(player.x,player.z)==='crystal')fog=lerpColor(fog,[.55,.62,.77],.31);if(isLake(player.x,player.z))fog=lerpColor(fog,[.49,.73,.87],.3);
 gl.clear(gl.DEPTH_BUFFER_BIT);drawSky(Math.sin(gameTime/320*2*Math.PI),biome(player.x,player.z)==='wood'?.4:.1);
 const cy=h(player.x,player.z);let cx=player.x-Math.sin(yaw)*12,cz=player.z+Math.cos(yaw)*12,ty=cy+2.4;camX=mix(camX,cx,.10);camY=mix(camY,Math.max(h(cx,cz)+1.4,ty+6.9+cameraTilt),.08);camZ=mix(camZ,cz,.10);cameraView=lookAt([camX,camY,camZ],[player.x,cy+1.35,player.z]);gl.uniformMatrix4fv(loc.proj,false,cameraProjection);gl.uniformMatrix4fv(loc.view,false,cameraView);gl.uniform3fv(loc.fog,fog);gl.uniform1f(loc.day,day);gl.uniformMatrix4fv(loc.model,false,I4);gl.uniform3fv(loc.tint,[1,1,1]);
 for(let [key,mesh] of meshCache){const parts=key.split(',').map(Number);if(dist(parts[0]*36+18,parts[1]*36+18,player.x,player.z)<171)drawMesh(mesh)}renderActors();}
function activePet(){return party.find(p=>p.uid===active)||party[0]}
function followPosition(){return{x:player.x-Math.sin(player.dir)*1.5+Math.cos(player.dir)*1.3,z:player.z+Math.cos(player.dir)*1.5+Math.sin(player.dir)*1.3}}
function addParticles(x,y,z,color,n=9,kind='sparks'){for(let i=0;i<n;i++){if(particles.length>95)particles.shift();let a=rand(i,gameTime,9)*Math.PI*2,v=.9+rand(i,gameTime,3)*2;particles.push({x,y,z,vx:Math.cos(a)*v,vy:1+rand(i,gameTime,5)*2,vz:Math.sin(a)*v,age:0,life:.65+rand(i,gameTime,4)*.75,size:.12+rand(i,gameTime,7)*.15,color,kind:kind==='crystal'?'shard':'sparks',seed:rand(i,gameTime)})}}
function audioTone(freq,duration=.15,type='sine',gain=.045){try{audio??=new(window.AudioContext||window.webkitAudioContext)();let osc=audio.createOscillator(),g=audio.createGain(),t=audio.currentTime;osc.type=type;osc.frequency.setValueAtTime(freq,t);osc.frequency.exponentialRampToValueAtTime(freq*.65,t+duration);g.gain.setValueAtTime(gain,t);g.gain.exponentialRampToValueAtTime(.0001,t+duration);osc.connect(g);g.connect(audio.destination);osc.start(t);osc.stop(t+duration+.01)}catch(e){}}
function fanfare(){[440,554,659,880].forEach((f,i)=>setTimeout(()=>audioTone(f,.29,'sine',.055),i*105))}
function toast(message,type='good'){if(!started)return;let t=document.createElement('div');t.className='toast '+type;t.textContent=message;$('toast-container').appendChild(t);setTimeout(()=>t.remove(),3200)}
function damagePop(x,y,z,amount,color){let pos=project(x,y,z);if(!pos)return;let pop=document.createElement('span');pop.className='damage-pop';pop.textContent=(amount>0?'-':'')+Math.abs(amount);pop.style.cssText=`left:${pos.x}px;top:${pos.y}px;color:${color||'#ffe9b3'}`;$('damage-container').appendChild(pop);setTimeout(()=>pop.remove(),1100)}
function awardXp(n){player.xp+=n;while(player.xp>=player.level*65){player.xp-=player.level*65;player.level++;player.hp=Math.min(maxHp(),player.hp+35);toast('✦ 冒険者 Lv.'+player.level+' にレベルアップ！');fanfare()}let p=activePet();if(p)awardPetXp(p,n)}
function awardPetXp(p,amount){p.xp+=amount;while(p.xp>=p.level*45){p.xp-=p.level*45;p.level++;addParticles(player.x,h(player.x,player.z)+2,player.z,C.gold,17,'crystal');toast('✧ '+SPECIES[p.id].name+' が Lv.'+p.level+' に成長！');audioTone(920,.25)}refreshHUD()}
function maxHp(){return 100+(player.level-1)*14}
function selectTarget(){target=null;let best=19;for(let m of mobs){if(m.dead)continue;let d=dist(player.x,player.z,m.x,m.z);if(d<best){best=d;target=m}}if(boss&&!boss.dead){let d=dist(player.x,player.z,boss.x,boss.z);if(d<best){best=d;target=boss}}}
function attack(){if(!started||panelOpen||attackTimer>0)return;
 if(now-lastStrikeAt>2.0)combatCombo=0;lastStrikeAt=now;const combo=(combatCombo++%3);
 attackTimer=[.36,.33,.52][combo];playerAttackAnim=attackTimer;selectTarget();playSound('swing');audioTone(400+combo*75,.13,'triangle',.025);
 let p=activePet();let hit=target&&dist(player.x,player.z,target.x,target.z)<(target.boss?7.0:5.8);
 if(hit){let angle=Math.atan2(target.x-player.x,-(target.z-player.z));hit=Math.cos(angle-player.dir)>.02}
 if(!hit){addParticles(player.x+Math.sin(player.dir)*2,h(player.x,player.z)+1.7,player.z-Math.cos(player.dir)*2,[.68,.96,.97],8);return}
 const dmg=Math.round((16+player.level*2+(p?.level||1)*2+Math.random()*7)*[1,1.1,1.55][combo]*typeMultiplier(p?.id||0,target.id||0));
 target.hp-=dmg;target.flash=.20;addParticles(target.x,h(target.x,target.z)+(target.boss?4:1),target.z,combo===2?C.crystal2:C.gold,12+combo*5);damagePop(target.x,h(target.x,target.z)+(target.boss?5:2),target.z,dmg,combo===2?'#fce6b2':'#e9fff1');
 if(combo===2){$('combo-text').textContent='✦ フィニッシュ ×1.5';$('combo-text').classList.add('visible');setTimeout(()=>$('combo-text').classList.remove('visible'),800);}
 if(target.hp<=0)killMob(target);
}
function killMob(m){if(m.dead)return;m.dead=true;kills++;playSound('impact');if(Number.isInteger(m.trialId)&&!trialsCleared.has(m.trialId)){trialsCleared.add(m.trialId);activeTrials.delete(m.trialId);shards+=18;orbs+=4;toast('✦ '+trialPoints[m.trialId].name+' 突破！ かけら+18 / 捕獲オーブ+4');fanfare();persist()}if(m.boss){bossDefeated=true;shards+=60;orbs+=10;setTimeout(()=>showStory('finale'),1000);toast('✦ 星の守護者を解放！ かけら+60 / オーブ+10');fanfare();setTimeout(()=>toast('第一章クリア！ 世界の探索は続きます ✧'),2200)}else{let gain=15+m.level*6,sh=1+Math.floor(Math.random()*3);shards+=sh;awardXp(gain);if(Math.random()<.24)orbs++;toast('討伐成功！ +'+gain+' EXP / かけら +'+sh)}addParticles(m.x,h(m.x,m.z)+1,m.z,m.boss?C.crystal2:SPECIES[m.id].accent,22,'crystal');selectTarget();refreshHUD();}
function catchMob(){if(!started||panelOpen||storyPlaying)return;let item=pickups.find(p=>!p.taken&&dist(p.x,p.z,player.x,player.z)<3.7);if(item){collect(item);return}if(orbs<=0){toast('オーブがありません。星晶を探しましょう','warn');return}selectTarget();if(!target){toast('近くに星獣がいません。近づいてください','warn');return}if(target.boss){toast('神殿の守護者は捕獲できません','warn');return}let d=dist(player.x,player.z,target.x,target.z);if(d>9){toast('あと少し近づくと捕獲できます','warn');return}orbs--;let ratio=target.hp/target.maxHp,chance=clamp(.22+(1-ratio)*.93+(player.level-target.level)*.035,.08,.98);const success=Math.random()<chance;addParticles(target.x,h(target.x,target.z)+1.0,target.z,[.53,.91,1],15,'crystal');audioTone(700,.2,'sine');if(success){const m=target;{let p={id:m.id,level:m.level,xp:0,evolved:false,uid:++save.nextUid};if(party.length<6){party.push(p);toast('◈ '+SPECIES[m.id].name+' を仲間にした！')}else{box.push(p);toast('◈ '+SPECIES[m.id].name+' を控えボックスに送った！')}caught++;awardXp(20);m.dead=true;if(caught>=3&&!storySeen.has('resonance'))setTimeout(()=>showStory('resonance'),650);playSound('capture');fanfare()}}else toast('惜しい！ 星獣がオーブから飛び出した','warn');refreshHUD();}
function collect(p){if(p.taken)return;p.taken=true;const amt=p.kind==='crystal'?3+Math.floor(Math.random()*3):1;forageCount++;if(p.kind==='crystal'){shards+=amt;if(Math.random()<.45)orbs++;toast('✦ 星のかけら +'+amt+(Math.random()<.1?'':'') );audioTone(820,.15)}else{orbs+=2;player.hp=Math.min(maxHp(),player.hp+13);toast('✧ 星咲きの花：オーブ +2 / HP回復');audioTone(710,.20)}addParticles(p.x,p.y+.8,p.z,p.kind==='crystal'?C.crystal2:C.pink,14,'crystal');refreshHUD()}
function jump(){if(!started||panelOpen||player.jumpY>0)return;player.jumpV=6.4;playSound('dodge')}
function toggleSprint(){sprinting=!sprinting;$('btn-sprint').classList.toggle('selected',sprinting);toast(sprinting?'ダッシュ ON':'ダッシュ OFF')}
function dodge(){if(!started||panelOpen||player.dodge>0)return;playSound('dodge');player.dodge=.65;player.invuln=.5;let f=1,side=joystick.x,forward=-joystick.y;if(Math.hypot(side,forward)<.1)forward=1;let dx=side*Math.cos(yaw)+forward*Math.sin(yaw),dz=side*Math.sin(yaw)-forward*Math.cos(yaw);player.x+=dx*3.8;player.z+=dz*3.8;addParticles(player.x,h(player.x,player.z)+.6,player.z,[.67,.97,.94],9);audioTone(340,.14)}
function switchPet(){if(party.length<2){toast('星獣を捕獲すると交代できます');return}let i=party.findIndex(p=>p.uid===active);active=party[(i+1)%party.length].uid;toast('✧ '+SPECIES[activePet().id].name+' に交代');refreshHUD()}
function landMobHit(m){
 if(m.dead||player.invuln>0||player.jumpY>.75||dist(player.x,player.z,m.x,m.z)>3.1+(m.boss?1.4:0))return;
 const dmg=m.boss?18:5+Math.ceil(m.level*1.2);player.hp=Math.max(0,player.hp-dmg);player.hitFlash=.18;player.invuln=.72;
 damagePop(player.x,h(player.x,player.z)+2,player.z,dmg,'#ffa2a2');playSound('impact');
 if(navigator.vibrate)navigator.vibrate([20,35,20]);
 if(player.hp<=0){player.hp=maxHp();player.x=0;player.z=3;shards=Math.max(0,shards-4);toast('光の加護で草原へ帰還しました（かけら -4）','warn')}
 refreshHUD();
}
function tryMobHit(m){
 if(m.windup>0||m.attack>0||dist(player.x,player.z,m.x,m.z)>3.1+(m.boss?1.4:0))return;
 m.windup=m.boss?1.0:.64;m.attack=m.boss?2.7:1.95;
}
function pollGamepad(dt){
 const pads=typeof navigator.getGamepads==='function'?navigator.getGamepads():[];
 const pad=Array.from(pads||[]).find(p=>p&&p.connected);
 if(!pad){padMove.x=0;padMove.y=0;gamepadButtons.clear();gamepadConnected=false;return}
 if(!gamepadConnected){gamepadConnected=true;toast('🎮 コントローラーを接続しました')}
 const dead=v=>Math.abs(v)>.16?v:0;
 padMove.x=dead(pad.axes?.[0]||0);padMove.y=dead(pad.axes?.[1]||0);
 if(!panelOpen){yaw-=dead(pad.axes?.[2]||0)*dt*2.6;cameraTilt=clamp(cameraTilt+dead(pad.axes?.[3]||0)*dt*2.8,-3.8,7.5)}
 const mappings=[[0,jump],[1,dodge],[2,catchMob],[3,switchPet],[4,useSkill],[5,attack],[8,()=>openPanel('quest-panel')],[9,()=>panelOpen?closePanels():openPanel('pause-panel')],[10,toggleSprint]];
 for(const [i,fn] of mappings){let pressed=!!pad.buttons?.[i]?.pressed;if(pressed&&!gamepadButtons.has(i))fn();if(pressed)gamepadButtons.add(i);else gamepadButtons.delete(i)}
}
function updateMovement(dt){let side=joystick.active?joystick.x:padMove.x,forward=joystick.active?-joystick.y:-padMove.y;if(keys.has('KeyW')||keys.has('ArrowUp'))forward+=1;if(keys.has('KeyS')||keys.has('ArrowDown'))forward-=1;if(keys.has('KeyA')||keys.has('ArrowLeft'))side-=1;if(keys.has('KeyD')||keys.has('ArrowRight'))side+=1;let mag=Math.hypot(side,forward);if(mag>1){side/=mag;forward/=mag;mag=1}if(mag>.08){let dx=side*Math.cos(yaw)+forward*Math.sin(yaw),dz=side*Math.sin(yaw)-forward*Math.cos(yaw),spd=sprinting||keys.has('ShiftLeft')?10.5:7.5,step=spd*dt*mag,oldX=player.x,oldZ=player.z;player.x+=dx*step;player.z+=dz*step;totalDistance+=step;player.dir=Math.atan2(dx,-dz);player.anim+=dt*mag*1.65;if(isLake(player.x,player.z)&&h(player.x,player.z)<-1.0){player.x=oldX;player.z=oldZ;if(Math.random()<.007)toast('湖は深そうです。岸沿いに進みましょう')}}else player.anim+=dt*.2;}
function update(dt){if(!started)return;pollGamepad(dt);if(panelOpen||storyPlaying)return;now+=dt;gameTime+=dt;attackTimer=Math.max(0,attackTimer-dt);skillTimer=Math.max(0,skillTimer-dt);playerAttackAnim=Math.max(0,playerAttackAnim-dt);if(Math.floor(skillTimer+dt)!==Math.floor(skillTimer))refreshSkillButton();petTimer=Math.max(0,petTimer-dt);player.dodge=Math.max(0,player.dodge-dt);player.invuln=Math.max(0,player.invuln-dt);player.hitFlash=Math.max(0,player.hitFlash-dt);
 updateMovement(dt);if(player.jumpY>0||player.jumpV>0){player.jumpY=Math.max(0,player.jumpY+player.jumpV*dt);player.jumpV-=18.5*dt;if(player.jumpY===0)player.jumpV=0}selectTarget();const pos=followPosition();
 for(let m of mobs){if(m.dead)continue;let dd=dist(player.x,player.z,m.x,m.z);m.flash=Math.max(0,m.flash-dt);m.attack-=dt;if(m.windup>0){m.windup-=dt;if(m.windup<=0){m.windup=0;landMobHit(m)}}m.walkT+=dt;let spd=.38;if(dd<9){let dx=player.x-m.x,dz=player.z-m.z;if(dd>2.7){m.x+=dx/dd*dt*(m.level>4?1.5:1.06);m.z+=dz/dd*dt*(m.level>4?1.5:1.06);m.dir=Math.atan2(dx,-dz)}if(dd<3.1)tryMobHit(m)}else if(dd<90){m.angle+=Math.sin(m.walkT*.5+m.serial)*dt*.25;let dx=Math.sin(m.angle)*spd*dt,dz=Math.cos(m.angle)*spd*dt;m.x+=dx;m.z+=dz;m.dir=Math.atan2(dx,-dz)}if(dd>150){m.dead=true;if(Number.isInteger(m.trialId))activeTrials.delete(m.trialId)}}
 if(boss&&!boss.dead){boss.flash=Math.max(0,(boss.flash||0)-dt);if(dist(player.x,player.z,boss.x,boss.z)<22&&Math.floor(now*3)!==Math.floor((now-dt)*3)){addParticles(boss.x,h(boss.x,boss.z)+3,boss.z,C.crystal2,2,'crystal')}boss.attack-=dt;if(boss.windup>0){boss.windup-=dt;if(boss.windup<=0){boss.windup=0;landMobHit(boss)}}let d=dist(boss.x,boss.z,player.x,player.z);if(d<6)tryMobHit(boss)}
 if(petTimer===0){let enemy=mobs.find(m=>!m.dead&&dist(m.x,m.z,pos.x,pos.z)<9);if(!enemy&&boss&&!boss.dead&&dist(pos.x,pos.z,boss.x,boss.z)<12)enemy=boss;if(enemy){let p=activePet(),dmg=7+(p?.level||1)*3+(p?.evolved?12:0);enemy.hp-=dmg;enemy.flash=.15;addParticles(enemy.x,h(enemy.x,enemy.z)+(enemy.boss?3:1.2),enemy.z,SPECIES[p.id].accent,6);damagePop(enemy.x,h(enemy.x,enemy.z)+(enemy.boss?4:2),enemy.z,dmg,'#aef9e1');if(enemy.hp<=0)killMob(enemy);petTimer=1.65}}
 for(let p of pickups){if(!p.taken&&dist(p.x,p.z,player.x,player.z)<1.8)collect(p);if(dist(p.x,p.z,player.x,player.z)>150)p.taken=true}for(let p of particles){p.age+=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.z+=p.vz*dt;p.vy-=3.0*dt}particles=particles.filter(p=>p.age<p.life);
 mobs=mobs.filter(m=>!m.dead||now<0.5?true:!m.dead);pickups=pickups.filter(p=>!p.taken);
 if(now%4<dt){spawnWorld();spawnPickups()}if(dist(player.x,player.z,0,-3)<32&&Math.floor(now*2)!==Math.floor((now-dt)*2)){addParticles(0,h(0,-3)+.8,-3,C.gold,2)}if(Math.floor(now*2)!==Math.floor((now-dt)*2)){let next=getInteraction();interaction=next;const b=$('btn-interact');if(b){b.classList.toggle('hidden',!next);$('interact-label').textContent=next?next.name:''}}
 if(Math.floor(now/1.8)!==Math.floor((now-dt)/1.8))refreshHUD();if(caught>=3&&evolutions>=1&&!bossDefeated&&!storySeen.has('temple')&&dist(player.x,player.z,111,-83)<31){showStory('temple')}if(now-lastSave>9){persist();lastSave=now}if(Math.floor(now/5)!==Math.floor((now-dt)/5))syncChunks();}
// Optional, persistent adventures. Rewards are only claimable once.
const SIDE_QUESTS=[
 {id:'collector',title:'星晶の採集家',description:'フィールドの光る素材を12回拾う',need:12,progress:()=>forageCount,reward:{shards:12,orbs:2}},
 {id:'archaeologist',title:'失われた遺跡の調査',description:'宝箱を3つ発見する',need:3,progress:()=>chests.size,reward:{shards:14,orbs:1}},
 {id:'trial',title:'星の試練',description:'守護星獣の試練を2つ突破する',need:2,progress:()=>trialsCleared.size,reward:{shards:25,orbs:4}},
 {id:'hunter',title:'大地の守り手',description:'野生の星獣を12体討伐する',need:12,progress:()=>kills,reward:{shards:20,orbs:3}},
 {id:'bond',title:'進化の証',description:'1体以上の星獣を進化させる',need:1,progress:()=>evolutions,reward:{shards:16,orbs:4}}
];
function questUI(){
 const chapter=document.getElementById('quest-chapter'),list=document.getElementById('side-quest-list');
 chapter.innerHTML='<b>第一章｜星脈の目覚め</b><p>'+currentQuest()+'</p><span>星獣との共鳴が失われた記憶を呼び戻す。三つの灯を結び、進化の光で神殿の封印を解こう。</span>';
 list.innerHTML=SIDE_QUESTS.map(q=>{let n=Math.min(q.need,q.progress()),done=n>=q.need,claimed=sideRewards.has(q.id);return '<article class="side-quest '+(claimed?'complete':'')+'"><div class="side-title"><b>'+q.title+'</b><span>'+n+' / '+q.need+'</span></div><p>'+q.description+'</p><div class="side-progress"><i style="width:'+Math.round(n/q.need*100)+'%"></i></div><div class="side-reward"><span>報酬：✦'+q.reward.shards+' / ◈'+q.reward.orbs+'</span><button data-reward="'+q.id+'" '+(done&&!claimed?'':'disabled')+'>'+(claimed?'受取済み':done?'報酬を受け取る':'進行中')+'</button></div></article>';}).join('');
 $('quest-extras').textContent='試練の祭壇 '+trialsCleared.size+' / '+trialPoints.length+' · 転移地点 '+waypoints.size+' / '+transferPoints.length;
}
function claimSideReward(id){const q=SIDE_QUESTS.find(q=>q.id===id);if(!q||sideRewards.has(id)||q.progress()<q.need)return;
 sideRewards.add(id);shards+=q.reward.shards;orbs+=q.reward.orbs;playSound('chest');fanfare();toast('✦ '+q.title+' 達成報酬を受け取りました');questUI();refreshHUD();persist();
}
function objective(){if(caught<3)return{x:-12,z:-14,label:'星獣を捕獲'};if(evolutions<1)return{x:5,z:6,label:'キャンプで育成'};if(!bossDefeated)return{x:111,z:-83,label:'封印された星の神殿'};return{x:-71,z:-20,label:'新たな試練'};}
function refreshCompass(){const el=$('quest-compass');if(!el)return;const o=objective(),d=dist(player.x,player.z,o.x,o.z),angle=Math.atan2(o.x-player.x,-(o.z-player.z)),relative=Math.atan2(Math.sin(angle-yaw),Math.cos(angle-yaw)),arrow=Math.abs(relative)<.50?'↑':Math.abs(relative)>2.5?'↓':relative>0?'↗':'↖';el.textContent=arrow+' '+o.label+' · '+Math.round(d)+'m';}
function currentQuest(){if(caught<3)return '第一章｜記憶を持つ星獣を集める '+caught+'/3';if(evolutions<1)return '第一章｜星獣を進化させ、星脈を共鳴させる';if(!bossDefeated)return '第一章｜星の神殿で封印の真実を確かめる';return '第一章クリア｜忘却の潮の源を探す旅は続く'}
function refreshHUD(){if(!started)return;let hp=Math.round(player.hp);$('level-badge').textContent='Lv.'+player.level;$('health-label').textContent=hp+'/'+maxHp();$('health-bar').style.width=clamp(hp/maxHp()*100,0,100)+'%';$('xp-bar').style.width=clamp(player.xp/(player.level*65)*100,0,100)+'%';$('quest-text').textContent=currentQuest();$('orb-count').textContent=orbs;$('shard-count').textContent=shards;const pet=activePet();if(pet){let sp=SPECIES[pet.id];$('pet-avatar').src='assets/portraits/'+speciesKeys[pet.id]+'_'+(pet.evolved?'ascended':'young')+'.webp';$('pet-name').textContent=pet.evolved?sp.evolved:sp.name;$('pet-level').textContent='Lv. '+pet.level+' · EXP '+pet.xp+'/'+(pet.level*45);$('pet-exp').style.width=clamp(pet.xp/(pet.level*45)*100,0,100)+'%'}let newRegion=regionName(player.x,player.z);if(regionNow!==newRegion){regionNow=newRegion;toast('✧ '+newRegion+' に到着')}else regionNow=newRegion;$('region-name').textContent='✦ '+newRegion;$('coordinates').textContent='X '+Math.round(player.x)+' · Z '+Math.round(player.z);refreshCompass();if(target){$('target-panel').classList.remove('hidden');$('target-name').textContent=target.boss?'虚空の守護者':target.elite?'★ '+SPECIES[target.id].name+'・守護種':SPECIES[target.id].name;$('target-level').textContent=target.boss?'BOSS':'Lv.'+target.level;$('target-bar').style.width=clamp(target.hp/target.maxHp*100,0,100)+'%';$('target-help').textContent=target.boss?'星晶の神殿を守る古代獣':target.hp/target.maxHp<.53?'捕獲チャンス！ ◈ ボタンをタップ':'攻撃で弱らせて捕獲しよう'}else $('target-panel').classList.add('hidden');}
function persist(){save={...save,x:player.x,z:player.z,yaw,lv:player.level,xp:player.xp,hp:player.hp,orbs,shards,party,box,chests:[...chests],waypoints:[...waypoints],audioEnabled,quality,active,caught,kills,distance:totalDistance,boss:bossDefeated,evolutions,day:(gameTime/320)%1,storySeen:[...storySeen],forageCount,trials:[...trialsCleared],sideRewards:[...sideRewards]};try{localStorage.setItem(KEY,JSON.stringify(save))}catch(e){}}
function mapDraw(c,big=false){let ctx=c.getContext('2d');const W=c.width,H=c.height,scale=big?1.24:.49;ctx.clearRect(0,0,W,H);ctx.fillStyle='#244f55';ctx.fillRect(0,0,W,H);const midX=W/2,midY=H/2;function mxy(x,z){return[midX+(x-player.x)*scale,midY+(z-player.z)*scale]}const step=big?12:9;for(let x=0;x<W;x+=step)for(let y=0;y<H;y+=step){let wx=player.x+(x-midX)/scale,wz=player.z+(y-midY)/scale,b=biome(wx,wz),col=b==='lake'?'#447d97':b==='wood'?'#326955':b==='crystal'?'#4c6578':b==='shrine'?'#7c8371':'#5f8b5f';ctx.fillStyle=col;ctx.fillRect(x,y,step+1,step+1)}if(big){ctx.strokeStyle='#ffffff16';for(let x=0;x<W;x+=70){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke()}for(let y=0;y<H;y+=70){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke()}}
 let shrine=mxy(111,-83);ctx.fillStyle='#ffe6a8';ctx.beginPath();ctx.arc(...shrine,big?8:4,0,Math.PI*2);ctx.fill();if(big){ctx.font='bold 12px sans-serif';ctx.fillText('✦ 星の神殿',shrine[0]+12,shrine[1])}
 for(let i=0;i<trialPoints.length;i++){const q=trialPoints[i],xy=mxy(q.x,q.z);ctx.fillStyle=trialsCleared.has(i)?'#93c7b2':'#e5b7fb';ctx.font=(big?'bold 14px':'10px')+' sans-serif';ctx.fillText(trialsCleared.has(i)?'✧':'✦',xy[0],xy[1]);if(big){ctx.fillStyle='#f4e4f4';ctx.font='10px sans-serif';ctx.fillText(q.name,xy[0]+11,xy[1]+2)}}
 const lake=mxy(81,74);if(big){ctx.fillStyle='#d1ecff';ctx.font='11px sans-serif';ctx.fillText('月雫の湖',lake[0],lake[1]-9)}for(let p of pickups){if(p.taken)continue;let xy=mxy(p.x,p.z);ctx.fillStyle=p.kind==='crystal'?'#c69aff':'#ffcc91';ctx.fillRect(xy[0]-2,xy[1]-2,4,4)}for(let m of mobs){if(m.dead)continue;let xy=mxy(m.x,m.z);ctx.beginPath();ctx.arc(...xy,big?3:2,0,Math.PI*2);ctx.fillStyle='#f2b1aa';ctx.fill()}
 ctx.save();ctx.translate(midX,midY);ctx.rotate(player.dir);ctx.fillStyle='#fff7bd';ctx.strokeStyle='#1c3445';ctx.lineWidth=1.4;ctx.beginPath();ctx.moveTo(0,-8);ctx.lineTo(-6,7);ctx.lineTo(0,3);ctx.lineTo(6,7);ctx.closePath();ctx.fill();ctx.stroke();ctx.restore();}
function renderMini(){if(!started)return;mapDraw($('map-canvas'));}
function partyUI(){const list=$('party-list');list.innerHTML='';for(let p of party){let s=SPECIES[p.id],activeNow=p.uid===active,item=document.createElement('div');item.className='pet-entry'+(activeNow?' active':'');const levelNeed=p.level>=5,canEvolve=levelNeed&&shards>=12&&!p.evolved;item.innerHTML=`<div class="portrait"><img src="assets/portraits/${speciesKeys[p.id]}_${p.evolved?'ascended':'young'}.webp" alt="${s.name}"></div><div class="pet-entry-main"><strong>${p.evolved?s.evolved:s.name} ${activeNow?'★':''}</strong><small>${s.type}属性 · Lv.${p.level} · EXP ${p.xp}/${p.level*45}</small><div class="pet-tags">${p.evolved?'✦ 進化済み':'◇ 第1形態'}</div><div class="pet-entry-actions"><button data-pet="${p.uid}" data-act="select" ${activeNow?'disabled':''}>${activeNow?'編成中':'編成'}</button><button data-pet="${p.uid}" data-act="store">控えへ</button><button data-pet="${p.uid}" data-act="train" ${shards<5?'disabled':''}>強化 ✦5</button><button data-pet="${p.uid}" data-act="evolve" ${canEvolve?'':'disabled'}>${p.evolved?'進化済み':`進化 ✦12${!levelNeed?' (Lv.5〜)':''}`}</button></div></div>`;list.appendChild(item)}$('party-foot').textContent='所持：星のかけら '+shards+'個　·　進化条件：Lv.5以上 ＋ かけら12個';}
function openPanel(id){panelOpen=true;paused=true;$('panel-backdrop').classList.remove('hidden');for(let id2 of['party-panel','pause-panel','world-panel','bestiary-panel','storage-panel','shop-panel','settings-panel','quest-panel','story-journal'])$(id2).classList.add('hidden');$(id).classList.remove('hidden');if(id==='party-panel')partyUI();if(id==='settings-panel'){$('btn-sound').textContent=audioEnabled?'BGM・効果音：ON':'BGM・効果音：OFF';$('btn-quality').textContent='画質：'+({auto:'自動',low:'軽量',high:'高画質'}[quality])}if(id==='pause-panel'){$('stat-distance').textContent=Math.floor(totalDistance)+'m';$('stat-caught').textContent=caught;$('stat-kills').textContent=kills;}if(id==='world-panel'){mapDraw($('big-map'),true);renderWarpList()};if(id==='bestiary-panel')showBestiary();if(id==='storage-panel')showStorage();if(id==='shop-panel')refreshShop();if(id==='quest-panel')questUI();if(id==='story-journal')renderStoryArchive()}
function closePanels(){panelOpen=false;paused=false;$('panel-backdrop').classList.add('hidden');for(let id of['party-panel','pause-panel','world-panel','bestiary-panel','storage-panel','shop-panel','settings-panel','quest-panel','story-journal'])$(id).classList.add('hidden');refreshHUD()}
function train(uid){let p=party.find(p=>p.uid===uid);if(!p||shards<5)return;shards-=5;awardPetXp(p,60);toast('✦ '+SPECIES[p.id].name+' を強化！ EXP +60');audioTone(730,.19);partyUI();refreshHUD();persist()}
function evolve(uid){let p=party.find(p=>p.uid===uid);if(!p||p.evolved||p.level<5||shards<12)return;shards-=12;p.evolved=true;evolutions++;addParticles(player.x,h(player.x,player.z)+2,player.z,C.gold,37,'crystal');toast('✧ 進化！ '+SPECIES[p.id].evolved+' が誕生！');showEvolution(p);fanfare();playSound('evolution');partyUI();refreshHUD();persist()}
function showEvolution(p){
 const modal=$('evolution-screen'),id=speciesKeys[p.id],s=SPECIES[p.id];
 $('evo-before').src='assets/portraits/'+id+'_young.webp';$('evo-after').src='assets/portraits/'+id+'_ascended.webp';
 $('evo-before-name').textContent=s.name;$('evo-after-name').textContent=s.evolved;
 modal.classList.remove('hidden');modal.classList.remove('evo-play');void modal.offsetWidth;modal.classList.add('evo-play');
 clearTimeout(showEvolution.timeout);showEvolution.timeout=setTimeout(()=>modal.classList.add('hidden'),5700);
}

// Original narrative, in-game illustrated cinematics and a real pre-rendered MP4 prologue.
// All story flags persist in the same save slot as v4; the saved game remains playable.
const CINEMA_ASSETS=['01_starlight','02_oblivion','03_oath','04_bond'].map(x=>'assets/cinematics/'+x+'.webp');
const STORIES={
 prologue:{chapter:'序章 · 星が消える夜',film:true,slides:[
  {art:0,speaker:'語り部',title:'星に記憶が宿る世界',text:'この大地には、人と星獣の心を結ぶ「星脈」という光が流れていた。'},
  {art:1,speaker:'語り部',title:'忘却の潮',text:'けれど百年前、黒い潮が星脈を断ち切り、星獣たちは大切な記憶を失った。'},
  {art:2,speaker:'星守り セラ',title:'消えなかった最後の灯',text:'「星の印を宿す旅人よ。あなたなら、失われた絆をもう一度結べる」'},
  {art:3,speaker:'語り部',title:'物語は、小さな出会いから',text:'森の星獣モコルだけは、あなたを覚えていた。さあ、星の記憶を取り戻す旅へ。'}
 ]},
 researcher:{chapter:'人物 · 星脈の研究者',slides:[
  {art:2,speaker:'研究者 ミナ',title:'星獣の記憶は、消えていない',text:'「忘却の潮」は記憶を消すのではなく、星晶の中に閉じ込める。そう考えているの。'},
  {art:1,speaker:'研究者 ミナ',title:'三つの光の共鳴',text:'星獣が三体揃えば、異なる星紋が共鳴するはず。彼らを傷つけず、仲間にしてほしい。'},
  {art:0,speaker:'研究者 ミナ',title:'目的地は星の神殿',text:'神殿には星脈の核がある。でも今は封印されている。進化の光が鍵になるかもしれない。'}
 ]},
 resonance:{chapter:'第一章 · 三つの灯',slides:[
  {art:3,speaker:'モコル',title:'重なる星の声',text:'「……モコ！」　三体の星獣が近づいたとき、胸元の星紋が初めて強く輝いた。'},
  {art:0,speaker:'研究者 ミナ',title:'封印を解くための手掛かり',text:'「これが共鳴……！　次は星獣を育てて、進化の力を呼び覚まして。」'},
  {art:1,speaker:'遠くから聞こえる声',title:'神殿が、あなたを呼んでいる',text:'「星の記憶を持つ者よ。忘却に沈む前に、私を見つけてくれ……」'}
 ]},
 ascension:{chapter:'第一章 · 覚醒する星脈',slides:[
  {art:3,speaker:'語り部',title:'変化する絆のかたち',text:'旅を通して築いた絆が光となり、星獣の姿を進化させた。'},
  {art:2,speaker:'星守り セラ',title:'封印の道が開かれた',text:'「その輝きは古の星守りと同じ……。東の星の神殿へ行って。真実はそこにある」'},
  {art:1,speaker:'語り部',title:'次の目的地 · 星の神殿',text:'星脈を乱す謎の守護者が待つ神殿へ。仲間を強化し、装備と回復の準備を整えよう。'}
 ]},
 temple:{chapter:'第一章 · 神殿の真実',slides:[
  {art:1,speaker:'語り部',title:'崩れかけた封印',text:'星の神殿を覆う紫の霧は、星獣の恐怖ではない。外から入り込んだ忘却の潮だった。'},
  {art:0,speaker:'虚空の守護者',title:'守り続けた者の声',text:'「私は敵ではない……。潮をここへ封じた最後の番人だ。だが、もう心が保たぬ」'},
  {art:3,speaker:'モコル',title:'傷つけず、解き放つ',text:'光を取り戻すには、暴走した守護者を鎮めるしかない。仲間の力を合わせて戦おう。'}
 ]},
 finale:{chapter:'第一章 完結 · 星明かりの約束',slides:[
  {art:1,speaker:'虚空の守護者',title:'砕けた黒い鎖',text:'守護者を覆っていた闇がほどけ、星の神殿に百年ぶりの光が戻った。'},
  {art:0,speaker:'虚空の守護者',title:'神殿の奥に隠されていた真実',text:'「忘却の潮は、ここから生まれたのではない。北の『沈黙の星図』から流れ込んだのだ」'},
  {art:2,speaker:'研究者 ミナ',title:'旅は、まだ終わらない',text:'「星の記憶を一つ取り戻せた。でも消えた星座は、まだ空にたくさんある」'},
  {art:3,speaker:'語り部',title:'第一章クリア · 次の星を目指して',text:'あなたと星獣の絆が、世界に初めての光を返した。第二章へと続く手掛かりが残された。'}
 ]}
};
let storyLastTime=0,storySlides=null;
function renderStoryArchive(){let el=$('story-archive');if(!el)return;const order=['prologue','researcher','resonance','ascension','temple','finale'];el.innerHTML=order.map((key,i)=>{let s=STORIES[key],isReady=storySeen.has(key),isPrologue=key==='prologue';return '<div class="story-archive-row '+(isReady?'seen':'')+'"><div><small>EPISODE '+String(i).padStart(2,'0')+'</small><b>'+(isReady||isPrologue?s.chapter:'？？？ · 未解放')+'</b><span>'+(isReady?'映像の記録を見返せます':isPrologue?'世界の始まりを知る':'冒険を進めると解放')+'</span></div><button data-story="'+key+'" '+(isReady||isPrologue?'':'disabled')+'>再生 ▶</button></div>'}).join('')}
function storySlide(id,index){const spec=STORIES[id];if(!spec)return;storyIndex=clamp(index,0,spec.slides.length-1);const s=spec.slides[storyIndex],paint=$('story-paint');$('story-chapter').textContent=spec.chapter;$('story-speaker').textContent=s.speaker;$('story-title').textContent=s.title;$('story-text').textContent=s.text;$('story-counter').textContent=String(storyIndex+1).padStart(2,'0')+' / '+String(spec.slides.length).padStart(2,'0');$('story-dots').innerHTML=spec.slides.map((_,i)=>'<i class="'+(i===storyIndex?'active':'')+'"></i>').join('');$('story-next').textContent=storyIndex===spec.slides.length-1?'冒険にもどる ›':'次へ ›';if(!spec.film||storyVideoFailed){paint.classList.remove('hidden');paint.style.backgroundImage='url("'+CINEMA_ASSETS[s.art]+'")';paint.classList.remove('story-pan');void paint.offsetWidth;paint.classList.add('story-pan')}}
function showStory(id,replay=false){let spec=STORIES[id];if(!started||!spec||storyPlaying||(!replay&&storySeen.has(id)))return; if(panelOpen)closePanels();storyPlaying=true;storyId=id;storyReplay=replay;storyVideoFailed=false;storyIndex=0;storyLastTime=0;const box=$('story-cinema'),film=$('story-film'),paint=$('story-paint');box.classList.remove('hidden');$('hud').classList.add('cinematic-hud');film.pause();film.currentTime=0;film.classList.toggle('hidden',!spec.film);paint.classList.toggle('hidden',!!spec.film);storySlide(id,0);let bgm=$('bgm');if(bgm)bgm.volume=.065;if(spec.film){film.play().catch(()=>{if(storyPlaying&&storyId===id){storyVideoFailed=true;film.classList.add('hidden');storySlide(id,0)}})};}
function completeStory(){if(!storyPlaying)return;const id=storyId;storyPlaying=false;storyId=null;const film=$('story-film');film.pause();$('story-cinema').classList.add('hidden');$('hud').classList.remove('cinematic-hud');const bgm=$('bgm');if(bgm)bgm.volume=.18;if(id&&!storyReplay){storySeen.add(id);persist();}storyReplay=false;if(id==='prologue'){toast('✦ 第一章　星脈の目覚め');setTimeout(()=>{if(started&&!storyPlaying)toast('目標：仲間を3体にして星紋を共鳴させよう')},1650)}else if(id==='resonance'){toast('✧ 次の目標：星獣をLv.5まで育て、進化させよう')}else if(id==='ascension'){toast('✧ 次の目標：東の星の神殿に向かおう')}else if(id==='finale'){toast('✦ 第一章クリア！　冒険記録で物語を振り返れます')}refreshHUD();}
function nextStorySlide(){if(!storyPlaying)return;const spec=STORIES[storyId];if(storyIndex>=spec.slides.length-1){completeStory();return;}let n=storyIndex+1;if(spec.film&&!storyVideoFailed){let film=$('story-film');try{film.currentTime=n*4.8+.02;film.play().catch(()=>{})}catch(e){} }storySlide(storyId,n)}
function initStoryControls(){const film=$('story-film');$('story-next').addEventListener('click',nextStorySlide);$('story-skip').addEventListener('click',completeStory);film.addEventListener('timeupdate',()=>{if(!storyPlaying||storyId!=='prologue'||storyVideoFailed)return;const index=Math.min(3,Math.floor(Math.max(0,film.currentTime)/4.8));if(index!==storyIndex)storySlide('prologue',index)});film.addEventListener('ended',()=>{if(storyPlaying&&storyId==='prologue'){$('story-next').textContent='冒険を始める ›'}});film.addEventListener('error',()=>{if(storyPlaying&&storyId==='prologue'){storyVideoFailed=true;film.classList.add('hidden');storySlide('prologue',storyIndex)}});window.addEventListener('keydown',e=>{if(!storyPlaying)return;if(e.code==='Escape')completeStory();if(e.code==='Enter'||e.code==='Space'){e.preventDefault();nextStorySlide()}})}

function wireUI(){const buttons=[['btn-jump',jump],['btn-sprint',toggleSprint],['btn-attack',attack],['btn-catch',catchMob],['btn-dodge',dodge],['btn-pet',switchPet],['party-open',()=>openPanel('party-panel')],['menu-toggle',()=>openPanel('pause-panel')],['map-toggle',()=>openPanel('world-panel')],['menu-party',()=>openPanel('party-panel')],['menu-heal',()=>{if(shards>=5){shards-=5;player.hp=maxHp();addParticles(player.x,h(player.x,player.z)+1,player.z,C.leaf2,16);toast('✧ HPを全回復しました');refreshHUD();persist()}else toast('星のかけらが5個必要です','warn')}],['menu-save',()=>{persist();toast('▣ 冒険の記録を保存しました');closePanels()}],['menu-reset',()=>{$('confirm-reset').classList.remove('hidden')}],['reset-no',()=>{$('confirm-reset').classList.add('hidden')}],['reset-yes',()=>{try{localStorage.removeItem(KEY)}catch(e){}location.reload()}]];for(const[id,fn]of buttons)$(id).addEventListener('click',fn);document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',closePanels));$('panel-backdrop').addEventListener('click',closePanels);
 $('party-list').addEventListener('click',e=>{const button=e.target.closest('button[data-pet]');if(!button)return;let uid=Number(button.dataset.pet),act=button.dataset.act;if(act==='train')train(uid);if(act==='evolve')evolve(uid);if(act==='select'){active=uid;partyUI();refreshHUD();toast('仲間を交代しました');persist()}});
 const joy=$('joystick-area'),knob=$('joystick-knob');function moveJoy(e){let r=joy.getBoundingClientRect(),dx=e.clientX-(r.left+r.width/2),dy=e.clientY-(r.top+r.height/2),radius=42,d=Math.min(radius,Math.hypot(dx,dy)),ang=Math.atan2(dy,dx);joystick.x=Math.cos(ang)*d/radius;joystick.y=Math.sin(ang)*d/radius;knob.style.transform=`translate(${joystick.x*36}px,${joystick.y*36}px)`}joy.addEventListener('pointerdown',e=>{e.preventDefault();joy.setPointerCapture(e.pointerId);joystick.active=true;joystick.pointer=e.pointerId;moveJoy(e)});joy.addEventListener('pointermove',e=>{if(joystick.active&&joystick.pointer===e.pointerId){e.preventDefault();moveJoy(e)}});function joyEnd(e){if(joystick.pointer!==e.pointerId)return;joystick.x=0;joystick.y=0;joystick.active=false;joystick.pointer=null;knob.style.transform='translate(0,0)'}joy.addEventListener('pointerup',joyEnd);joy.addEventListener('pointercancel',joyEnd);
 canvas.addEventListener('pointerdown',e=>{if(!started||panelOpen||storyPlaying)return;drag.on=true;drag.pointer=e.pointerId;drag.x=e.clientX;drag.y=e.clientY;canvas.setPointerCapture(e.pointerId)});canvas.addEventListener('pointermove',e=>{if(!drag.on||drag.pointer!==e.pointerId)return;let dx=e.clientX-drag.x;yaw-=dx*.0048;drag.x=e.clientX;cameraTilt=clamp(cameraTilt+(e.clientY-drag.y)*.035,-3.8,7.5);drag.y=e.clientY});['pointerup','pointercancel','lostpointercapture'].forEach(evt=>canvas.addEventListener(evt,e=>{if(e.pointerId===drag.pointer)drag.on=false}));
 window.addEventListener('keydown',e=>{if(['Space','Tab','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();keys.add(e.code);if(!started||e.repeat||storyPlaying)return;if(e.code==='Space'||e.code==='KeyJ')attack();if(e.code==='KeyK')catchMob();if(e.code==='KeyE')dodge();if(e.code==='KeyR')jump();if(e.code==='KeyQ')switchPet();if(e.code==='Tab')panelOpen?closePanels():openPanel('party-panel');if(e.code==='Escape')panelOpen?closePanels():openPanel('pause-panel')});window.addEventListener('keyup',e=>keys.delete(e.code));window.addEventListener('blur',()=>{keys.clear();joystick.x=0;joystick.y=0;joystick.active=false;knob.style.transform='translate(0,0)'});
 document.addEventListener('visibilitychange',()=>{if(document.hidden)persist()});window.addEventListener('pagehide',persist);window.addEventListener('visibilitychange',()=>{let b=$('bgm');if(document.hidden)b.pause();else if(started&&audioEnabled)initBgm()});

 $('btn-skill').addEventListener('click',useSkill);$('quest-line').addEventListener('click',()=>openPanel('quest-panel'));$('quest-line').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();openPanel('quest-panel')}});$('menu-quest').addEventListener('click',()=>openPanel('quest-panel'));$('menu-story').addEventListener('click',()=>openPanel('story-journal'));$('story-archive').addEventListener('click',e=>{let b=e.target.closest('button[data-story]');if(b)showStory(b.dataset.story,true)});$('side-quest-list').addEventListener('click',e=>{let b=e.target.closest('button[data-reward]');if(b)claimSideReward(b.dataset.reward)});
 $('btn-interact').addEventListener('click',interact);
 $('menu-export').addEventListener('click',()=>exportSave());
 $('menu-import').addEventListener('click',()=>$('import-save-file').click());
 $('import-save-file').addEventListener('change',e=>importSaveFile(e.target.files?.[0]));
 $('menu-dex').addEventListener('click',()=>openPanel('bestiary-panel'));
 $('menu-storage').addEventListener('click',()=>openPanel('storage-panel'));
 $('menu-settings').addEventListener('click',()=>openPanel('settings-panel'));
 $('btn-sound').addEventListener('click',()=>{audioEnabled=!audioEnabled;$('btn-sound').textContent=audioEnabled?'BGM・効果音：ON':'BGM・効果音：OFF';const b=$('bgm');if(audioEnabled)initBgm();else b.pause();persist()});
 $('btn-quality').addEventListener('click',()=>{quality=quality==='auto'?'low':quality==='low'?'high':'auto';syncChunks();$('btn-quality').textContent='画質：'+({auto:'自動',low:'軽量',high:'高画質'}[quality]);persist()});
 $('storage-list').addEventListener('click',e=>{let b=e.target.closest('button[data-box]');if(!b)return;if(party.length>=6){toast('編成は最大6体です。先に1体を控えへ移してください','warn');return}let i=box.findIndex(p=>p.uid===Number(b.dataset.box));if(i<0)return;party.push(box.splice(i,1)[0]);showStorage();toast('編成に追加しました');persist()});
 $('party-list').addEventListener('click',e=>{let b=e.target.closest('button[data-pet]');if(!b||b.dataset.act!=='store')return;if(party.length<=1){toast('最低1体は編成に必要です','warn');return}let i=party.findIndex(p=>p.uid===Number(b.dataset.pet));if(i<0)return;let removed=party.splice(i,1)[0];box.push(removed);if(removed.uid===active)active=party[0].uid;partyUI();refreshHUD();persist()});
 $('shop-details').addEventListener('click',e=>{let b=e.target.closest('button[data-buy]');if(b)doShop(b.dataset.buy)});
 $('warp-list').addEventListener('click',e=>{let b=e.target.closest('button[data-warp]');if(b)warpTo(Number(b.dataset.warp))});
 window.addEventListener('keydown',e=>{if(!started||e.repeat||storyPlaying)return;if(e.code==='KeyL')useSkill();if(e.code==='KeyF')interact();if(e.code==='KeyB')openPanel('bestiary-panel');if(e.code==='KeyM')openPanel('quest-panel')});
 $('evo-close').addEventListener('click',()=>{clearTimeout(showEvolution.timeout);$('evolution-screen').classList.add('hidden');if(!storySeen.has('ascension')){closePanels();setTimeout(()=>showStory('ascension'),200)}});$('start-button').addEventListener('click',startGame);}
async function startGame(){if(started)return;try{audio??=new(window.AudioContext||window.webkitAudioContext)();audio.resume();initBgm()}catch(e){}const btn=$('start-button');btn.disabled=true;btn.textContent='3D世界を読み込んでいます…';$('loading-track').classList.remove('hidden');try{await loadAdvancedModels()}catch(error){console.warn('オリジナル3D読み込み失敗。簡易モデルに切替',error)}started=true;$('splash').classList.add('hidden');$('hud').classList.remove('hidden');camX=player.x;camZ=player.z+12;camY=h(player.x,player.z)+9;player.dir=0;syncChunks();mobs.push(spawnMob(-7,-16,1,1),spawnMob(12,-23,2,2),spawnMob(17,9,3,2),spawnMob(-14,-11,0,1));spawnWorld();spawnPickups();boss={boss:true,x:111,z:-83,hp:950,maxHp:950,level:12,dead:bossDefeated,attack:0,windup:0,flash:0};generateModels();initSceneProps();refreshHUD();refreshSkillButton();if(storySeen.has('prologue')){toast('✦ 星獣を3体仲間にし、星脈を呼び覚まそう');setTimeout(()=>toast('◈ 敵を弱らせると捕獲しやすくなります'),2700)}try{if(screen.orientation?.lock)await screen.orientation.lock('landscape')}catch(e){}try{audio??=new(window.AudioContext||window.webkitAudioContext)();audio.resume();initBgm()}catch(e){}lastFrame=performance.now();requestAnimationFrame(loop);if(!storySeen.has('prologue'))setTimeout(()=>showStory('prologue'),350)}
let lastFrame=0;function loop(frame){if(!started)return;let dt=clamp((frame-lastFrame)/1000,0,.055);lastFrame=frame;perfFrames++;perfTimer+=dt;if(perfTimer>=3){perfFps=Math.round(perfFrames/perfTimer);perfFrames=0;perfTimer=0;if(quality==='auto'){if(perfFps<33)autoResolution=Math.max(.85,autoResolution-.1);else if(perfFps>55)autoResolution=Math.min(1.4,autoResolution+.04)}const info=$('performance-label');if(info)info.textContent='描画：'+perfFps+' fps · 解像度倍率 '+(quality==='auto'?autoResolution.toFixed(2):quality==='low'?'.95':'1.70');}if(!document.hidden){update(dt);render();if(renderCount++%6===0)renderMini()}requestAnimationFrame(loop)}
canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();try{persist()}catch(err){}},false);canvas.addEventListener('webglcontextrestored',()=>location.reload(),false);wireUI();initStoryControls();window.addEventListener('resize',resize);resize();window.LumoriaDebug={status:()=>({started,hasAdvanced,monsters:mobs.length,party:party.length,box:box.length,loading:!!$('loading-progress'),hp:player.hp,x:player.x,z:player.z,skillTimer,forageCount,trials:trialsCleared.size,sideRewards:sideRewards.size,perfFps,storyPlaying,storyId,storyIndex,storySeen:[...storySeen]}),interact,showStory,skipStory:completeStory,storyNext:nextStorySlide,skill:useSkill,attack,catch:catchMob,save:persist,warpTo,openPanel};
if('serviceWorker' in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('./sw.js').catch(()=>{});
})();
