extends Node3D
## Smoothed shoulder camera, keeps same world-space basis used by the joystick.
var target: Node3D
var eye: Camera3D
var yaw: float = 0.0
var elevation: float = 0.27
var distance: float = 6.3
var look_target: Vector3 = Vector3.ZERO

func _ready() -> void:
    eye = Camera3D.new()
    eye.name = "ThirdPersonCamera"
    eye.current = true
    eye.fov = 66.0
    eye.near = 0.075
    eye.far = 280.0
    add_child(eye)

func _process(delta: float) -> void:
    if target == null or eye == null:
        return
    var anchor: Vector3 = target.global_position + Vector3.UP * 1.65
    look_target = look_target.lerp(anchor, 1.0 - exp(-delta * 12.0))
    var offset: Vector3 = Vector3(sin(yaw) * cos(elevation), sin(elevation), cos(yaw) * cos(elevation)) * distance
    var desired: Vector3 = look_target + offset
    # Camera wall avoidance: excludes the player's own collision body.
    var query: PhysicsRayQueryParameters3D = PhysicsRayQueryParameters3D.create(look_target, desired)
    if target is CollisionObject3D:
        query.exclude = [(target as CollisionObject3D).get_rid()]
    var hit: Dictionary = get_world_3d().direct_space_state.intersect_ray(query)
    if not hit.is_empty():
        desired = look_target.lerp(hit["position"], 0.89)
    eye.global_position = eye.global_position.lerp(desired, 1.0 - exp(-delta * 14.0))
    eye.look_at(look_target, Vector3.UP)

func rotate_look(delta_xy: Vector2) -> void:
    yaw -= delta_xy.x * 0.006
    elevation = clampf(elevation + delta_xy.y * 0.004, 0.06, 1.0)
