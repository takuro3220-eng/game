extends CharacterBody3D
## Third-person kinetic controller. Camera-relative stick forward is always screen-forward.
signal attack_hit(origin: Vector3, direction: Vector3, damage: int, distance: float, arc: float, kind: String)
signal cast_projectile(origin: Vector3, direction: Vector3, damage: int)
signal dodged

const WALK_SPEED: float = 6.25
const RUN_ACCEL: float = 16.0
const GRAVITY: float = 24.0
var input_axis: Vector2 = Vector2.ZERO
var camera_ref: Camera3D
var model_root: Node3D
var animation_player: AnimationPlayer
var anim_id: String = ""
var last_direction: Vector3 = Vector3.FORWARD
var busy_time: float = 0.0
var dodge_time: float = 0.0
var invulnerable: float = 0.0
var combo: int = 0
var combo_window: float = 0.0
var defeated: bool = false
var control_locked: bool = false

func _ready() -> void:
    name = "PlayableHero"
    collision_layer = 2
    collision_mask = 1
    var c: CollisionShape3D = CollisionShape3D.new()
    var shape: CapsuleShape3D = CapsuleShape3D.new()
    shape.radius = 0.37
    shape.height = 2.1
    c.position = Vector3(0, 1.05, 0)
    c.shape = shape
    add_child(c)
    model_root = Node3D.new()
    model_root.name = "Visual"
    add_child(model_root)
    set_hero(str(GameData.get_value("hero", "aster")))

func set_hero(hero: String) -> void:
    if model_root == null:
        return
    for child in model_root.get_children():
        child.queue_free()
    animation_player = null
    var path: String = "res://assets/models/characters/lyra.glb" if hero == "lyra" else "res://assets/models/characters/aster.glb"
    var prefab: PackedScene = load(path) as PackedScene
    if prefab != null:
        var visual: Node3D = prefab.instantiate() as Node3D
        model_root.add_child(visual)
        visual.scale = Vector3.ONE * 0.77
        animation_player = visual.find_child("AnimationPlayer", true, false) as AnimationPlayer
    else:
        var capsule: MeshInstance3D = MeshInstance3D.new()
        var m: CapsuleMesh = CapsuleMesh.new()
        m.radius = 0.4
        m.height = 1.9
        capsule.mesh = m
        capsule.position.y = 1.0
        model_root.add_child(capsule)
    anim_id = ""
    _play_anim("Idle")

func _physics_process(delta: float) -> void:
    if defeated:
        return
    busy_time = maxf(busy_time - delta, 0.0)
    combo_window = maxf(combo_window - delta, 0.0)
    invulnerable = maxf(invulnerable - delta, 0.0)
    dodge_time = maxf(dodge_time - delta, 0.0)
    var keys: Vector2 = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
    var axis: Vector2 = input_axis if input_axis.length_squared() > 0.003 else keys
    var wanted: Vector3 = Vector3.ZERO
    if camera_ref != null:
        var forward: Vector3 = -camera_ref.global_transform.basis.z
        var right: Vector3 = camera_ref.global_transform.basis.x
        forward.y = 0
        right.y = 0
        wanted = right.normalized() * axis.x + forward.normalized() * -axis.y
    else:
        wanted = Vector3(axis.x, 0, axis.y)
    wanted = wanted.limit_length(1.0)
    if control_locked:
        wanted = Vector3.ZERO
    if wanted.length() > 0.06:
        last_direction = wanted.normalized()
        var facing: float = atan2(-last_direction.x, -last_direction.z)
        model_root.rotation.y = lerp_angle(model_root.rotation.y, facing, minf(1.0, delta * 12.0))
    var target_speed: float = WALK_SPEED * wanted.length()
    if busy_time > 0:
        target_speed *= 0.25
    if dodge_time > 0:
        velocity.x = last_direction.x * 12.0
        velocity.z = last_direction.z * 12.0
    else:
        velocity.x = move_toward(velocity.x, wanted.x * target_speed, delta * RUN_ACCEL)
        velocity.z = move_toward(velocity.z, wanted.z * target_speed, delta * RUN_ACCEL)
    if not is_on_floor():
        velocity.y -= GRAVITY * delta
    elif velocity.y < 0:
        velocity.y = -0.1
    move_and_slide()
    if dodge_time > 0:
        _play_anim("Dodge")
    elif busy_time > 0:
        pass
    elif not is_on_floor():
        _play_anim("Jump")
    elif wanted.length() > 0.1:
        _play_anim("Run")
    else:
        _play_anim("Idle")

func _anim_name(clip: String) -> StringName:
    if animation_player == null:
        return &""
    for found in animation_player.get_animation_list():
        var item: String = str(found)
        if item == clip or item.ends_with("/" + clip):
            return StringName(item)
    return &""

func _play_anim(clip: String, reset: bool = false) -> void:
    if animation_player == null:
        return
    if anim_id == clip and not reset:
        return
    var imported: StringName = _anim_name(clip)
    if imported == &"":
        return
    if clip == "Idle" or clip == "Run":
        var a: Animation = animation_player.get_animation(imported)
        if a != null:
            a.loop_mode = Animation.LOOP_LINEAR
    animation_player.play(imported, 0.14)
    anim_id = clip

func action(id: String) -> bool:
    if defeated or control_locked:
        return false
    match id:
        "attack":
            if busy_time > 0.08 or dodge_time > 0:
                return false
            combo = (combo % 3 + 1) if combo_window > 0 else 1
            combo_window = 0.94
            busy_time = 0.32
            _play_anim("Attack" + str(combo), true)
            attack_hit.emit(global_position + Vector3.UP, last_direction, 14 + combo * 5 + int(GameData.get_value("weapon", 1)) * 4 + int(GameData.get_value("level", 1)) * 2, 3.1, 0.43, "sword")
            return true
        "skill":
            if busy_time > 0 or not GameData.spend_mp(18):
                return false
            busy_time = 0.72
            _play_anim("Attack3", true)
            attack_hit.emit(global_position + Vector3.UP, last_direction, 42 + int(GameData.get_value("level", 1)) * 4, 4.0, -0.9, "sweep")
            return true
        "magic":
            if busy_time > 0 or not GameData.spend_mp(12):
                return false
            busy_time = 0.55
            _play_anim("Cast", true)
            cast_projectile.emit(global_position + Vector3.UP * 1.2, last_direction, 26 + int(GameData.get_value("level", 1)) * 5)
            return true
        "dodge":
            if dodge_time > 0 or busy_time > 0.15:
                return false
            dodge_time = 0.30
            invulnerable = 0.45
            busy_time = 0.32
            _play_anim("Dodge", true)
            dodged.emit()
            return true
        "jump":
            if is_on_floor() and busy_time <= 0:
                velocity.y = 8.0
                _play_anim("Jump", true)
                return true
    return false

func receive_damage(amount: int) -> bool:
    if invulnerable > 0 or defeated:
        return false
    GameData.lose_hp(amount)
    busy_time = 0.27
    _play_anim("Hit", true)
    if int(GameData.get_value("hp", 0)) <= 0:
        defeated = true
    return true

func revive() -> void:
    GameData.state["hp"] = GameData.state["max_hp"]
    GameData.state["mp"] = GameData.state["max_mp"]
    GameData.changed.emit()
    defeated = false
    busy_time = 0.0
    global_position = Vector3(0, 5, 18)
