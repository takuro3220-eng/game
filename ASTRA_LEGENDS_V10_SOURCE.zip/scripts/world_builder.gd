extends Node3D
## Streamable-world foundation: deterministic terrain, instanced foliage, authored GLB landmarks.
## Hero/collision/game systems are separate from world art assets.

const WORLD_HALF = 92.0
var rng := RandomNumberGenerator.new()
var npc_spots: Array[Dictionary] = []
var chest_spots: Array[Dictionary] = []
var music_source: String = "res://assets/audio/celestial_theme.ogg"
var elapsed: float = 0.0
var sun: DirectionalLight3D

func _ready() -> void:
    rng.seed = 9827331
    _lighting()
    _terrain()
    _village()
    _forest()
    _lake()
    _ruins()
    _spawn_points()

func _process(delta: float) -> void:
    elapsed += delta
    # Slow atmospheric day cycle, kept bright enough for navigation.
    if sun != null:
        sun.rotation.x = -0.85 + sin(elapsed * 0.002) * 0.16
        sun.light_energy = 1.15 + sin(elapsed * 0.002) * 0.12

func ground_y(x: float, z: float) -> float:
    var ridge: float = 1.2 * sin(x * 0.039) * cos(z * 0.038) + 0.31 * sin(x * 0.16) * cos(z * 0.12)
    var road_flat: float = smoothstep(3.0, 17.0, absf(x))
    if z > -74.0 and z < 34.0:
        ridge *= lerpf(0.25, 1.0, road_flat)
    # Lake basin with a shoreline instead of surface floating above the earth.
    var lake_d: float = Vector2(x - 42.0, z + 13.0).length()
    ridge -= (1.0 - smoothstep(14.0, 24.0, lake_d)) * 2.8
    return ridge

func _lighting() -> void:
    var env: WorldEnvironment = WorldEnvironment.new()
    env.name = "Atmosphere"
    var e: Environment = Environment.new()
    e.background_mode = Environment.BG_SKY
    var sky: Sky = Sky.new()
    var sky_mat: ProceduralSkyMaterial = ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color("568dbf")
    sky_mat.sky_horizon_color = Color("c2e1e6")
    sky_mat.ground_bottom_color = Color("405769")
    sky_mat.ground_horizon_color = Color("abc59a")
    sky.sky_material = sky_mat
    e.sky = sky
    e.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    e.reflected_light_source = Environment.REFLECTION_SOURCE_BG
    e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    e.fog_enabled = true
    e.fog_light_color = Color("b0c7bd")
    e.fog_density = 0.006
    env.environment = e
    add_child(env)
    sun = DirectionalLight3D.new()
    sun.name = "Sun"
    sun.rotation = Vector3(-0.95, -0.72, 0.0)
    sun.light_color = Color("fff2d3")
    sun.light_energy = 1.25
    sun.shadow_enabled = true
    add_child(sun)

func _mat(color: Color, roughness: float = 0.92, emission: bool = false) -> StandardMaterial3D:
    var mat: StandardMaterial3D = StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = roughness
    if emission:
        mat.emission_enabled = true
        mat.emission = color
        mat.emission_energy_multiplier = 1.8
    return mat

func _mesh(mesh: PrimitiveMesh, pos: Vector3, mat: Material, parent: Node3D = null) -> MeshInstance3D:
    var mesh_inst: MeshInstance3D = MeshInstance3D.new()
    mesh_inst.mesh = mesh
    mesh_inst.material_override = mat
    mesh_inst.position = pos
    if parent == null:
        add_child(mesh_inst)
    else:
        parent.add_child(mesh_inst)
    return mesh_inst

func _box(size: Vector3, pos: Vector3, color: Color, parent: Node3D = null) -> MeshInstance3D:
    var m: BoxMesh = BoxMesh.new()
    m.size = size
    return _mesh(m, pos, _mat(color), parent)

func _cone(radius: float, height: float, pos: Vector3, color: Color, parent: Node3D = null) -> MeshInstance3D:
    var m: CylinderMesh = CylinderMesh.new()
    m.top_radius = 0.0
    m.bottom_radius = radius
    m.height = height
    m.radial_segments = 8
    return _mesh(m, pos, _mat(color), parent)

func _cylinder(radius: float, height: float, pos: Vector3, color: Color, parent: Node3D = null) -> MeshInstance3D:
    var m: CylinderMesh = CylinderMesh.new()
    m.top_radius = radius
    m.bottom_radius = radius
    m.height = height
    m.radial_segments = 10
    return _mesh(m, pos, _mat(color), parent)

func _asset(path: String, pos: Vector3, scale_factor: float, rot: float = 0.0) -> Node3D:
    var anchor: Node3D = Node3D.new()
    anchor.position = pos
    anchor.rotation.y = rot
    anchor.scale = Vector3.ONE * scale_factor
    add_child(anchor)
    var pack: PackedScene = load(path) as PackedScene
    if pack != null:
        var instance: Node = pack.instantiate()
        anchor.add_child(instance)
    return anchor

func _terrain() -> void:
    var st: SurfaceTool = SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    var steps: int = 48
    var unit: float = WORLD_HALF / float(steps)
    for iz in range(-steps, steps):
        for ix in range(-steps, steps):
            var x: float = float(ix) * unit
            var z: float = float(iz) * unit
            var a: Vector3 = Vector3(x, ground_y(x, z), z)
            var b: Vector3 = Vector3(x + unit, ground_y(x + unit, z), z)
            var c: Vector3 = Vector3(x, ground_y(x, z + unit), z + unit)
            var d: Vector3 = Vector3(x + unit, ground_y(x + unit, z + unit), z + unit)
            _terrain_vertex(st, a)
            _terrain_vertex(st, c)
            _terrain_vertex(st, b)
            _terrain_vertex(st, b)
            _terrain_vertex(st, c)
            _terrain_vertex(st, d)
    st.generate_normals()
    var array_mesh: ArrayMesh = st.commit()
    var mat: StandardMaterial3D = _mat(Color.WHITE)
    mat.vertex_color_use_as_albedo = true
    mat.albedo_texture = load("res://assets/textures/grass.png") as Texture2D
    mat.roughness = 1.0
    var ground: MeshInstance3D = MeshInstance3D.new()
    ground.name = "WalkableTerrain"
    ground.mesh = array_mesh
    ground.material_override = mat
    add_child(ground)
    var body: StaticBody3D = StaticBody3D.new()
    body.name = "TerrainCollision"
    add_child(body)
    var col: CollisionShape3D = CollisionShape3D.new()
    col.shape = array_mesh.create_trimesh_shape()
    body.add_child(col)

func _terrain_vertex(st: SurfaceTool, p: Vector3) -> void:
    var shade: float = 0.88 + 0.12 * sin(p.x * 0.48 + p.z * 0.29)
    var road: bool = absf(p.x) < 3.0 and p.z < 34.0 and p.z > -76.0
    var c: Color = Color("9aa991") if road else Color("457b4c")
    if p.y > 0.9:
        c = c.lerp(Color("93a86e"), 0.29)
    st.set_color(c * shade)
    st.set_uv(Vector2(p.x / 12.0, p.z / 12.0))
    st.add_vertex(p)

func _solid_box(size: Vector3, pos: Vector3) -> void:
    var body: StaticBody3D = StaticBody3D.new()
    body.position = pos
    add_child(body)
    var c: CollisionShape3D = CollisionShape3D.new()
    var s: BoxShape3D = BoxShape3D.new()
    s.size = size
    c.shape = s
    body.add_child(c)

func _village() -> void:
    # Authored landmark GLB with collision shell. Other props are mobile-friendly kit pieces.
    _asset("res://assets/models/environment/star_lantern_inn.glb", Vector3(13.0, ground_y(13.0, 32.0), 32.0), 1.0, 0.42)
    _solid_box(Vector3(6.0, 7.0, 6.0), Vector3(13.0, ground_y(13.0, 32.0) + 3.5, 32.0))
    _asset("res://assets/models/environment/moonforest_gate.glb", Vector3(0.0, ground_y(0.0, -1.0), -1.0), 1.1)
    for i in range(7):
        var z: float = 25.0 + float(i % 4) * 7.0
        var x: float = (-14.0 if i % 2 == 0 else 15.5) + float(i % 3)
        var y: float = ground_y(x, z)
        var house: Node3D = Node3D.new()
        house.position = Vector3(x, y, z)
        add_child(house)
        _box(Vector3(5.0, 3.6, 5.2), Vector3(0, 1.8, 0), Color("e3d1a9"), house)
        _cone(4.15, 2.65, Vector3(0, 4.45, 0), Color("9b493d"), house)
        _box(Vector3(0.9, 2.0, 0.17), Vector3(0, 0.99, 2.68), Color("66442d"), house)
        _solid_box(Vector3(5, 3.5, 5), house.global_position + Vector3(0, 1.75, 0))
    # Native stone road segments following world elevation.
    for i in range(44):
        var z: float = 31.0 - float(i) * 2.42
        for j in range(3):
            var x: float = (float(j) - 1.0) * 2.0
            _box(Vector3(1.82, 0.12, 2.2), Vector3(x, ground_y(x, z) + 0.055, z), Color("abb5a2"))
    _cylinder(3.2, 0.5, Vector3(-3.0, ground_y(-3, 29) + 0.24, 29.0), Color("7d8d88"))
    _cylinder(1.0, 2.9, Vector3(-3.0, ground_y(-3, 29) + 1.55, 29.0), Color("ded9bc"))
    _cone(2.6, 2.8, Vector3(-3.0, ground_y(-3, 29) + 4.25, 29.0), Color("5ba1c4"))

func _tree(x: float, z: float, factor: float) -> void:
    var base: float = ground_y(x, z)
    var root: Node3D = Node3D.new()
    root.position = Vector3(x, base, z)
    root.scale = Vector3.ONE * factor
    add_child(root)
    _cylinder(0.32, 4.4, Vector3(0, 2.2, 0), Color("635443"), root)
    _cone(2.1, 4.5, Vector3(0, 5.15, 0), Color("35785d"), root)
    _cone(1.65, 3.65, Vector3(0, 7.0, 0), Color("408b68"), root)
    _cone(1.05, 2.8, Vector3(0, 8.65, 0), Color("6cab78"), root)

func _forest() -> void:
    # Four instanced components for the whole forest: drastically fewer draw calls
    # than the one-Node-per-tree prototype. World layout stays deterministic.
    var sites: Array[Dictionary] = []
    for i in range(145):
        var x: float = rng.randf_range(-80.0, 80.0)
        var z: float = rng.randf_range(-76.0, 73.0)
        if absf(x) < 10.0 or (z > 20.0 and absf(x) < 26.0):
            continue
        if Vector2(x - 42.0, z + 13.0).length() < 25.0:
            continue
        sites.append({"base": Vector3(x, ground_y(x, z), z), "size": rng.randf_range(0.70, 1.30)})
    var trunk: CylinderMesh = CylinderMesh.new()
    trunk.top_radius = 0.28
    trunk.bottom_radius = 0.37
    trunk.height = 4.4
    trunk.radial_segments = 7
    _forest_instances(trunk, Color("665341"), sites, 2.2)
    for spec in [
        [2.15, 4.5, 5.15, "327758"],
        [1.65, 3.65, 7.0, "438e64"],
        [1.05, 2.8, 8.65, "80ae74"]
    ]:
        var canopy: CylinderMesh = CylinderMesh.new()
        canopy.top_radius = 0.0
        canopy.bottom_radius = float(spec[0])
        canopy.height = float(spec[1])
        canopy.radial_segments = 8
        _forest_instances(canopy, Color(str(spec[3])), sites, float(spec[2]))
    # Heroic trees remain individually authored GLB assets.
    _asset("res://assets/models/environment/ancient_silverleaf.glb", Vector3(-27.0, ground_y(-27.0, -21.0), -21.0), 1.5)
    _asset("res://assets/models/environment/ancient_silverleaf.glb", Vector3(25.0, ground_y(25.0, -35.0), -35.0), 1.3)
    var rocks: Array[Dictionary] = []
    for i in range(53):
        var x: float = rng.randf_range(-75.0, 75.0)
        var z: float = rng.randf_range(-75.0, 70.0)
        var factor: float = rng.randf_range(0.45, 1.55)
        rocks.append({"base": Vector3(x, ground_y(x, z), z), "size": factor})
    var stone: SphereMesh = SphereMesh.new()
    stone.radius = 0.7
    stone.height = 1.0
    stone.radial_segments = 8
    stone.rings = 5
    _forest_instances(stone, Color("748481"), rocks, 0.42)

func _forest_instances(mesh: Mesh, color: Color, sites: Array[Dictionary], height_offset: float) -> void:
    var batch: MultiMesh = MultiMesh.new()
    batch.transform_format = MultiMesh.TRANSFORM_3D
    batch.mesh = mesh
    batch.instance_count = sites.size()
    for i in range(sites.size()):
        var site: Dictionary = sites[i]
        var factor: float = float(site["size"])
        var position: Vector3 = site["base"] + Vector3.UP * height_offset * factor
        var basis: Basis = Basis().scaled(Vector3.ONE * factor)
        batch.set_instance_transform(i, Transform3D(basis, position))
    var renderer: MultiMeshInstance3D = MultiMeshInstance3D.new()
    renderer.multimesh = batch
    renderer.material_override = _mat(color)
    add_child(renderer)

func _lake() -> void:
    var p: PlaneMesh = PlaneMesh.new()
    p.size = Vector2(32.0, 25.0)
    p.subdivide_width = 24
    p.subdivide_depth = 24
    var shader: Shader = Shader.new()
    shader.code = """shader_type spatial;
render_mode cull_disabled, depth_draw_opaque;
uniform vec4 water_color : source_color = vec4(0.11, 0.52, 0.64, 1.0);
void vertex() { VERTEX.y += sin(VERTEX.x*0.8 + TIME*1.4)*0.06 + cos(VERTEX.z*0.9 + TIME)*0.05; }
void fragment() { ALBEDO = water_color.rgb + vec3(0.07)*sin(UV.x*30.0+TIME*1.4)*cos(UV.y*20.0-TIME); ROUGHNESS = 0.16; METALLIC = 0.09; }
"""
    var mat: ShaderMaterial = ShaderMaterial.new()
    mat.shader = shader
    var surface: MeshInstance3D = _mesh(p, Vector3(42, -0.50, -13), mat)
    surface.name = "AnimatedLake"
    for i in range(12):
        var ang: float = TAU * float(i) / 12.0
        var x: float = 42.0 + cos(ang) * 21.0
        var z: float = -13.0 + sin(ang) * 16.0
        _cylinder(1.0, 0.8, Vector3(x, ground_y(x, z) + 0.25, z), Color("6f8f88"))

func _ruins() -> void:
    var center: Vector3 = Vector3(0, ground_y(0, -65), -65)
    _cylinder(8.2, 0.5, center + Vector3(0, 0.2, 0), Color("87999a"))
    for i in range(10):
        var a: float = TAU * float(i) / 10.0
        var x: float = cos(a) * 8.1
        var z: float = sin(a) * 8.1
        var h: float = rng.randf_range(3.0, 7.2)
        _cylinder(0.78, h, center + Vector3(x, h * 0.5, z), Color("bbc0aa"))
        _box(Vector3(1.8, 0.5, 1.8), center + Vector3(x, h + 0.1, z), Color("94a1a0"))
    var crystal: SphereMesh = SphereMesh.new()
    crystal.radius = 1.8
    crystal.height = 3.4
    _mesh(crystal, center + Vector3(0, 4.2, 0), _mat(Color("5ee0e3"), 0.12, true))
    # Far-field tower gives spatial scale without expanding the playable area.
    _cylinder(6.0, 19.0, Vector3(-65, ground_y(-65, -65) + 9.5, -65), Color("a6a6b0"))
    _cone(9.5, 10.0, Vector3(-65, ground_y(-65, -65) + 24, -65), Color("5673a1"))

func _spawn_points() -> void:
    npc_spots = [
        {"id": "elder", "label": "Elder Elian", "position": Vector3(-5, ground_y(-5, 25.0), 25)},
        {"id": "smith", "label": "Blacksmith Rowan", "position": Vector3(8.5, ground_y(8.5, 20), 20)},
        {"id": "merchant", "label": "Merchant Mira", "position": Vector3(-11, ground_y(-11, 18), 18)}
    ]
    chest_spots = [
        {"id": "relic", "position": Vector3(4.4, ground_y(4.4, -63) + 0.5, -63.0)},
        {"id": "forest", "position": Vector3(-19.0, ground_y(-19.0, -17) + 0.5, -17)},
        {"id": "lake", "position": Vector3(26.0, ground_y(26.0, 7) + 0.5, 7)}
    ]
