extends Node
## Persistent, engine-independent gameplay state. v8 web localStorage is NOT directly readable.
signal changed

const SAVE_PATH = "user://astra_godot_v9.json"
var state: Dictionary = {}

func _ready() -> void:
    reset()
    load_game()

func reset() -> void:
    state = {
        "hero": "aster", "level": 1, "xp": 0, "hp": 120, "max_hp": 120,
        "mp": 60, "max_mp": 60, "gold": 45, "potions": 3,
        "weapon": 1, "armor": 1, "quest": 0, "wolves": 0, "herbs": 0,
        "relic": false, "boss_defeated": false, "chests": [],
        "position": [0.0, 4.0, 35.0], "camera_yaw": 0.0
    }
    changed.emit()

func get_value(key: String, fallback: Variant = null) -> Variant:
    return state.get(key, fallback)

func add_xp(amount: int) -> void:
    state["xp"] = int(state["xp"]) + amount
    while int(state["xp"]) >= xp_to_next():
        state["xp"] = int(state["xp"]) - xp_to_next()
        state["level"] = int(state["level"]) + 1
        state["max_hp"] = int(state["max_hp"]) + 18
        state["max_mp"] = int(state["max_mp"]) + 8
        state["hp"] = state["max_hp"]
        state["mp"] = state["max_mp"]
    changed.emit()

func xp_to_next() -> int:
    return 50 + int(state["level"]) * 40

func save_game(position: Vector3, yaw: float) -> bool:
    state["position"] = [position.x, position.y, position.z]
    state["camera_yaw"] = yaw
    var f: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if f == null:
        push_error("Cannot save: " + str(FileAccess.get_open_error()))
        return false
    f.store_string(JSON.stringify(state, "  "))
    f.close()
    return true

func load_game() -> bool:
    if not FileAccess.file_exists(SAVE_PATH):
        return false
    var f: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.READ)
    if f == null:
        return false
    var parsed: Variant = JSON.parse_string(f.get_as_text())
    f.close()
    if not (parsed is Dictionary):
        return false
    for k in parsed:
        if state.has(k):
            state[k] = parsed[k]
    # Validate and clamp loaded values before creating gameplay nodes.
    state["level"] = clampi(int(state["level"]), 1, 99)
    state["xp"] = maxi(0, int(state["xp"]))
    state["max_hp"] = maxi(1, int(state["max_hp"]))
    state["max_mp"] = maxi(0, int(state["max_mp"]))
    state["hp"] = clampi(int(state["hp"]), 0, int(state["max_hp"]))
    state["mp"] = clampi(int(state["mp"]), 0, int(state["max_mp"]))
    state["gold"] = maxi(0, int(state["gold"]))
    state["potions"] = clampi(int(state["potions"]), 0, 999)
    state["weapon"] = clampi(int(state["weapon"]), 1, 99)
    state["armor"] = clampi(int(state["armor"]), 1, 99)
    state["quest"] = clampi(int(state["quest"]), 0, 5)
    state["wolves"] = clampi(int(state["wolves"]), 0, 3)
    state["hero"] = "lyra" if str(state["hero"]) == "lyra" else "aster"
    if not (state["chests"] is Array):
        state["chests"] = []
    if not (state["position"] is Array) or state["position"].size() != 3:
        state["position"] = [0.0, 4.0, 35.0]
    changed.emit()
    return true

func heal() -> bool:
    if int(state["potions"]) <= 0 or int(state["hp"]) >= int(state["max_hp"]):
        return false
    state["potions"] = int(state["potions"]) - 1
    state["hp"] = mini(int(state["max_hp"]), int(state["hp"]) + 70)
    changed.emit()
    return true

func lose_hp(amount: int) -> void:
    state["hp"] = maxi(0, int(state["hp"]) - amount)
    changed.emit()

func spend_mp(amount: int) -> bool:
    if int(state["mp"]) < amount:
        return false
    state["mp"] = int(state["mp"]) - amount
    changed.emit()
    return true
