extends Control
## Landscape-first virtual joystick and action HUD. UI itself doesn't simulate game state.
signal action_pressed(id: String)
signal camera_swiped(delta_xy: Vector2)
signal stick_moved(axis: Vector2)

var axis: Vector2 = Vector2.ZERO
var stick_id: int = -1
var look_id: int = -1
var stick_center: Vector2 = Vector2(110, 400)
var stick_radius: float = 68.0
var minimap_center: Vector2 = Vector2.ZERO
var action_buttons: Dictionary = {}
var hp_text: Label
var mp_text: Label
var quest_text: Label
var coin_text: Label
var mission_hint: Label
var toast_text: Label
var panel: Panel
var dialog_back: Panel
var dialog_text: Label
var menu_back: Panel
var toast_left: float = 0.0
var map_markers: Array[Dictionary] = []
var player_map: Vector2 = Vector2.ZERO
var ui_scale: float = 1.0

func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _build_ui()
    resized.connect(_layout)
    GameData.changed.connect(refresh)
    _layout()
    refresh()

func _panel(bg: Color, radius: int = 15) -> StyleBoxFlat:
    var s: StyleBoxFlat = StyleBoxFlat.new()
    s.bg_color = bg
    s.set_corner_radius_all(radius)
    s.border_width_top = 1
    s.border_width_bottom = 1
    s.border_width_left = 1
    s.border_width_right = 1
    s.border_color = Color(0.85, 0.85, 0.67, 0.35)
    return s

func _label(value: String, size: int, color: Color, parent: Node = null) -> Label:
    var l: Label = Label.new()
    l.text = value
    l.add_theme_font_size_override("font_size", size)
    l.add_theme_color_override("font_color", color)
    l.mouse_filter = Control.MOUSE_FILTER_IGNORE
    if parent == null:
        add_child(l)
    else:
        parent.add_child(l)
    return l

func _button(title: String, action: String, bg: Color, font_size: int = 16) -> Button:
    var b: Button = Button.new()
    b.text = title
    b.add_theme_font_size_override("font_size", font_size)
    b.add_theme_color_override("font_color", Color("fff8dc"))
    b.add_theme_stylebox_override("normal", _panel(bg, 24))
    b.add_theme_stylebox_override("hover", _panel(bg.lightened(0.17), 24))
    b.add_theme_stylebox_override("pressed", _panel(bg.darkened(0.14), 24))
    b.focus_mode = Control.FOCUS_NONE
    b.pressed.connect(func() -> void: action_pressed.emit(action))
    add_child(b)
    action_buttons[action] = b
    return b

func _build_ui() -> void:
    panel = Panel.new()
    panel.add_theme_stylebox_override("panel", _panel(Color(0.04, 0.11, 0.17, 0.78)))
    add_child(panel)
    _label("✦ ASTRA LEGENDS", 19, Color("f4d59a"), panel).position = Vector2(17, 12)
    hp_text = _label("HP", 14, Color("ffd1d1"), panel)
    hp_text.position = Vector2(17, 43)
    mp_text = _label("MP", 14, Color("a9d8ff"), panel)
    mp_text.position = Vector2(17, 66)
    coin_text = _label("", 12, Color("e4d7a6"), panel)
    coin_text.position = Vector2(17, 91)
    quest_text = _label("", 16, Color("fbeac8"))
    quest_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    mission_hint = _label("", 12, Color("d7d9d9"))
    mission_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    toast_text = _label("", 17, Color("ffe6a5"))
    toast_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    for entry in [
        ["ATK", "attack", Color("a34b4f"), 20],
        ["SPELL", "magic", Color("376b9d"), 12],
        ["SKILL", "skill", Color("866ab1"), 12],
        ["DODGE", "dodge", Color("466d72"), 12],
        ["JUMP", "jump", Color("324f62"), 12],
        ["TALK", "interact", Color("6e7850"), 12],
        ["MENU", "menu", Color("354855"), 13]
    ]:
        _button(str(entry[0]), str(entry[1]), entry[2], int(entry[3]))
    dialog_back = Panel.new()
    dialog_back.add_theme_stylebox_override("panel", _panel(Color(0.035, 0.08, 0.14, 0.95), 14))
    add_child(dialog_back)
    dialog_text = _label("", 19, Color("fff2d8"), dialog_back)
    dialog_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    var close: Button = Button.new()
    close.text = "Continue  ›"
    close.pressed.connect(func() -> void: action_pressed.emit("close_dialogue"))
    close.position = Vector2(20, 104)
    close.size = Vector2(155, 35)
    dialog_back.add_child(close)
    dialog_back.hide()
    menu_back = Panel.new()
    menu_back.add_theme_stylebox_override("panel", _panel(Color(0.035, 0.08, 0.14, 0.97)))
    add_child(menu_back)
    var title: Label = _label("ADVENTURER'S MENU", 22, Color("f1d99e"), menu_back)
    title.position = Vector2(17, 10)
    for i in range(5):
        var options: Array = ["POTION", "UPGRADE", "ARMOR", "SAVE", "HERO"]
        var btn: Button = Button.new()
        btn.text = str(options[i])
        btn.position = Vector2(16, 49 + i * 49)
        btn.size = Vector2(245, 40)
        btn.add_theme_stylebox_override("normal", _panel(Color("273a4d")))
        var action: String = str(options[i]).to_lower()
        btn.pressed.connect(func() -> void: action_pressed.emit(action))
        menu_back.add_child(btn)
    var exit: Button = Button.new()
    exit.text = "CLOSE"
    exit.position = Vector2(16, 295)
    exit.size = Vector2(245, 37)
    exit.pressed.connect(func() -> void: action_pressed.emit("menu"))
    menu_back.add_child(exit)
    menu_back.hide()

func _layout() -> void:
    var w: float = size.x
    var h: float = size.y
    if w < 1 or h < 1:
        return
    stick_radius = minf(66.0, h * 0.18)
    stick_center = Vector2(maxf(82.0, w * 0.115), h - maxf(81.0, h * 0.185))
    minimap_center = Vector2(w - 83.0, 89.0)
    panel.position = Vector2(18, 17)
    panel.size = Vector2(248, 119)
    quest_text.position = Vector2(w * 0.32, 22)
    quest_text.size = Vector2(w * 0.36, 29)
    mission_hint.position = Vector2(w * 0.32, 50)
    mission_hint.size = Vector2(w * 0.36, 27)
    toast_text.position = Vector2(w * 0.27, h * 0.7)
    toast_text.size = Vector2(w * 0.46, 36)
    var positions: Dictionary = {
        "attack": Vector2(w - 95, h - 105),
        "magic": Vector2(w - 179, h - 128),
        "skill": Vector2(w - 184, h - 207),
        "dodge": Vector2(w - 256, h - 85),
        "jump": Vector2(w - 264, h - 164),
        "interact": Vector2(w - 95, h - 198),
        "menu": Vector2(w - 151, 17)
    }
    for key in action_buttons:
        var b: Button = action_buttons[key]
        b.size = Vector2(70, 68) if key == "attack" else Vector2(65, 54)
        if key == "menu":
            b.size = Vector2(59, 38)
        b.position = positions[key]
    dialog_back.position = Vector2(w * 0.20, h * 0.63)
    dialog_back.size = Vector2(w * 0.60, h * 0.31)
    dialog_text.position = Vector2(20, 12)
    dialog_text.size = Vector2(dialog_back.size.x - 40, dialog_back.size.y - 62)
    # Close button stays inside dialogue even in short landscape dimensions.
    var close_dialog: Button = dialog_back.get_child(1) as Button
    close_dialog.position = Vector2(dialog_back.size.x - 172, dialog_back.size.y - 42)
    menu_back.position = Vector2(w * 0.50, maxf(9, h * 0.08))
    menu_back.size = Vector2(280, 354)
    queue_redraw()

func _point_is_button(p: Vector2) -> bool:
    for key in action_buttons:
        if action_buttons[key].get_global_rect().has_point(p):
            return true
    return false

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        var touch: InputEventScreenTouch = event
        if touch.pressed:
            if dialog_back.visible or menu_back.visible:
                return
            if _point_is_button(touch.position):
                return
            if touch.position.x < size.x * 0.43 and touch.position.y > size.y * 0.45 and stick_id == -1:
                stick_id = touch.index
                _set_axis(touch.position)
            elif touch.position.x > size.x * 0.44 and look_id == -1:
                look_id = touch.index
        else:
            if touch.index == stick_id:
                stick_id = -1
                axis = Vector2.ZERO
                stick_moved.emit(axis)
                queue_redraw()
            if touch.index == look_id:
                look_id = -1
    elif event is InputEventScreenDrag:
        var drag: InputEventScreenDrag = event
        if drag.index == stick_id:
            _set_axis(drag.position)
        elif drag.index == look_id:
            camera_swiped.emit(drag.relative)
    elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
        camera_swiped.emit((event as InputEventMouseMotion).relative)

func _set_axis(touch: Vector2) -> void:
    var raw: Vector2 = (touch - stick_center) / stick_radius
    if raw.length() <= 0.14:
        axis = Vector2.ZERO
    else:
        axis = raw.limit_length(1.0)
    stick_moved.emit(axis)
    queue_redraw()

func _draw() -> void:
    if size.x < 1:
        return
    draw_circle(stick_center, stick_radius, Color(0.06, 0.12, 0.19, 0.55))
    draw_arc(stick_center, stick_radius, 0, TAU, 64, Color(0.87, 0.91, 0.88, 0.5), 2.0, true)
    draw_circle(stick_center + axis * stick_radius * 0.54, stick_radius * 0.40, Color(0.4, 0.74, 0.82, 0.75))
    draw_circle(minimap_center, 61.0, Color(0.03, 0.14, 0.15, 0.83))
    draw_arc(minimap_center, 61, 0, TAU, 64, Color("cdbb83"), 3, true)
    draw_circle(minimap_center, 3.7, Color.WHITE)
    for entry in map_markers:
        var pt: Vector2 = entry.get("at", Vector2.ZERO)
        var kind: String = entry.get("kind", "enemy")
        var delta: Vector2 = (pt - player_map) * 0.55
        var point: Vector2 = minimap_center + delta.limit_length(55)
        var tint: Color = Color("e47b78") if kind == "enemy" else Color("e6d08e")
        draw_circle(point, 3.6, tint)

func update_map(hero_pos: Vector3, markers: Array[Dictionary]) -> void:
    player_map = Vector2(hero_pos.x, hero_pos.z)
    map_markers = markers
    queue_redraw()

func refresh() -> void:
    if hp_text == null:
        return
    hp_text.text = "HP  %d / %d" % [int(GameData.get_value("hp", 120)), int(GameData.get_value("max_hp", 120))]
    mp_text.text = "MP  %d / %d" % [int(GameData.get_value("mp", 60)), int(GameData.get_value("max_mp", 60))]
    coin_text.text = "Lv.%d   XP %d/%d     %d G" % [int(GameData.get_value("level", 1)), int(GameData.get_value("xp", 0)), GameData.xp_to_next(), int(GameData.get_value("gold", 45))]
    var q: int = int(GameData.get_value("quest", 0))
    var quests: Array[String] = ["Chapter I — The Fallen Star", "The Wolves of Silverwood", "The Relic Beneath the Ruins", "The Guardian of Dawn", "Return to the Elder", "Chapter I Complete"]
    quest_text.text = quests[clampi(q, 0, quests.size() - 1)]
    var hints: Array[String] = ["Speak to Elder Elian in the village", "Defeat 3 forest wolves", "Find the luminous chest in the ruins", "Defeat the guardian at the altar", "Return to Elder Elian for your reward", "Explore freely · more chapters planned"]
    mission_hint.text = hints[clampi(q, 0, hints.size() - 1)]

func show_dialogue(text: String) -> void:
    dialog_text.text = text
    dialog_back.show()

func hide_dialogue() -> void:
    dialog_back.hide()

func toggle_menu() -> bool:
    if menu_back.visible:
        menu_back.hide()
    else:
        dialog_back.hide()
        menu_back.show()
    return menu_back.visible

func is_blocking() -> bool:
    return dialog_back.visible or menu_back.visible

func toast(message: String) -> void:
    toast_text.text = message
    toast_left = 2.35
    toast_text.show()

func _process(delta: float) -> void:
    if toast_left > 0:
        toast_left -= delta
        if toast_left <= 0:
            toast_text.text = ""
