extends CharacterBody3D
## Independent enemy AI with anticipation windows, chase and differentiated rewards.
signal slain(enemy: Node3D, xp: int, gold: int)
signal strike_player(power: int)

var kind: String = "wolf"
var hp: int = 70
var max_hp: int = 70
var speed: float = 3.1
var xp_reward: int = 21
var gold_reward: int = 12
var attack_power: int = 12
var player: Node3D
var visual: Node3D
var anim: AnimationPlayer
var home: Vector3
var cooldown: float = 0.0
var windup: float = 0.0
var dying: bool = false
var drift: float = 0.0
var health_bar: MeshInstance3D
var warning_ring: MeshInstance3D

func configure(enemy_kind: String, target: Node3D) -> void:
    kind = enemy_kind
    player = target
    match kind:
        "slime":
            hp = 45; speed = 2.0; xp_reward = 16; gold_reward = 7; attack_power = 9
        "spirit":
            hp = 58; speed = 3.4; xp_reward = 26; gold_reward = 15; attack_power = 11
        "boss":
            hp = 490; speed = 3.0; xp_reward = 240; gold_reward = 190; attack_power = 23
        _:
            hp = 78; speed = 3.8; xp_reward = 24; gold_reward = 13; attack_power = 12
    max_hp = hp

func _ready() -> void:
    collision_layer = 4
    collision_mask = 1
    home = global_position
    var col: CollisionShape3D = CollisionShape3D.new()
    var sphere: SphereShape3D = SphereShape3D.new()
    sphere.radius = 0.8 if kind != "boss" else 1.6
    col.position.y = 0.8 if kind != "boss" else 1.65
    col.shape = sphere
    add_child(col)
    visual = Node3D.new()
    add_child(visual)
    _visuals()
    _create_warning_ring()

func _material(color: Color, emission: bool = false) -> StandardMaterial3D:
    var mat: StandardMaterial3D = StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.44
    if emission:
        mat.emission_enabled = true
        mat.emission = color
        mat.emission_energy_multiplier = 1.3
    return mat

func _ball(size: float, y: float, color: Color, parent: Node3D = null) -> MeshInstance3D:
    var mi: MeshInstance3D = MeshInstance3D.new()
    var sphere: SphereMesh = SphereMesh.new()
    sphere.radius = size
    sphere.height = size * 2.0
    mi.mesh = sphere
    mi.material_override = _material(color, kind == "spirit")
    mi.position.y = y
    if parent == null:
        visual.add_child(mi)
    else:
        parent.add_child(mi)
    return mi

func _visuals() -> void:
    if kind == "wolf":
        var fox: PackedScene = load("res://assets/models/creatures/fox_ccby4.gltf") as PackedScene
        if fox != null:
            var n: Node3D = fox.instantiate() as Node3D
            visual.add_child(n)
            n.scale = Vector3.ONE * 0.022
            anim = n.find_child("AnimationPlayer", true, false) as AnimationPlayer
            if anim != null:
                var clip: StringName = _find_anim("Run")
                if clip != &"":
                    anim.play(clip)
        else:
            _ball(0.8, 0.86, Color("8e5c36"))
    elif kind == "slime":
        _ball(0.77, 0.8, Color("5dd7db"))
        _ball(0.17, 1.0, Color("ffffff"))
    elif kind == "spirit":
        _ball(0.59, 1.3, Color("b48ee5"))
        for i in range(3):
            var a: float = TAU * float(i) / 3.0
            var orb: MeshInstance3D = _ball(0.17, 0.0, Color("e9f1ff"))
            orb.position = Vector3(cos(a) * 1.0, 1.2, sin(a) * 1.0)
    else:
        _ball(1.66, 1.85, Color("292c5e"))
        _ball(0.85, 3.6, Color("b157ba"))
        for i in range(6):
            var a: float = TAU * float(i) / 6.0
            var spike: MeshInstance3D = MeshInstance3D.new()
            var m: CylinderMesh = CylinderMesh.new()
            m.top_radius = 0.0
            m.bottom_radius = 0.4
            m.height = 2.1
            spike.mesh = m
            spike.material_override = _material(Color("b8a1e4"))
            spike.position = Vector3(cos(a) * 1.4, 2.8, sin(a) * 1.4)
            visual.add_child(spike)

func _create_warning_ring() -> void:
    # Explicit ground telegraph instead of an unreadable scale animation.
    warning_ring = MeshInstance3D.new()
    warning_ring.name = "AttackDangerZone"
    var disc: CylinderMesh = CylinderMesh.new()
    disc.top_radius = 1.75 if kind == "boss" else 1.08
    disc.bottom_radius = disc.top_radius
    disc.height = 0.035
    disc.radial_segments = 32
    warning_ring.mesh = disc
    var mat: StandardMaterial3D = StandardMaterial3D.new()
    mat.albedo_color = Color(1.0, 0.12, 0.16, 0.34)
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.emission_enabled = true
    mat.emission = Color("eb3f45")
    mat.emission_energy_multiplier = 0.6
    warning_ring.material_override = mat
    warning_ring.position.y = -1.15
    warning_ring.visible = false
    add_child(warning_ring)

func _find_anim(name_part: String) -> StringName:
    if anim != null:
        for n in anim.get_animation_list():
            if str(n).ends_with(name_part):
                return n
    return &""

func _physics_process(delta: float) -> void:
    if dying or player == null:
        return
    cooldown = maxf(0.0, cooldown - delta)
    if warning_ring != null:
        warning_ring.visible = windup > 0.0
        if windup > 0.0:
            var pulse: float = 0.92 + 0.14 * sin(drift * 18.0)
            warning_ring.scale = Vector3(pulse, 1.0, pulse)
    drift += delta
    var toward: Vector3 = player.global_position - global_position
    toward.y = 0.0
    var d: float = toward.length()
    var attack_range: float = 3.6 if kind == "boss" else 1.9
    if windup > 0:
        windup -= delta
        velocity.x = move_toward(velocity.x, 0.0, delta * 22.0)
        velocity.z = move_toward(velocity.z, 0.0, delta * 22.0)
        if windup <= 0 and d < attack_range + 0.35:
            strike_player.emit(attack_power)
            cooldown = 1.3 if kind != "boss" else 1.8
    elif d < 17.0 and d > attack_range:
        var direction: Vector3 = toward.normalized()
        velocity.x = move_toward(velocity.x, direction.x * speed, delta * 12.0)
        velocity.z = move_toward(velocity.z, direction.z * speed, delta * 12.0)
        visual.rotation.y = lerp_angle(visual.rotation.y, atan2(-direction.x, -direction.z), delta * 8.0)
    elif d <= attack_range and cooldown <= 0:
        windup = 0.65 if kind != "boss" else 1.0
        # Scale up during windup as a strong visual threat cue.
        visual.scale = Vector3.ONE * 1.12
    else:
        velocity.x = move_toward(velocity.x, 0.0, delta * 8.0)
        velocity.z = move_toward(velocity.z, 0.0, delta * 8.0)
    if windup <= 0:
        visual.scale = visual.scale.lerp(Vector3.ONE, delta * 7.0)
    if not is_on_floor():
        velocity.y -= 24.0 * delta
    else:
        velocity.y = -0.1
    move_and_slide()
    if kind == "slime" or kind == "spirit":
        visual.position.y = sin(drift * (3.0 if kind == "slime" else 2.3)) * 0.15

func take_hit(amount: int, impulse: Vector3) -> void:
    if dying:
        return
    hp -= amount
    if hp <= 0:
        dying = true
        slain.emit(self, xp_reward, gold_reward)
        var tw: Tween = create_tween()
        tw.tween_property(visual, "scale", Vector3.ZERO, 0.27)
        tw.tween_callback(queue_free)
    else:
        if kind != "boss":
            velocity.x += impulse.x * 4.0
            velocity.z += impulse.z * 4.0
        var tw: Tween = create_tween()
        tw.tween_property(visual, "scale", Vector3.ONE * 1.18, 0.08)
        tw.tween_property(visual, "scale", Vector3.ONE, 0.12)
