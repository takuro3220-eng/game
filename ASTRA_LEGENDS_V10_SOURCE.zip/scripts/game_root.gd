extends Node3D
## Native Godot vertical slice: continuous world + gameplay + mobile input + persistence.
## Source Web v8 was inspected; logic reimplemented, not embedded in a WebView.

const WORLD_SCRIPT = preload("res://scripts/world_builder.gd")
const HERO_SCRIPT = preload("res://scripts/player.gd")
const ENEMY_SCRIPT = preload("res://scripts/enemy.gd")
const CAMERA_SCRIPT = preload("res://scripts/camera_rig.gd")
const HUD_SCRIPT = preload("res://scripts/touch_hud.gd")

var world
var hero
var rig
var hud
var layer: CanvasLayer
var enemies: Array = []
var projectiles: Array[Dictionary] = []
var scenery_npcs: Array[Dictionary] = []
var scenery_chests: Array[Dictionary] = []
var scenery_herbs: Array[Dictionary] = []
var ambient_music: AudioStreamPlayer
var update_counter: float = 0
var autosave_counter: float = 0
var respawn_delay: float = -1

func _ready() -> void:
    world = WORLD_SCRIPT.new()
    world.name = "World_Silverwood"
    add_child(world)
    hero = HERO_SCRIPT.new()
    add_child(hero)
    var p: Array = GameData.get_value("position", [0.0, 4.0, 17.0])
    if p.size() >= 3:
        hero.global_position = Vector3(float(p[0]), maxf(3.0, float(p[1])), float(p[2]))
    else:
        hero.global_position = Vector3(0, 4, 17)
    rig = CAMERA_SCRIPT.new()
    rig.target = hero
    rig.yaw = float(GameData.get_value("camera_yaw", 0.0))
    add_child(rig)
    hero.camera_ref = rig.eye
    layer = CanvasLayer.new()
    add_child(layer)
    hud = HUD_SCRIPT.new()
    layer.add_child(hud)
    hud.action_pressed.connect(_on_action)
    hud.stick_moved.connect(func(axis: Vector2) -> void: hero.input_axis = axis)
    hud.camera_swiped.connect(func(movement: Vector2) -> void: rig.rotate_look(movement))
    hero.attack_hit.connect(_on_hero_attack)
    hero.cast_projectile.connect(_on_spell)
    hero.dodged.connect(func() -> void: _message("Swift evasion!"))
    _populate_npcs()
    _populate_chests()
    _populate_herbs()
    _populate_enemies()
    _music()
    _message("The fallen star awaits. Speak to Elder Elian.")

func _input(event: InputEvent) -> void:
    if event.is_action_pressed("attack"):
        _on_action("attack")
    elif event.is_action_pressed("interact"):
        _on_action("interact")
    elif event.is_action_pressed("dodge"):
        _on_action("dodge")
    elif event.is_action_pressed("magic"):
        _on_action("magic")
    elif event.is_action_pressed("skill"):
        _on_action("skill")
    elif event.is_action_pressed("jump"):
        _on_action("jump")
    elif event.is_action_pressed("menu"):
        _on_action("menu")
    elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
        rig.rotate_look((event as InputEventMouseMotion).relative)

func _process(delta: float) -> void:
    update_counter += delta
    autosave_counter += delta
    if update_counter > 0.25:
        update_counter = 0
        var m: Array[Dictionary] = []
        for npc in scenery_npcs:
            m.append({"at": Vector2(npc["position"].x, npc["position"].z), "kind": "npc"})
        for enemy in enemies:
            if is_instance_valid(enemy) and not enemy.dying:
                m.append({"at": Vector2(enemy.global_position.x, enemy.global_position.z), "kind": "enemy"})
        hud.update_map(hero.global_position, m)
        if absf(hero.global_position.x) > 89.0 or absf(hero.global_position.z) > 89.0:
            hero.global_position = Vector3(clampf(hero.global_position.x, -88.0, 88.0), 5.0, clampf(hero.global_position.z, -88.0, 88.0))
    if autosave_counter > 40.0:
        autosave_counter = 0
        _save(false)
    if respawn_delay > 0:
        respawn_delay -= delta
        if respawn_delay <= 0:
            hero.revive()
            _message("You awaken at Silverwood village.")
    _update_projectiles(delta)
    if hero.defeated and respawn_delay < 0:
        respawn_delay = 2.5
        _message("Your journey is not over...")

func _music() -> void:
    ambient_music = AudioStreamPlayer.new()
    ambient_music.volume_db = -13.0
    ambient_music.stream = load("res://assets/audio/celestial_theme.ogg") as AudioStream
    add_child(ambient_music)
    if ambient_music.stream != null:
        ambient_music.play()

func _mesh_box(name_str: String, size: Vector3, color: Color, root: Node3D) -> MeshInstance3D:
    var mesh_inst: MeshInstance3D = MeshInstance3D.new()
    mesh_inst.name = name_str
    var mesh: BoxMesh = BoxMesh.new()
    mesh.size = size
    mesh_inst.mesh = mesh
    var mat: StandardMaterial3D = StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.71
    mesh_inst.material_override = mat
    root.add_child(mesh_inst)
    return mesh_inst

func _populate_npcs() -> void:
    for i in range(world.npc_spots.size()):
        var record: Dictionary = world.npc_spots[i]
        var anchor: Node3D = Node3D.new()
        anchor.name = "NPC_" + str(record["id"])
        anchor.position = record["position"]
        anchor.rotation.y = 2.5 - float(i) * 0.6
        add_child(anchor)
        var f: String = "aster.glb" if i == 1 else "lyra.glb"
        var asset: PackedScene = load("res://assets/models/characters/" + f) as PackedScene
        if asset != null:
            var instance: Node3D = asset.instantiate() as Node3D
            instance.scale = Vector3.ONE * 0.71
            anchor.add_child(instance)
            var ap: AnimationPlayer = instance.find_child("AnimationPlayer", true, false) as AnimationPlayer
            if ap != null:
                for clip in ap.get_animation_list():
                    if str(clip).ends_with("Idle"):
                        var act: Animation = ap.get_animation(clip)
                        if act != null:
                            act.loop_mode = Animation.LOOP_LINEAR
                        ap.play(clip)
                        break
        var ring: MeshInstance3D = _mesh_box("NPCMarker", Vector3(0.82, 0.12, 0.82), Color("75a8d5"), anchor)
        ring.position.y = 0.08
        scenery_npcs.append({"id": record["id"], "label": record["label"], "position": anchor.global_position, "node": anchor})

func _populate_chests() -> void:
    for ch in world.chest_spots:
        var id: String = str(ch["id"])
        if GameData.get_value("chests", []).has(id):
            continue
        var anchor: Node3D = Node3D.new()
        anchor.name = "Chest_" + id
        anchor.position = ch["position"]
        add_child(anchor)
        _mesh_box("Wood", Vector3(1.2, 0.8, 0.8), Color("6a4630"), anchor)
        var lid: MeshInstance3D = _mesh_box("Ornament", Vector3(1.28, 0.20, 0.88), Color("d5b66e"), anchor)
        lid.position.y = 0.47
        scenery_chests.append({"id": id, "position": anchor.global_position, "node": anchor})

func _populate_herbs() -> void:
    for pt in [Vector2(-12, -9), Vector2(-23, -25), Vector2(19, -12), Vector2(-33, -16), Vector2(25, -37)]:
        var anchor: Node3D = Node3D.new()
        anchor.position = Vector3(pt.x, world.ground_y(pt.x, pt.y) + 0.32, pt.y)
        add_child(anchor)
        var flower: MeshInstance3D = MeshInstance3D.new()
        var sphere: SphereMesh = SphereMesh.new()
        sphere.radius = 0.37
        sphere.height = 0.74
        flower.mesh = sphere
        var mat: StandardMaterial3D = StandardMaterial3D.new()
        mat.albedo_color = Color("8ff5c5")
        mat.emission_enabled = true
        mat.emission = Color("4da882")
        flower.material_override = mat
        anchor.add_child(flower)
        scenery_herbs.append({"position": anchor.global_position, "node": anchor})

func _populate_enemies() -> void:
    for spot in [
        ["wolf", -7.0, -9.0], ["wolf", 9.0, -15.0], ["wolf", -13.0, -27.0], ["wolf", 17.0, -36.0],
        ["slime", -3.0, -19.0], ["slime", 21.0, -7.0], ["slime", -21.0, -39.0],
        ["spirit", -22.0, -49.0], ["spirit", 18.0, -57.0]
    ]:
        _enemy(str(spot[0]), float(spot[1]), float(spot[2]))
    if int(GameData.get_value("quest", 0)) >= 3 and not bool(GameData.get_value("boss_defeated", false)):
        _spawn_boss_once()

func _spawn_boss_once() -> void:
    if bool(GameData.get_value("boss_defeated", false)):
        return
    for enemy in enemies:
        if is_instance_valid(enemy) and enemy.kind == "boss" and not enemy.dying:
            return
    _enemy("boss", 0.0, -68.0)

func _enemy(kind: String, x: float, z: float) -> void:
    var enemy = ENEMY_SCRIPT.new()
    enemy.configure(kind, hero)
    add_child(enemy)
    enemy.position = Vector3(x, world.ground_y(x, z) + 1.3, z)
    enemy.strike_player.connect(_enemy_strike)
    enemy.slain.connect(_on_enemy_slain)
    enemies.append(enemy)

func _enemy_strike(power: int) -> void:
    if hud.is_blocking():
        return
    var reduced: int = maxi(1, power - int(GameData.get_value("armor", 1)) * 2)
    if hero.receive_damage(reduced):
        _message("-%d HP" % reduced)
    else:
        _message("Dodged!")

func _on_enemy_slain(enemy, xp: int, gold: int) -> void:
    GameData.add_xp(xp)
    GameData.state["gold"] = int(GameData.get_value("gold", 0)) + gold
    if enemy.kind == "wolf" and int(GameData.get_value("quest", 0)) == 1:
        GameData.state["wolves"] = int(GameData.get_value("wolves", 0)) + 1
        if int(GameData.state["wolves"]) >= 3:
            if bool(GameData.get_value("relic", false)):
                GameData.state["quest"] = 3
                _spawn_boss_once()
                _message("The guardian has awakened at the ruins!")
            else:
                GameData.state["quest"] = 2
                _message("The forest is safer. Find the star relic!")
    elif enemy.kind == "boss":
        GameData.state["boss_defeated"] = true
        if int(GameData.get_value("quest", 0)) == 3:
            GameData.state["quest"] = 4
        _message("Guardian defeated! Return to Elder Elian.")
    else:
        _message("+%d XP   +%d G" % [xp, gold])
    GameData.changed.emit()
    _save(false)

func _on_hero_attack(origin: Vector3, direction: Vector3, damage: int, reach: float, arc: float, kind: String) -> void:
    _sword_effect(origin, kind)
    var hits: int = 0
    for enemy in enemies:
        if not is_instance_valid(enemy) or enemy.dying:
            continue
        var to_enemy: Vector3 = enemy.global_position - origin
        to_enemy.y = 0
        if to_enemy.length() > reach:
            continue
        if arc > 0 and direction.normalized().dot(to_enemy.normalized()) < arc:
            continue
        enemy.take_hit(damage, direction)
        hits += 1
    if hits > 0:
        _message("%s!  %d damage" % ["Arc Slash" if kind == "sweep" else "Hit", damage])

func _sword_effect(origin: Vector3, kind: String) -> void:
    var pulse: MeshInstance3D = MeshInstance3D.new()
    var m: SphereMesh = SphereMesh.new()
    m.radius = 0.48
    m.height = 0.44
    pulse.mesh = m
    var material: StandardMaterial3D = StandardMaterial3D.new()
    material.albedo_color = Color("d5fff3") if kind == "sweep" else Color("f6cf82")
    material.emission_enabled = true
    material.emission = material.albedo_color
    pulse.material_override = material
    add_child(pulse)
    pulse.global_position = origin + hero.last_direction * 1.3
    var t: Tween = create_tween()
    t.tween_property(pulse, "scale", Vector3(4.0, 0.28, 4.0), 0.20)
    t.tween_callback(pulse.queue_free)

func _on_spell(origin: Vector3, direction: Vector3, damage: int) -> void:
    var ball: MeshInstance3D = MeshInstance3D.new()
    var m: SphereMesh = SphereMesh.new()
    m.radius = 0.36
    m.height = 0.72
    ball.mesh = m
    var mat: StandardMaterial3D = StandardMaterial3D.new()
    mat.albedo_color = Color("84c7ff")
    mat.emission_enabled = true
    mat.emission = Color("70b5ff")
    mat.emission_energy_multiplier = 2.0
    ball.material_override = mat
    add_child(ball)
    ball.global_position = origin + direction * 0.8
    projectiles.append({"node": ball, "direction": direction, "lifetime": 2.5, "damage": damage})

func _update_projectiles(delta: float) -> void:
    for i in range(projectiles.size() - 1, -1, -1):
        var bullet: Dictionary = projectiles[i]
        var node: Node3D = bullet["node"]
        bullet["lifetime"] = float(bullet["lifetime"]) - delta
        var facing: Vector3 = bullet["direction"]
        var nearest: Node3D = null
        var best: float = 16.0
        for enemy in enemies:
            if is_instance_valid(enemy) and not enemy.dying:
                var d: float = node.global_position.distance_to(enemy.global_position + Vector3.UP)
                if d < best:
                    best = d
                    nearest = enemy
        if nearest != null:
            var target_dir: Vector3 = (nearest.global_position + Vector3.UP - node.global_position).normalized()
            facing = facing.lerp(target_dir, minf(1.0, delta * 5.0)).normalized()
            bullet["direction"] = facing
        node.global_position += facing * delta * 17.0
        if nearest != null and best < 1.1:
            nearest.take_hit(int(bullet["damage"]), facing)
            node.queue_free()
            projectiles.remove_at(i)
        elif float(bullet["lifetime"]) < 0:
            node.queue_free()
            projectiles.remove_at(i)

func _on_action(action: String) -> void:
    if ambient_music != null and not ambient_music.playing and ambient_music.stream != null:
        ambient_music.play()
    if action == "close_dialogue":
        hud.hide_dialogue()
        hero.control_locked = false
        return
    if action == "menu":
        var opened: bool = hud.toggle_menu()
        hero.control_locked = opened
        return
    if action == "interact":
        if not hud.is_blocking():
            _interact()
        return
    if action == "potion":
        _message("Recovered HP" if GameData.heal() else "No potion / already healthy")
        return
    if action == "upgrade":
        var price: int = 30 + int(GameData.get_value("weapon", 1)) * 22
        if int(GameData.get_value("gold", 0)) >= price:
            GameData.state["gold"] = int(GameData.state["gold"]) - price
            GameData.state["weapon"] = int(GameData.state["weapon"]) + 1
            GameData.changed.emit()
            _message("Sword upgraded! -%d G" % price)
        else:
            _message("Need %d gold" % price)
        return
    if action == "armor":
        var price: int = 25 + int(GameData.get_value("armor", 1)) * 22
        if int(GameData.get_value("gold", 0)) >= price:
            GameData.state["gold"] = int(GameData.state["gold"]) - price
            GameData.state["armor"] = int(GameData.state["armor"]) + 1
            GameData.changed.emit()
            _message("Armor reinforced! -%d G" % price)
        else:
            _message("Need %d gold" % price)
        return
    if action == "hero":
        var next_id: String = "lyra" if str(GameData.state["hero"]) == "aster" else "aster"
        GameData.state["hero"] = next_id
        hero.set_hero(next_id)
        GameData.changed.emit()
        _message("Hero: " + next_id.capitalize())
        return
    if action == "save":
        _message("Adventure saved" if _save(true) else "Save failed")
        return
    if not hud.is_blocking():
        if not hero.action(action):
            if action == "magic" or action == "skill":
                _message("Action unavailable / not enough MP")

func _interact() -> void:
    var best: float = 3.45
    var kind: String = ""
    var found: Dictionary = {}
    for entry in scenery_npcs:
        var d: float = hero.global_position.distance_to(entry["position"])
        if d < best:
            best = d
            found = entry
            kind = "npc"
    for entry in scenery_chests:
        var d: float = hero.global_position.distance_to(entry["position"])
        if d < best:
            best = d
            found = entry
            kind = "chest"
    for entry in scenery_herbs:
        var d: float = hero.global_position.distance_to(entry["position"])
        if d < best:
            best = d
            found = entry
            kind = "herb"
    match kind:
        "npc":
            _talk(str(found["id"]))
        "chest":
            _open_chest(found)
        "herb":
            scenery_herbs.erase(found)
            found["node"].queue_free()
            GameData.state["herbs"] = int(GameData.get_value("herbs", 0)) + 1
            GameData.state["potions"] = int(GameData.get_value("potions", 0)) + 1
            GameData.changed.emit()
            _message("Moonflower harvested. +1 potion")
        _:
            _message("Nothing to interact with nearby")

func _talk(id: String) -> void:
    var speech: String = ""
    var stage: int = int(GameData.get_value("quest", 0))
    if id == "elder":
        match stage:
            0:
                GameData.state["quest"] = 1
                speech = "Elder Elian: The dawn-star has shattered! Three wild wolves guard the path. Defeat them, and seek the ancient relic."
            1:
                speech = "Elder Elian: The path cannot be crossed until three wolves are driven away."
            2:
                speech = "Elder Elian: The forgotten relic awaits in a chest at the northern ruins."
            3:
                speech = "Elder Elian: The Guardian of Dawn must be overcome. Stay brave."
            4:
                GameData.state["quest"] = 5
                GameData.state["gold"] = int(GameData.get_value("gold", 0)) + 180
                GameData.add_xp(170)
                speech = "Elder Elian: The star shines again! Our kingdom owes you its future. [Quest complete: +180 G, +170 XP]"
            _:
                speech = "Elder Elian: The road beyond Silverwood is only beginning. More chapters are still in development."
    elif id == "smith":
        speech = "Rowan: Your blade needs strengthening. Open MENU to upgrade your sword and armor using gold."
    else:
        if int(GameData.get_value("gold", 0)) >= 20:
            GameData.state["gold"] = int(GameData.get_value("gold", 0)) - 20
            GameData.state["potions"] = int(GameData.get_value("potions", 0)) + 1
            speech = "Mira: A healing potion for 20 gold. Safe travels, adventurer!"
        else:
            speech = "Mira: I sell healing potions for 20 gold. Come back once you've earned enough."
    GameData.changed.emit()
    hero.control_locked = true
    hud.show_dialogue(speech)

func _open_chest(chest: Dictionary) -> void:
    var id: String = str(chest["id"])
    var opened: Array = GameData.get_value("chests", [])
    if opened.has(id):
        return
    opened.append(id)
    GameData.state["chests"] = opened
    scenery_chests.erase(chest)
    chest["node"].queue_free()
    if id == "relic":
        GameData.state["relic"] = true
        if int(GameData.get_value("quest", 0)) == 2:
            GameData.state["quest"] = 3
            _spawn_boss_once()
        _message("Star relic acquired! The ancient guardian awakens.")
    else:
        GameData.state["gold"] = int(GameData.get_value("gold", 0)) + 60
        GameData.state["potions"] = int(GameData.get_value("potions", 0)) + 1
        _message("Treasure! +60 gold and +1 potion")
    GameData.changed.emit()
    _save(false)

func _save(notify: bool) -> bool:
    var ok: bool = GameData.save_game(hero.global_position, rig.yaw)
    if notify and ok:
        _message("Saved")
    return ok

func _message(t: String) -> void:
    if hud != null:
        hud.toast(t)
