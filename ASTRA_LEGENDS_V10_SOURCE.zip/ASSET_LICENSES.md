# Third-party and original assets

## Original v8 content carried into Godot

`assets/models/characters/{aster,lyra}.glb`, `assets/models/environment/*.glb`, `assets/textures/*.png`, `assets/audio/celestial_theme.ogg` are original game assets from the previous ASTRA LEGENDS project. `celestial_theme.ogg` is a transcoding of the self-composed `celestial_theme.m4a` using FFmpeg. Source written for this project; retain applicable original ownership/licensing arrangements.

## Fox (CC BY 4.0; preserve attribution)

- Model title: Fox, Khronos glTF Sample Models, created by PixelMannen, @tomkranis, AsoboStudio, @scurest.
- Source: https://github.com/KhronosGroup/glTF-Sample-Models/tree/main/2.0/Fox
- License: https://creativecommons.org/licenses/by/4.0/
- Asset: `assets/models/creatures/fox_ccby4.gltf`; has skinned mesh plus Survey, Walk, Run clips.
- Runtime adaptation: scale and placement as forest enemy. No change to the source glTF mesh topology.

## Godot Engine

Godot 4.7.2 is MIT-licensed. The engine executable is not included in this archive. See https://godotengine.org/license/

No copied Dragon Quest or Ys characters, models, sounds, music, locations or branding.
