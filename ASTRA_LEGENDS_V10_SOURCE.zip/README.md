# ASTRA LEGENDS — Production Gate v10 (Godot 4.7.2)

本リポジトリはGodotに移行したオリジナル3DアクションRPGの**開発・検証用ソース**です。商用完成品・App Store配信済みアプリではありません。

## 概要

- 3D村／森林／湖／遺跡、主人公2体、モンスター3種＋守護者ボス、第一章クエスト、装備強化・セーブ。
- iPhone横画面を想定したカメラ基準ジョイスティック（上は画面奥、右は画面右）、右側アクションボタン。
- v10: MultiMeshによる森林描画の省コール化、敵の攻撃予告ディスク、ボス重複出現防止、セーブデータ検証。
- `tests/smoke.gd`：Godot実エンジンでシーンの生成と操作を確認するスモークテスト。ただし**現時点では未実行**。
- `.github/workflows/web-preview.yml`：GitHub ActionsでのGodot検証・Webビルド・GitHub Pages配信。
- `.github/workflows/ios-xcode-project.yml`：GitHub macOSランナー上での未署名Xcodeプロジェクト生成（手動実行、Apple Team IDとBundle IDが必要）。

## ファイル

- `project.godot` / `scenes/main.tscn`: Godotプロジェクト
- `scripts/`: 入力、プレイヤー、敵、ワールド、HUD、状態管理、ゲーム進行
- `assets/`: 原創的GLB・テクスチャ・BGM、CC BY 4.0 Fox（ライセンス記載あり）
- `production/check_asset_quality.py`: 主人公のGLB品質検証
- `tests/verify_project.py`: オフライン参照・構文の簡易検査
- `tests/smoke.gd`: Godot実行時の統合テスト
- `qa/`: 配信品質ステータス、iOS用プリセット生成、パッケージ検査
- `docs/DELIVERY_AND_RELEASE_JA.md`: iPhone公開の具体的手順と品質ゲート
- `release/github-pages-from-zip.yml`: iPhoneからGitHubへソースZIP1つだけアップロードする場合の補助ワークフロー

## 開発マシンでの確認（Godotがインストールされている場合）

```bash
python3 tests/verify_project.py
python3 qa/validate_delivery.py
godot --headless --path . --editor --quit
godot --headless --path . --script res://tests/smoke.gd
mkdir -p build/web
godot --headless --path . --export-release "Web" build/web/index.html
```

**注意**: `project.godot`内のGL CompatibilityレンダラーはGodot Web（WebGL2）との互換性を優先した設定です。Safari実機で正常動作する保証ではありません。iPhoneへの公開後、タッチ・カメラ・FPS・発熱・セーブの全検査が必要です。

## 現在の判定

| 項目 | 実績 |
| --- | --- |
| Godotプロジェクト・アセット | 作成 |
| オフライン構造／参照検査 | 合格 |
| Godotエディタによる実行テスト | 未実施 |
| Web版のビルド・公開URL発行 | 未実施 |
| ネイティブiOS IPA・TestFlight・App Store | 未実施 |
| Ys級キャラクター・DQX級コンテンツ | 未達（モデル骨格／表情を含む品質ゲート不合格） |

前提：利用可能なGitHubリポジトリがまだなく、この環境ではGodot実行ファイル、Mac/Xcode、Apple署名設定にアクセスできません。以上を「達成済み」と誤記しないこと。
