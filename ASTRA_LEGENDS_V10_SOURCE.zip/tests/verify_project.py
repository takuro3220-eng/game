#!/usr/bin/env python3
"""Offline static tests; NOT a replacement for Godot editor, WebGL or iOS E2E tests."""
from pathlib import Path
import json, math, re, struct, sys
P=Path(__file__).resolve().parents[1]
failures=[]; checks=[]

def check(cond, text):
    (checks if cond else failures).append(text)

def validate_brackets(path):
    # Basic GDScript structural check ignoring line comments and literal strings.
    t=path.read_text(encoding='utf-8')
    stack=[]; pair={')':'(',']':'[','}':'{'}
    quote=None; triple=False; escape=False; comment=False;i=0
    while i<len(t):
        c=t[i]
        if c=='\n': comment=False
        if comment: i+=1;continue
        if quote:
            if escape: escape=False;i+=1;continue
            if c=='\\':escape=True;i+=1;continue
            if triple and t[i:i+3]==quote*3:quote=None;triple=False;i+=3;continue
            if not triple and c==quote:quote=None;i+=1;continue
            i+=1;continue
        if c=='#':comment=True;i+=1;continue
        if c in "\"'":
            triple=t[i:i+3]==c*3;quote=c;i+=3 if triple else 1;continue
        if c in '([{':stack.append(c)
        elif c in ')]}':
            if not stack or stack.pop()!=pair[c]:return False
        i+=1
    return not stack and not quote

for s in sorted((P/'scripts').glob('*.gd')):
    check(validate_brackets(s),f'balanced blocks/brackets {s.name}')
    lines=s.read_text().splitlines()
    check(all(not l.startswith('\t') for l in lines),f'spaces indentation {s.name}')
    for path in re.findall(r'res://[A-Za-z0-9_./\-]+\.(?:gd|glb|gltf|png|ogg|tscn)',s.read_text()):
        check((P/path[6:]).is_file(),f'file ref {path}')

for f in [P/'scenes/main.tscn',P/'project.godot',P/'export_presets.cfg', P/'.github/workflows/web-preview.yml']:
    check(f.exists(),f'{f.name} exists')

from importlib.machinery import SourceFileLoader
sys.path.insert(0,str(P/'production'))
from check_asset_quality import summary
for n in ('aster','lyra'):
    data=summary(P/'assets/models/characters'/f'{n}.glb')
    check(not data['missing_clips'],f'{n} has 9 named gameplay clips')
    check(data['triangles']>1000,f'{n} original polygon asset present')
    check(data['skins']==0,f'{n} correctly reported as NOT skeletal skinned')
fox=json.loads((P/'assets/models/creatures/fox_ccby4.gltf').read_text())
check(len(fox.get('skins',[]))>0,'Fox really is skinned')
check({'Survey','Walk','Run'}.issubset({x.get('name') for x in fox.get('animations',[])}),'Fox animations')
check((P/'assets/audio/celestial_theme.ogg').read_bytes()[:4]==b'OggS','Ogg soundtrack is valid container')

# Exact intent of joystick code: axis up negative-y => camera forward, right => camera right.
player=(P/'scripts/player.gd').read_text()
check('forward.normalized() * -axis.y' in player and 'right.normalized() * axis.x' in player,'stick direction calculation')
for yaw in [0,0.38,1.2,2.4,3.14159,4.8]:
    right=(math.cos(yaw),-math.sin(yaw))
    forward=(-math.sin(yaw),-math.cos(yaw))
    for input_x,input_y,target in [(0,-1,forward),(1,0,right)]:
        desired=(input_x*right[0]-input_y*forward[0], input_x*right[1]-input_y*forward[1])
        dot=desired[0]*target[0]+desired[1]*target[1]
        check(dot>0.9999,f'camera yaw {yaw:.2f} stick {input_x,input_y}')

report={'status':'PASS' if not failures else 'FAIL','passed':len(checks),'failed':len(failures),'failures':failures,'notes':['No Godot executable in this runtime; GDScript parse/scene execution NOT performed','iPhone gamepad/UI/3D rendering not device-tested','External engine Godot 4.7.2 and export templates are not included']}
(P/'docs/STATIC_TEST_RESULT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2))
if failures:sys.exit(1)
