extends SceneTree
## Runs only inside actual Godot. Failure prevents Web release in CI.
## Usage: godot --headless --path . --script res://tests/smoke.gd

var errors: Array[String] = []

func _initialize() -> void:
    call_deferred("_run")

func _require(ok: bool, description: String) -> void:
    if ok:
        print("PASS | " + description)
    else:
        push_error("FAIL | " + description)
        errors.append(description)

func _run() -> void:
    var scene: PackedScene = load("res://scenes/main.tscn") as PackedScene
    _require(scene != null, "Main scene loads")
    if scene == null:
        quit(1)
        return
    var game: Node = scene.instantiate()
    root.add_child(game)
    await process_frame
    await physics_frame
    var hero: Node3D = game.get("hero") as Node3D
    var world: Node3D = game.get("world") as Node3D
    var hud: Control = game.get("hud") as Control
    var rig: Node3D = game.get("rig") as Node3D
    _require(hero != null and is_instance_valid(hero), "Player is spawned")
    _require(world != null and is_instance_valid(world), "Continuous world spawned")
    _require(hud != null and is_instance_valid(hud), "Landscape HUD spawned")
    _require(rig != null and is_instance_valid(rig), "Third-person camera spawned")
    if hero != null and rig != null:
        _require(hero.get("camera_ref") != null, "Camera linked to hero")
        var pos: Vector3 = hero.global_position
        hero.set("input_axis", Vector2(0.0, -1.0))
        for i in range(12):
            await physics_frame
        _require(hero.global_position.distance_to(pos) > 0.01, "Joystick forward creates actual movement")
        hero.set("input_axis", Vector2.ZERO)
    var data: Node = root.get_node_or_null("GameData")
    _require(data != null, "Save manager autoload available")
    if data != null:
        var old_gold: int = int(data.call("get_value", "gold", 0))
        data.call("add_xp", 55)
        _require(int(data.call("get_value", "xp", 0)) >= 0, "XP progression callable")
        data.set("state", data.get("state"))
        _require(int(data.call("get_value", "gold", 0)) == old_gold, "Gameplay state remains coherent")
    if game != null:
        game.queue_free()
    await process_frame
    if errors.is_empty():
        print("SMOKE RESULT: PASS")
        quit(0)
    else:
        print("SMOKE RESULT: FAIL | %d errors" % errors.size())
        quit(1)
