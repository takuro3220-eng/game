#!/usr/bin/env python3
"""Generate a non-signing, Xcode-project-only iOS export preset; never stores credentials."""
import argparse, re, pathlib, sys
p=argparse.ArgumentParser()
p.add_argument('--team-id',required=True)
p.add_argument('--bundle-id',required=True)
a=p.parse_args()
if not re.fullmatch(r'[A-Z0-9]{10}', a.team_id):
 sys.exit('Team ID must be 10 uppercase letters/digits')
if not re.fullmatch(r'[A-Za-z][A-Za-z0-9-]*(?:\.[A-Za-z0-9-]+){2,}',a.bundle_id):
 sys.exit('Bundle ID must be reverse-DNS: com.example.astralegends')
f=pathlib.Path(__file__).resolve().parents[1]/'export_presets.cfg'
s=f.read_text()
if '[preset.1]' in s:
 s=s.split('[preset.1]')[0].rstrip()+'\n\n'
s += f'''[preset.1]
name="iOS"
platform="iOS"
runnable=false
advanced_options=false
custom_features=""
export_filter="all_resources"
include_filter=""
exclude_filter=""
export_path="build/ios/AstraLegends.zip"
encryption_include_filters=""
encryption_exclude_filters=""
encrypt_pck=false
encrypt_directory=false
script_export_mode=2

[preset.1.options]
application/app_store_team_id="{a.team_id}"
application/bundle_identifier="{a.bundle_id}"
application/export_project_only=true
application/min_ios_version="15.0"
'''
f.write_text(s)
print('Added project-only iOS preset; no signing or IPA uploaded')
