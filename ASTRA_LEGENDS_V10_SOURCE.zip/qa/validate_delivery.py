#!/usr/bin/env python3
"""Verifies release packaging and exposes unsupported commercial claims."""
from pathlib import Path
from importlib.machinery import SourceFileLoader
import json, re, sys, yaml
root=Path(__file__).resolve().parents[1]
issues=[]
required=[
 'project.godot','scenes/main.tscn','scripts/game_root.gd','scripts/player.gd',
 'scripts/world_builder.gd','scripts/enemy.gd','scripts/touch_hud.gd',
 'tests/smoke.gd','tests/verify_project.py',
 '.github/workflows/web-preview.yml','.github/workflows/ios-xcode-project.yml',
 'assets/models/characters/aster.glb','assets/models/characters/lyra.glb',
 'assets/models/creatures/fox_ccby4.gltf','assets/audio/celestial_theme.ogg'
]
for name in required:
 if not (root/name).is_file():issues.append('missing '+name)
wf=yaml.safe_load((root/'.github/workflows/web-preview.yml').read_text())
steps=wf['jobs']['test-build-deploy']['steps']
steps_text=' '.join(str(x) for x in steps)
for term in ['smoke.gd','--export-release','deploy-pages@v4','upload-artifact@v4']:
 if term not in steps_text:issues.append('CI missing '+term)
gd=(root/'scripts/world_builder.gd').read_text()
if 'MultiMeshInstance3D' not in gd:issues.append('batched foliage not implemented')
en=(root/'scripts/enemy.gd').read_text()
if '_create_warning_ring()' not in en:issues.append('telegraph missing')
from sys import path
path.insert(0,str(root/'production'))
from check_asset_quality import summary
heroes=[summary(root/'assets/models/characters'/f'{c}.glb') for c in ('aster','lyra')]
quality_gate_pass=all(h['professional_skeletal_gate'] for h in heroes)
status={
 'offline_file_checks':'PASS' if not issues else 'FAIL',
 'issues':issues,
 'forest_instancing':'present',
 'attack_telegraph':'present',
 'web_build':'NOT_RUN',
 'godot_engine_smoke':'NOT_RUN',
 'native_ipa':'NOT_BUILT',
 'apple_testflight':'NOT_SUBMITTED',
 'app_store':'NOT_PUBLISHED',
 'iPhone_device_test':'NOT_RUN',
 'commercial_hero_asset_gate':'PASS' if quality_gate_pass else 'FAIL',
 'hero_assets':heroes,
}
(root/'qa/DELIVERY_STATUS.json').write_text(json.dumps(status,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in status.items() if k not in ('hero_assets',)},ensure_ascii=False,indent=2))
sys.exit(1 if issues else 0)
