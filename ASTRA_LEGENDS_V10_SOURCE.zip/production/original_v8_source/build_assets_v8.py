#!/usr/bin/env python3
"""Original 3D asset source generator for ASTRA LEGENDS v7.
No commercial models are copied or downloaded. Generates real binary GLB with
PBR materials, reusable mesh primitives, named articulated hierarchies, and
8 independent glTF animation clips. Blender-ready GLBs are the authored source.
"""
from __future__ import annotations
import os, json, struct, math, io, random, pathlib
from dataclasses import dataclass
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT=pathlib.Path(__file__).resolve().parents[1]
CHARS=ROOT/'models/characters'; ENV=ROOT/'models/environment'; SOURCE=ROOT/'source'
for p in (CHARS,ENV,SOURCE):p.mkdir(parents=True,exist_ok=True)


def geom_sphere(lon=18,lat=12):
    verts=[]; normals=[]; uvs=[]; inds=[]
    for j in range(lat+1):
        t=math.pi*j/lat
        for i in range(lon+1):
            p=i/lon*2*math.pi
            x=math.sin(t)*math.cos(p);y=math.cos(t);z=math.sin(t)*math.sin(p)
            verts.append((x,y,z));normals.append((x,y,z));uvs.append((i/lon,1-j/lat))
    for j in range(lat):
        for i in range(lon):
            a=j*(lon+1)+i;b=a+lon+1
            inds.extend([a,a+1,b,a+1,b+1,b])
    return verts,normals,uvs,inds

def geom_cylinder(n=14,top=1.,bottom=1.):
    v=[];norm=[];uv=[];ind=[]
    for row,(y,r) in enumerate([(-.5,bottom),(.5,top)]):
        for j in range(n+1):
            a=j/n*2*math.pi;x=math.cos(a);z=math.sin(a)
            v.append((x*r,y,z*r));norm.append((x,0,z));uv.append((j/n,float(row)))
    for j in range(n):
        a=j;b=j+n+1;ind.extend([a,b,a+1,a+1,b,b+1])
    for row,(y,r) in enumerate([(-.5,bottom),(.5,top)]):
        if r<=0:continue
        center=len(v);v.append((0,y,0));norm.append((0,-1 if row==0 else 1,0));uv.append((.5,.5))
        for j in range(n+1):
            a=j/n*2*math.pi;x=math.cos(a);z=math.sin(a)
            v.append((x*r,y,z*r));norm.append((0,-1 if row==0 else 1,0));uv.append((.5+.5*x,.5+.5*z))
        for j in range(n):
            if row==0:ind.extend([center,center+j+1,center+j+2])
            else:ind.extend([center,center+j+2,center+j+1])
    return v,norm,uv,ind

def geom_cube():
    v=[];n=[];uv=[];ind=[]
    fs=[((0,0,1),[(-.5,-.5,.5),(.5,-.5,.5),(.5,.5,.5),(-.5,.5,.5)]),((0,0,-1),[(.5,-.5,-.5),(-.5,-.5,-.5),(-.5,.5,-.5),(.5,.5,-.5)]),((1,0,0),[(.5,-.5,.5),(.5,-.5,-.5),(.5,.5,-.5),(.5,.5,.5)]),((-1,0,0),[(-.5,-.5,-.5),(-.5,-.5,.5),(-.5,.5,.5),(-.5,.5,-.5)]),((0,1,0),[(-.5,.5,.5),(.5,.5,.5),(.5,.5,-.5),(-.5,.5,-.5)]),((0,-1,0),[(-.5,-.5,-.5),(.5,-.5,-.5),(.5,-.5,.5),(-.5,-.5,.5)])]
    for normal,pts in fs:
        k=len(v);v+=pts;n += [normal]*4;uv += [(0,0),(1,0),(1,1),(0,1)];ind.extend([k,k+1,k+2,k,k+2,k+3])
    return v,n,uv,ind

def geom_ribbon(points,widths):
    # A double-sided, sculpted cape/hair/fabric ribbon, facing the camera (+Z)
    n=len(points);v=[];norm=[];uv=[];ind=[]
    for i,((x,y,z),w) in enumerate(zip(points,widths)):
        v.extend([(x-w/2,y,z),(x+w/2,y,z)]);norm.extend([(0,0,1),(0,0,1)]);uv.extend([(0,1-i/(n-1)),(1,1-i/(n-1))])
    for i in range(n-1):
        a=i*2;ind.extend([a,a+1,a+2,a+1,a+3,a+2]);ind.extend([a+2,a+1,a,a+2,a+3,a+1])
    return v,norm,uv,ind

def geom_hair_path(points,radius=.11,n=8):
    # Tapered tubular locks with smoothed quadratic interpolation
    P=np.array(points,dtype=float);v=[];norm=[];uv=[];ind=[]
    samples=[]
    for j in range((len(P)-1)*4+1):
        u=j/4;ix=min(int(u),len(P)-2);t=u-ix
        a=P[max(0,ix-1)];b=P[ix];c=P[ix+1];d=P[min(len(P)-1,ix+2)]
        pos=.5*((2*b)+(-a+c)*t+(2*a-5*b+4*c-d)*t*t+(-a+3*b-3*c+d)*t*t*t)
        samples.append(pos)
    samples=np.array(samples)
    for i,p in enumerate(samples):
        tangent=samples[min(i+1,len(samples)-1)]-samples[max(0,i-1)]
        tangent/=max(np.linalg.norm(tangent),1e-9)
        n0=np.cross(tangent,np.array([0,0,1]));
        if np.linalg.norm(n0)<.1:n0=np.cross(tangent,np.array([0,1,0]))
        n0/=max(np.linalg.norm(n0),1e-9);b0=np.cross(tangent,n0)
        r=radius*(1-i/max(1,len(samples)-1))**.65+.004
        for j in range(n):
            a=2*math.pi*j/n;out=n0*math.cos(a)+b0*math.sin(a);v.append(tuple(p+out*r));norm.append(tuple(out));uv.append((j/n,i/max(1,len(samples)-1)))
    for i in range(len(samples)-1):
        for j in range(n):
            a=i*n+j;b=i*n+(j+1)%n;c=(i+1)*n+j;d=(i+1)*n+(j+1)%n
            ind.extend([a,b,c,b,d,c])
    return v,norm,uv,ind

def euler_q(x=0.,y=0.,z=0.):
    # Euler XYZ to quaternion
    cx,sx=math.cos(x/2),math.sin(x/2);cy,sy=math.cos(y/2),math.sin(y/2);cz,sz=math.cos(z/2),math.sin(z/2)
    return [sx*cy*cz+cx*sy*sz,cx*sy*cz-sx*cy*sz,cx*cy*sz+sx*sy*cz,cx*cy*cz-sx*sy*sz]

class GLB:
    def __init__(self,label):
        self.label=label;self.nodes=[];self.meshes=[];self.materials=[];self.materialIds={};self.geometryCache={};self.meshCache={};self.accessors=[];self.views=[];self.bin=bytearray();self.clips=[];self.textures=[];self.images=[];self.samplers=[]
        self.root=self.group('AssetRoot')
    def pack(self,data):
        while len(self.bin)%4:self.bin.append(0)
        off=len(self.bin);self.bin.extend(data)
        view=len(self.views);self.views.append({'buffer':0,'byteOffset':off,'byteLength':len(data)})
        return view
    def acc(self,values,typ='VEC3',component=5126,target=None):
        arr=np.asarray(values,dtype=np.float32 if component==5126 else np.uint16)
        if typ=='SCALAR':arr=arr.reshape(-1,1)
        view=self.pack(arr.tobytes());self.views[view].update({'target':target} if target else {})
        a={'bufferView':view,'componentType':component,'count':len(arr),'type':typ}
        if component==5126 and typ in ('VEC3','SCALAR'):
            a['min']=np.min(arr,axis=0).astype(float).tolist();a['max']=np.max(arr,axis=0).astype(float).tolist()
        self.accessors.append(a);return len(self.accessors)-1
    def mat(self,name,color,metal=0.,rough=.7,emissive=None,tex=None,double=False):
        key=(name,str(color),metal,rough,str(emissive),tex,double)
        if key in self.materialIds:return self.materialIds[key]
        color=color.lstrip('#');rgb=[int(color[i:i+2],16)/255 for i in (0,2,4)]
        m={'name':name,'pbrMetallicRoughness':{'baseColorFactor':rgb+[1.],'metallicFactor':metal,'roughnessFactor':rough}}
        if emissive:
            ee=emissive.lstrip('#');m['emissiveFactor']=[int(ee[i:i+2],16)/255 for i in (0,2,4)]
        if double:m['doubleSided']=True
        if tex is not None:m['pbrMetallicRoughness']['baseColorTexture']={'index':self.add_texture(tex)}
        self.materialIds[key]=len(self.materials);self.materials.append(m);return len(self.materials)-1
    def add_texture(self,name):
        # texture registration uses embedded PNG from original generated texture source
        for i,t in enumerate(self.textures):
            if t.get('name')==name:return i
        path=SOURCE/f'{name}.png';blob=path.read_bytes();view=self.pack(blob)
        im=len(self.images);self.images.append({'name':name,'bufferView':view,'mimeType':'image/png'})
        self.textures.append({'name':name,'source':im,'sampler':0});return len(self.textures)-1
    def geo(self,key,fn):
        if key not in self.geometryCache:
            v,n,uv,ind=fn()
            attrs={'POSITION':self.acc(v,'VEC3',5126,34962),'NORMAL':self.acc(n,'VEC3',5126,34962),'TEXCOORD_0':self.acc(uv,'VEC2',5126,34962)}
            indices=self.acc(ind,'SCALAR',5123,34963)
            self.geometryCache[key]=(attrs,indices)
        return self.geometryCache[key]
    def primitive(self,geomkey,fn,material):
        cachekey=(geomkey,material)
        if cachekey in self.meshCache:return self.meshCache[cachekey]
        attrs,indices=self.geo(geomkey,fn)
        mesh=len(self.meshes);self.meshes.append({'name':str(geomkey),'primitives':[{'attributes':attrs,'indices':indices,'material':material}]})
        self.meshCache[cachekey]=mesh;return mesh
    def group(self,name,parent=None,t=None,r=None,s=None,mesh=None):
        d={'name':name}
        if t is not None:d['translation']=list(map(float,t))
        if r is not None:d['rotation']=list(map(float,r))
        if s is not None:d['scale']=list(map(float,s))
        if mesh is not None:d['mesh']=mesh
        idx=len(self.nodes);self.nodes.append(d)
        if parent is not None:self.nodes[parent].setdefault('children',[]).append(idx)
        return idx
    def shape(self,name,parent,kind,mat,t=(0,0,0),s=(1,1,1),r=None,detail='medium'):
        if kind=='sphere': key=('sphere',detail);fn=lambda:geom_sphere(20,14) if detail=='high' else geom_sphere(14,10)
        elif kind=='cube':key=('cube',);fn=geom_cube
        elif kind=='cylinder':key=('cylinder',);fn=lambda:geom_cylinder(16)
        elif kind=='cone':key=('cone',);fn=lambda:geom_cylinder(14,0,1)
        elif kind=='torus':key=('torus',);fn=lambda:self._torus()
        else:raise ValueError(kind)
        return self.group(name,parent,t,r,s,self.primitive(key,fn,mat))
    def _torus(self):
        v=[];norm=[];uv=[];ind=[];R=1.;r=.12;ns=22;nt=8
        for a in range(ns+1):
            u=a/ns*2*math.pi
            for b in range(nt+1):
                w=b/nt*2*math.pi;normal=(math.cos(u)*math.cos(w),math.sin(w),math.sin(u)*math.cos(w));v.append(((R+r*math.cos(w))*math.cos(u),r*math.sin(w),(R+r*math.cos(w))*math.sin(u)));norm.append(normal);uv.append((a/ns,b/nt))
        for a in range(ns):
            for b in range(nt):
                k=a*(nt+1)+b;ind.extend([k,k+1,k+nt+1,k+1,k+nt+2,k+nt+1])
        return v,norm,uv,ind
    def custom(self,name,parent,geom,mat,t=None,s=None,r=None):
        key=('unique',name);return self.group(name,parent,t,r,s,self.primitive(key,lambda:geom,mat))
    def animate(self,name,duration,tracks,n=12):
        # tracks mapping node ID => dict rot(t), translate(t), scale(t)
        animation={'name':name,'channels':[],'samplers':[]}
        ts=np.linspace(0,duration,n,dtype=float).tolist()
        ti=self.acc(ts,'SCALAR')
        for node,channels in tracks.items():
            for path,fn in channels.items():
                values=[fn(float(t),duration) for t in ts]
                ai=self.acc(values,'VEC4' if path=='rotation' else 'VEC3')
                s=len(animation['samplers']);animation['samplers'].append({'input':ti,'output':ai,'interpolation':'LINEAR'})
                animation['channels'].append({'sampler':s,'target':{'node':node,'path':path}})
        self.clips.append(animation)
    def save(self,path):
        gltf={'asset':{'version':'2.0','generator':'ASTRA LEGENDS original procedural 3D asset authoring pipeline v8'},'scene':0,'scenes':[{'nodes':[self.root]}], 'nodes':self.nodes,'meshes':self.meshes,'materials':self.materials,'buffers':[{'byteLength':len(self.bin)}],'bufferViews':self.views,'accessors':self.accessors}
        if self.clips:gltf['animations']=self.clips
        if self.images:gltf.update(images=self.images,textures=self.textures,samplers=[{'magFilter':9729,'minFilter':9987,'wrapS':10497,'wrapT':10497}])
        meta=json.dumps(gltf,ensure_ascii=False,separators=(',',':')).encode('utf-8')
        while len(meta)%4:meta+=b' '
        while len(self.bin)%4:self.bin.append(0)
        length=12+8+len(meta)+8+len(self.bin)
        path=pathlib.Path(path);path.parent.mkdir(parents=True,exist_ok=True)
        with open(path,'wb') as f:
            f.write(struct.pack('<4sII',b'glTF',2,length));f.write(struct.pack('<I4s',len(meta),b'JSON'));f.write(meta);f.write(struct.pack('<I4s',len(self.bin),b'BIN\0'));f.write(self.bin)
        print(f'{path.relative_to(ROOT)}: {round(length/1024)} KB, {len(self.nodes)} nodes, {len(self.clips)} clips, {len(self.meshes)} mesh patterns')

# hand-painted texture source: deterministic palette-noise, embedded in GLBs
from PIL import Image, ImageDraw

def make_tex(name,colors,scale=4,lines=False):
    rnd=random.Random(name);w=256;im=Image.new('RGB',(w,w));pix=im.load()
    a=np.array([int(colors[0][i:i+2],16) for i in (1,3,5)])
    b=np.array([int(colors[1][i:i+2],16) for i in (1,3,5)])
    for y in range(w):
        for x in range(w):
            n=.14*math.sin(x*.14+math.sin(y*.08))+.09*math.cos(y*.23)+rnd.uniform(-.055,.055)
            c=np.clip(a*(.72+n)+b*(.28-n),0,255).astype(int)
            if lines and (y%64 in (0,1) or x%128 in (0,1)):c=(c*.55).astype(int)
            pix[x,y]=tuple(map(int,c))
    im=im.filter(ImageFilter.GaussianBlur(.45));im.save(SOURCE/f'{name}.png')

for name,cs,line in [('weave_blue',('#416A99','#1B375E'),False),('weave_red',('#A65669','#54304C'),False),('weave_cream',('#F3E1CC','#C2B39E'),False),('wood',('#B18B68','#584334'),True),('stone',('#A9B9AF','#6B817F'),True),('leaf',('#6B9C72','#284F47'),False),('roof',('#B97579','#6E405B'),True)]:make_tex(name,cs,lines=line)


def char(girl=False):
    characterName='Lyra' if girl else 'Aster';b=GLB(characterName)
    skin=b.mat('warm porcelain skin','#F8D8BF',rough=.77)
    skinShade=b.mat('skin sculpt shadow','#D7A48F',rough=.9)
    coat=b.mat('embroidered azure coat' if not girl else 'scarlet mage tunic','#FFFFFF',rough=.76,tex='weave_red' if girl else 'weave_blue')
    cape=b.mat('silk cape','#6F2F51' if girl else '#274B74',rough=.88,double=True)
    hair=b.mat('heroine hair' if girl else 'hero hair','#E8BDD0' if girl else '#2E354E',rough=.61)
    hairShade=b.mat('underlying hair','#AD789B' if girl else '#171D32',rough=.79)
    ivory=b.mat('luminous ivory','#F8F0E3',rough=.72)
    leather=b.mat('calf leather','#3B313B',rough=.86)
    gold=b.mat('etched champagne gold','#C8A875',metal=.56,rough=.33)
    silver=b.mat('satin steel','#C9DEE8',metal=.72,rough=.27)
    dark=b.mat('eyeliner','#252335',rough=.9)
    whites=b.mat('eyewhites','#FFFCF5',rough=.3)
    iris=b.mat('deep gemstone irises','#5E76B0' if girl else '#3999C1',rough=.23)
    pupil=b.mat('pupils','#0D1C35',rough=.31)
    shine=b.mat('eye sparkle','#F6FFFF',rough=.13,emissive='#C9FFFF')
    gem=b.mat('star sapphire','#54CFE7',metal=.23,rough=.22,emissive='#3F9FB7')
    # fully distinct hierarchy, usable as editable pivot rig in DCC and game
    hips=b.group('Hips',b.root,t=(0,1.10,0));spine=b.group('Spine',hips,t=(0,.37,0));head=b.group('Head',spine,t=(0,1.00,.01),s=(.83,.83,.83));capeBone=b.group('Cape',spine,t=(0,.43,-.20))
    armL=b.group('UpperArm_L',spine,t=(-.355,.405,0));armR=b.group('UpperArm_R',spine,t=(.355,.405,0));legL=b.group('Leg_L',hips,t=(-.16,-.075,0));legR=b.group('Leg_R',hips,t=(.16,-.075,0))
    pony=b.group('HairTail',head,t=(0,.27,-.245));sword=b.group('Sword_R',armR,t=(.03,-.73,.045))
    S=lambda nm,par,kind,ma,t,s,r=None:b.shape(nm,par,kind,ma,t,s,r)
    C=lambda nm,par,pts,rs,ma:b.custom(nm,par,geom_hair_path(pts,rs),ma)
    S('waist_and_belt',hips,'sphere',coat,(0,0,0),(.27,.18,.19));S('clasp',hips,'sphere',gold,(0,-.005,.195),(.12,.09,.035))
    S('hero_torso',spine,'sphere',coat,(0,.07,0),(.305,.50,.22))
    S('layered_shirt',spine,'sphere',ivory,(0,.1,.132),(.235,.375,.11))
    S('chestplate',spine,'sphere',gold,(0,.30,.163),(.305,.16,.105))
    S('shirt_ruffle',spine,'sphere',ivory,(0,.42,.195),(.12,.16,.07))
    for s in [-1,1]:
        S(f'coat_side_fall_{s}',hips,'sphere',coat,(s*.18,-.35,0),(.16,.38,.17))
        S(f'hip_golden_clasp_{s}',hips,'sphere',gold,(s*.24,-.15,.09),(.045,.11,.07))
    S('star_brooch',spine,'sphere',gem,(0,.42,.247),(.09,.105,.055))
    S('neck',spine,'cylinder',skin,(0,.55,0),(.10,.20,.10))
    S('head_primary',head,'sphere',skin,(0,.022,0),(.293,.375,.276))
    S('chin',head,'sphere',skin,(0,-.20,.058),(.225,.165,.218))
    for side in [-1,1]:
        S(f'ear_{side}',head,'sphere',skin,(side*.295,0,-.01),(.060,.110,.06))
        S(f'inner_ear_{side}',head,'sphere',skinShade,(side*.333,-.009,.014),(.023,.060,.023))
        eye_x=side*.132
        S(f'eye_sclera_{side}',head,'sphere',whites,(eye_x,.058,.257),(.083,.092,.032))
        S(f'iris_{side}',head,'sphere',iris,(eye_x,.052,.289),(.052,.074,.024))
        S(f'pupil_{side}',head,'sphere',pupil,(eye_x,.056,.308),(.025,.054,.016))
        S(f'sparkle_{side}',head,'sphere',shine,(eye_x-.024,.091,.319),(.017,.024,.008))
        S(f'upper_lash_{side}',head,'sphere',dark,(eye_x,.162,.287),(.090,.024,.04))
        S(f'eyebrow_{side}',head,'sphere',hairShade,(eye_x,.256,.259),(.09,.020,.019))
        S(f'cheek_{side}',head,'sphere',skinShade,(side*.225,-.10,.190),(.065,.023,.015))
    S('nose',head,'sphere',skin,(0,-.035,.281),(.034,.042,.045));S('mouth',head,'sphere',skinShade,(0,-.175,.256),(.056,.013,.014))
    S('hair_crown',head,'sphere',hair,(0,.322,-.022),(.318,.174,.307))
    S('hair_back',head,'sphere',hair,(0,.235,-.18),(.306,.23,.193))
    for side in [-1,1]:
        C(f'side_lock_{side}',head,[(side*.235,.33,-.03),(side*.34,.19,.08),(side*.29,-.08,.15),(side*.245,-.26,.11)],.102,hair)
        C(f'fine_side_lock_{side}',head,[(side*.29,.34,-.11),(side*.345,.12,-.065),(side*.30,-.18,-.04)],.055,hairShade)
    bangs=[(-.252,.39,-.04,-.24,.14,.26),(-.12,.39,.015,-.15,.06,.293),(.007,.45,-.07,.015,.13,.32),(.12,.43,-.05,.17,.18,.29),(.246,.37,-.04,.27,.23,.23)]
    for i,(x,y,z,ex,ey,ez) in enumerate(bangs):C(f'swept_bang_{i}',head,[(x,y,z),(.8*x,y-.055,.15),(.85*ex,(y+ey)/2,.27),(ex,ey,ez)],.105 if i!=2 else .145,hair if i%3 else hairShade)
    if girl:
        S('hairband',pony,'sphere',gold,(0,.05,0),(.115,.085,.103))
        for i in range(6):
            x=(i-2.5)*.073
            C(f'long_hair_{i}',pony,[(x,.04,-.03),(x*1.2,-.25,-.1),(x*1.4,-.61,-.19),(x*1.35,-.95,-.1)],.105,hair if i%2 else hairShade)
    else:
        for i in range(8):
            a=2*math.pi*i/8;cx=math.sin(a)*.24;zz=math.cos(a)*.19
            C(f'back_swept_hair_{i}',head,[(cx,.35,zz),(cx*1.3,.42,zz*1.35),(cx*1.5,.22,zz*1.6)],.095,hair)
    # Slim long-legged silhouette and articulated gauntlets
    for side,leg in ((-1,legL),(1,legR)):
        S(f'thigh_{side}',leg,'cylinder',coat,(0,-.23,0),(.14,.47,.145))
        S(f'knee_{side}',leg,'sphere',gold,(0,-.46,.046),(.135,.122,.14))
        S(f'shin_{side}',leg,'cylinder',leather,(0,-.69,0),(.12,.44,.14))
        S(f'boot_{side}',leg,'sphere',leather,(0,-.92,.09),(.17,.118,.25))
        S(f'boot_trim_{side}',leg,'cube',gold,(0,-.805,.18),(.20,.028,.17))
    for side,arm in ((-1,armL),(1,armR)):
        S(f'pauldron_{side}',arm,'sphere',gold,(0,-.052,0),(.165,.16,.20))
        S(f'upper_sleeve_{side}',arm,'cylinder',coat,(side*.013,-.29,0),(.145,.45,.15))
        S(f'bracer_{side}',arm,'cylinder',silver,(side*.034,-.55,.015),(.14,.23,.15))
        S(f'glove_{side}',arm,'sphere',skin,(side*.034,-.735,.022),(.104,.13,.115))
    # Built-in blade; survives model swap, synced to Sword_R animation track
    S('sword_hilt',sword,'cylinder',leather,(0,.035,0),(.060,.38,.060))
    S('sword_guard',sword,'cube',gold,(0,.26,0),(.47,.075,.12))
    S('sword_blade',sword,'cube',silver,(0,.80,.0),(.105,1.10,.039))
    S('sword_tip',sword,'cone',silver,(0,1.385,0),(.090,.24,.051))
    S('sword_gem',sword,'sphere',gem,(0,.27,.087),(.068,.080,.025))
    # curved, multi-layer cloth back, pivoted for hair/cape motion
    cape_points=[(0,0,0),(0,-.28,-.04),(0,-.65,-.17),(0,-1.07,-.27),(0,-1.32,-.18)]
    b.custom('cape_primary',capeBone,geom_ribbon(cape_points,[.44,.57,.68,.77,.72]),cape)
    b.custom('cape_lining',capeBone,geom_ribbon([(x,y,z-.012) for x,y,z in cape_points],[.29,.48,.55,.63,.62]),gold)
    for side in (-1,1):
        C(f'cape_gold_cord_{side}',capeBone,[(side*.20,-.02,0),(side*.285,-.36,-.05),(side*.32,-.8,-.15),(side*.35,-1.21,-.2)],.021,gold)
    # eight authored quaternion animation clips (no JS sine-wave limb swinging)
    clips={}
    def make_tracks(mode):
        def vals(t,D):
            f=t/D;sin=math.sin;pi=math.pi
            x=sin(f*2*pi);y=sin(f*4*pi)
            if mode=='Idle':return {'hips':(0,0,.01*x),'spine':(.017*sin(f*2*pi),.018*x,.007*y),'head':(.014*y,.032*x,0),'armL':(.035*x,0,-.08),'armR':(-.03*x,0,.075),'legL':(0,0,0),'legR':(0,0,0),'cape':(.08+.035*x,0,.02*y),'sword':(-1.24,0,0),'pony':(.04*x,0,.04*y)}
            if mode=='Run':return {'hips':(.05*y,0,.017*x),'spine':(.12+.03*y,.02*x,0),'head':(-.08,0,.01*x),'armL':(-.55*x,0,-.10),'armR':(.50*x,0,.11),'legL':(.71*x,0,0),'legR':(-.71*x,0,0),'cape':(.35+.1*y,0,0),'sword':(-1.12+.08*x,0,0),'pony':(.10+.06*y,0,.045*x)}
            if mode.startswith('Attack'):
                swing=math.sin(min(1,f)*pi);severity={'Attack1':1,'Attack2':1.2,'Attack3':1.45}[mode]
                return {'hips':(0,.15*severity*swing,0),'spine':(-.10*swing,.45*severity*swing,.02*swing),'head':(-.03,.08*swing,0),'armL':(.28*swing,0,-.15),'armR':(-2.35+1.65*swing,0,-.65+.72*swing),'legL':(-.10*swing,0,-.06),'legR':(.08*swing,0,.07),'cape':(.33+.30*swing,0,.13*swing),'sword':(-1.7+.7*swing,0,.25*swing),'pony':(.22*swing,0,.2*swing)}
            if mode=='Dodge':return {'hips':(-.3*math.sin(pi*f),0,0),'spine':(-.55*math.sin(pi*f),0,.18*math.sin(pi*f)),'head':(.18*math.sin(pi*f),0,0),'armL':(-1.1*math.sin(pi*f),0,0),'armR':(-.8*math.sin(pi*f),0,0),'legL':(.45*math.sin(pi*f),0,0),'legR':(-.45*math.sin(pi*f),0,0),'cape':(.8*math.sin(pi*f),0,0),'sword':(-1.28,0,0),'pony':(.4*math.sin(pi*f),0,0)}
            if mode=='Cast':return {'hips':(0,0,0),'spine':(-.08*math.sin(pi*f),0,0),'head':(-.11*math.sin(pi*f),0,0),'armL':(-2.2*math.sin(pi*f),0,-.4),'armR':(-1.9*math.sin(pi*f),0,.6),'legL':(0,0,0),'legR':(0,0,0),'cape':(.12+.16*math.sin(pi*f),0,0),'sword':(-.8,0,0),'pony':(.15*math.sin(pi*f),0,0)}
            if mode=='Hit':return {'hips':(0,0,.12*math.sin(pi*f)),'spine':(.45*math.sin(pi*f),0,.1*math.sin(pi*f)),'head':(-.28*math.sin(pi*f),0,0),'armL':(.25*math.sin(pi*f),0,0),'armR':(.35*math.sin(pi*f),0,0),'legL':(0,0,0),'legR':(0,0,0),'cape':(.12,0,0),'sword':(-1.24,0,0),'pony':(.15,0,0)}
            if mode=='Jump':return {'hips':(-.12,0,0),'spine':(-.12,0,0),'head':(.05,0,0),'armL':(-.56,0,0),'armR':(-.46,0,0),'legL':(.35,0,0),'legR':(.39,0,0),'cape':(.40,0,0),'sword':(-1.1,0,0),'pony':(.15,0,0)}
        nodes={'hips':hips,'spine':spine,'head':head,'armL':armL,'armR':armR,'legL':legL,'legR':legR,'cape':capeBone,'sword':sword,'pony':pony}
        return {node:{'rotation':lambda t,D,key=key:euler_q(*vals(t,D)[key])} for key,node in nodes.items()}
    for name,duration in [('Idle',2.2),('Run',.68),('Attack1',.38),('Attack2',.42),('Attack3',.49),('Dodge',.34),('Cast',.63),('Hit',.43),('Jump',.68)]:b.animate(name,duration,make_tracks(name),16 if name in ('Run','Idle') else 12)
    b.save(CHARS/(characterName.lower()+'.glb'))
    return b


def env_forest_gate():
    b=GLB('Moonforest Gate')
    stone=b.mat('limestone plinth','#FFFFFF',rough=.96,tex='stone');dark=b.mat('mossy masonry','#6B7A76');gold=b.mat('etched bronze','#C8AB79',metal=.55,rough=.38);light=b.mat('moonstone glass','#A1DBDD',metal=.14,rough=.24,emissive='#307D83')
    for s in (-1,1):
        x=s*2.7
        b.shape('fluted pillar '+str(s),b.root,'cylinder',stone,(x,2.55,0),(.53,5.1,.53))
        for y in (.28,4.73):b.shape('carved capital',b.root,'cylinder',gold,(x,y,0),(.75,.25,.75))
        b.shape('arched crystal finial',b.root,'sphere',light,(x,5.36,0),(.36,.59,.35))
    b.shape('lintel',b.root,'cube',stone,(0,5.23,0),(6.8,.82,1.12))
    b.shape('lintel-inlay',b.root,'cube',gold,(0,5.35,.59),(6.5,.13,.1))
    b.shape('central sigil',b.root,'torus',gold,(0,5.27,.73),(.53,.53,.53),euler_q(math.pi/2,0,0))
    b.shape('sigil gem',b.root,'sphere',light,(0,5.28,.82),(.20,.29,.11))
    b.save(ENV/'moonforest_gate.glb')


def env_inn():
    b=GLB('Star Lantern Inn')
    plaster=b.mat('old ivory plaster','#E6DCC5',rough=.95);wood=b.mat('oiled timber','#FFFFFF',rough=.85,tex='wood');roof=b.mat('painted shingle roof','#FFFFFF',rough=.91,tex='roof');gold=b.mat('roof trim','#D8B980',metal=.3,rough=.6);glass=b.mat('glass-pane','#7CCDD8',rough=.23,metal=.12,emissive='#296F78')
    b.shape('plaster_main',b.root,'cube',plaster,(0,2.65,0),(7.6,5.3,5.4))
    for y in (.15,2.3,4.95):
        for x in (-3.65,3.65):b.shape('timber upright',b.root,'cube',wood,(x,2.65,0),(.3,5.5,5.58))
        b.shape('timber border',b.root,'cube',wood,(0,y,2.72),(7.7,.22,.2))
    # two staggered gables with rotated rafters
    for s in (-1,1):
        b.shape('roof sloped plane',b.root,'cube',roof,(s*1.92,5.65,0),(4.48,.31,6.15),euler_q(0,0,s*-.40))
        b.shape('roof edge metal',b.root,'cube',gold,(s*3.66,4.80,0),(.20,.20,6.20))
    b.shape('front door',b.root,'cube',wood,(0,1.13,2.81),(1.55,2.25,.18))
    b.shape('door handle',b.root,'sphere',gold,(.53,1.18,2.98),(.08,.08,.08))
    for x in (-2.25,2.25):
        b.shape('pane',b.root,'cube',glass,(x,3.0,2.77),(1.20,1.34,.12))
        b.shape('window cross',b.root,'cube',wood,(x,3.0,2.85),(.105,1.6,.16))
        b.shape('window cross',b.root,'cube',wood,(x,3.0,2.85),(1.4,.1,.16))
        b.shape('window sill',b.root,'cube',wood,(x,2.2,2.82),(1.5,.15,.28))
    b.shape('inn sign',b.root,'cube',wood,(0,4.15,2.94),(2.2,.65,.16))
    b.shape('sign crest',b.root,'sphere',gold,(0,4.18,3.08),(.21,.23,.045))
    for s in (-1,1):b.shape('bracket',b.root,'cube',wood,(s*1.05,4.40,2.92),(.12,.65,.15))
    b.save(ENV/'star_lantern_inn.glb')


def env_tree():
    b=GLB('Ancient Silverleaf Tree')
    wood=b.mat('silverleaf bark','#FFFFFF',rough=.94,tex='wood');leaf=b.mat('silver green canopy','#FFFFFF',rough=.91,tex='leaf');pink=b.mat('blossom','#C99FAB',rough=.8);glow=b.mat('starseed','#9CE7EA',rough=.23,emissive='#3EA2AF')
    b.shape('root trunk',b.root,'cylinder',wood,(0,3.25,0),(1.0,6.5,1.0))
    for s in (-1,1):
        b.shape('bent limb',b.root,'cylinder',wood,(s*1.8,5.25,0),(.46,4.1,.46),euler_q(0,0,s*.70))
    clusters=[(-2.1,6.3,0,2.6),(2.2,6.8,0,2.8),(.0,8.1,-.3,3.15),(-1.25,7.55,-1.3,1.8),(1.3,7.5,1.0,1.8)]
    for i,(x,y,z,r) in enumerate(clusters):
        b.shape('sculpted_leaf_cluster',b.root,'sphere',leaf,(x,y,z),(r,r*.69,r*.88),detail='high')
        for j in range(7):
            a=j*math.pi*2/7;fx=x+math.cos(a)*r*.65;fz=z+math.sin(a)*r*.6
            b.shape('blossom',b.root,'sphere',pink,(fx,y-.3+.1*(j%3),fz),(.18,.22,.15))
    for a in range(16):
        x=math.cos(a*math.pi/8)*.85;z=math.sin(a*math.pi/8)*.85
        b.shape('lightning rune',b.root,'sphere',glow,(x,3.1+(a%5)*.3,z),(.065,.14,.065))
    b.save(ENV/'ancient_silverleaf.glb')

if __name__=='__main__':
    char(False);char(True);env_forest_gate();env_inn();env_tree()
    # asset authoring contract, machine-readable for app + future Blender replacement
    registry={'schema':1,'coordinateSystem':'glTF +Y up, front +Z','units':'meters',
              'characters':{'boy':'./models/characters/aster.glb','girl':'./models/characters/lyra.glb'},
              'charactersAnimations':['Idle','Run','Attack1','Attack2','Attack3','Dodge','Cast','Hit','Jump'],
              'environment':{'gate':'./models/environment/moonforest_gate.glb','inn':'./models/environment/star_lantern_inn.glb','tree':'./models/environment/ancient_silverleaf.glb'},
              'license':'Original assets created for this project; no third-party visual asset dependencies for GLB files.',
              'target':{'heroTriangleBudget':22000,'sceneActiveTriangleBudget':240000,'maxTexture':512,'iphoneTargetFPS':30}}
    (ROOT/'asset_manifest.json').write_text(json.dumps(registry,ensure_ascii=False,indent=2),encoding='utf8')
    print('Finished original asset build.')
