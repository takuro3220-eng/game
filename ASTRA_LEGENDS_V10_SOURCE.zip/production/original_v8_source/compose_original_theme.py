#!/usr/bin/env python3
"""Create original fantasy exploration loop. No third-party melodies or samples.
Contains a custom harmonic, arpeggio and countermelody sequence, additive synth.
"""
import numpy as np, math, subprocess, tempfile, pathlib, os
S=24000
BAR=60/88*4
TOTAL=16*BAR
N=int(TOTAL*S)
a=np.zeros(N,np.float32)
rs=np.random.default_rng(44978)

def freq(note):return 440*2**((note-69)/12)
def add(note,start,duration,amplitude=.1,kind='harp',pan=0):
    i=int(start*S);length=min(int(duration*S),N-i)
    if i<0 or length<=0:return
    t=np.arange(length,dtype=np.float32)/S
    f=freq(note)
    if kind=='harp':
        amp=(1-np.exp(-t*55))*np.exp(-t*3.1)*np.minimum(1,(duration-t)*9)
        wave=(np.sin(2*np.pi*f*t)+.24*np.sin(4*np.pi*f*t)+.12*np.sin(6*np.pi*f*t)+.07*np.sin(10*np.pi*f*t))
    elif kind=='pad':
        env=np.minimum(1,t/.45)*np.minimum(1,(duration-t)/1.5)
        amp=np.maximum(0,env)**1.1
        wave=.65*np.sin(2*np.pi*f*t)+.21*np.sin(2*np.pi*f*1.003*t)+.13*np.sin(2*np.pi*2*f*t)+.07*np.sin(2*np.pi*3*f*t)
    elif kind=='flute':
        env=np.minimum(1,t/.09)*np.minimum(1,(duration-t)/.28)
        amp=np.maximum(0,env)
        wave=np.sin(2*np.pi*f*t+0.002*np.sin(2*np.pi*4.4*t))+.11*np.sin(2*np.pi*2*f*t)
    elif kind=='bass':
        amp=(1-np.exp(-t*15))*np.exp(-t*.58)*np.minimum(1,(duration-t)*2)
        wave=.78*np.sin(2*np.pi*f*t)+.18*np.sin(2*np.pi*2*f*t)
    else: return
    a[i:i+length]+=wave.astype(np.float32)*amp.astype(np.float32)*amplitude
# D minor, Bb major, F, C then Gm, Dm, Bb, A; original ascending motifs
chords=[(50,[62,65,69]),(46,[58,62,65]),(53,[60,65,69]),(48,[60,64,67]),
        (43,[58,62,67]),(50,[62,65,69]),(46,[58,62,65]),(45,[57,61,64])]*2
# Melody composed in D minor pentatonic with some leading notes
melody=[(0,74,1.0),(1.1,72,.65),(2.25,69,1.1),(3.0,72,.5),
        (4.1,74,.75),(5,77,1.1),(6.5,76,.45),(7.3,74,1.1),
        (8,72,.65),(8.8,69,.52),(9.7,72,.53),(10.6,74,1.35),
        (12.0,76,.65),(12.8,74,.5),(13.4,72,.5),(14.1,69,1.3)]
for b,(root,triad) in enumerate(chords):
    st=b*BAR
    for chordnote in triad:
        add(chordnote-12,st,BAR*1.15,.045,'pad')
        add(chordnote,st,BAR*.95,.013,'pad')
    add(root-12,st,BAR*.95,.095,'bass')
    for k in range(8):
        off=k*BAR/8
        n=[triad[0],triad[1],triad[2],triad[1],triad[0]+12,triad[2],triad[1],triad[2]][k]
        add(n+12,st+off,.64,.030 if k%2 else .039,'harp')
for b,n,d in melody:
    # melody motifs across complete loop, one bar per index
    add(n,b*BAR,d*BAR*.7,.04,'flute')
# subtle spatial expanse; decorrelated breath and delays
noise=rs.normal(0,1,N).astype(np.float32)
# filtered pink-ish grain by integrating high speed noise, subtly mixed
kernel=np.ones(900,np.float32)/900
wind=np.convolve(noise[:N],kernel,mode='same')*.035
# avoid giant array overhead, simple reverb with micro echoes
for delay,amount in [(int(.22*S),.13),(int(.45*S),.08),(int(.91*S),.04)]:
    a[delay:]+=a[:-delay].copy()*amount
a+=wind
# fade loop edges, room for ending / restart
fade=min(int(.5*S),N//4)
a[:fade]*=np.linspace(0,1,fade).astype(np.float32)
a[-fade:]*=np.linspace(1,0,fade).astype(np.float32)
a=np.tanh(a*1.35).astype(np.float32)
peak=np.max(abs(a));a=a/max(peak,0.01)*.79
out=pathlib.Path(__file__).resolve().parents[1]/'audio'/'celestial_theme.m4a'
with tempfile.NamedTemporaryFile(suffix='.f32',delete=False) as temp:
    a.tofile(temp);raw=temp.name
try:
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','f32le','-ar',str(S),'-ac','1','-i',raw,'-c:a','aac','-b:a','112k','-movflags','+faststart',str(out)],check=True)
finally:os.unlink(raw)
print(f'Created {out}: {out.stat().st_size} bytes, {TOTAL:.1f} seconds (original melody)')
