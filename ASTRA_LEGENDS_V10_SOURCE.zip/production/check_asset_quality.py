#!/usr/bin/env python3
"""Asset gate: report an asset's actual technical properties; strict mode requires skinned heroes."""
from pathlib import Path
import argparse, json, struct, sys
PROJECT = Path(__file__).resolve().parents[1]
REQUIRED = {'Idle','Run','Attack1','Attack2','Attack3','Dodge','Cast','Hit','Jump'}

def glb_document(path: Path):
    data=path.read_bytes()
    if data[:4]!=b'glTF': raise ValueError(f'Bad GLB: {path}')
    version, total=struct.unpack_from('<II',data,4)
    if version != 2 or total != len(data): raise ValueError(f'Invalid GLB header: {path}')
    chunk_size, chunk_type=struct.unpack_from('<II',data,12)
    if chunk_type != 0x4E4F534A: raise ValueError('Missing JSON chunk')
    return json.loads(data[20:20+chunk_size])

def summary(path):
    doc=glb_document(path)
    names={a.get('name','') for a in doc.get('animations',[])}
    tri_count=0
    for mesh in doc.get('meshes',[]):
        for p in mesh.get('primitives',[]):
            accs=doc.get('accessors',[])
            idx=p.get('indices')
            if idx is not None: tri_count += int(accs[idx]['count'])//3
            elif 'POSITION' in p.get('attributes',{}): tri_count += int(accs[p['attributes']['POSITION']]['count'])//3
    return {'asset':str(path.relative_to(PROJECT)),'skins':len(doc.get('skins',[])),
            'morph_target_meshes':sum(bool(m.get('weights')) for m in doc.get('meshes',[])),
            'triangles':tri_count,'animations':sorted(names),'missing_clips':sorted(REQUIRED-names),
            'professional_skeletal_gate':bool(doc.get('skins')) and not REQUIRED-names}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--strict',action='store_true');a=ap.parse_args()
    results=[summary(PROJECT/'assets/models/characters'/f'{name}.glb') for name in ['aster','lyra']]
    print(json.dumps(results,ensure_ascii=False,indent=2))
    if a.strict and not all(r['professional_skeletal_gate'] for r in results):
        print('FAIL: current hero assets are hierarchy-animated, not skinned production heroes.',file=sys.stderr)
        sys.exit(1)
