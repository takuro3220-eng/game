# ASTRA LEGENDS Godot Rebirth v9 — QA status

## Checked in this environment

- Project root, Godot scene/main.gd, scripts, Web export preset and GitHub Pages CI workflow: generated.
- Six GDScript files checked by an **offline bracket/literal/reference check**. This is not a Godot parser or engine test.
- Source GLB Aster and Lyra: valid glTF 2.0; 9 expected clip names; no skins. Model gate correctly **fails for professional skinned hero requirement**.
- Source Fox glTF: actual skin present, 3 animation clips (`Survey`, `Walk`, `Run`).
- Audio OGG: FFmpeg conversion and file signature checked.
- Camera-relative stick calculation: 6 yaw samples × 2 intended directions verify movement on the correct screen axes. This does NOT verify real touch behavior on iPhone.
- Save JSON user:// path and basic inventory/quest logic implemented; complete gameplay path **not play-tested**.

## Not executable here / unverified

Godot 4.7.2 executable and export templates are unavailable in this environment, therefore we **did not run the Godot editor**, import engine scenes, export Web/IPA, test GPU rendering, measure FPS, or touch-test an iPhone. GitHub Actions build is included but has not been run.

## Product quality gate: NOT PASSED

Hero models are 7.3K/7.4K tris, hierarchy animated, no skin weights/morph targets, and cannot be described as Ys-grade professional assets. Environment assets and scripted world are a vertical slice only; no DQX-scale content. The project is an **actual engine migration / editable baseline**, not a completed commercial RPG.

## Next acceptance tests once Godot and iPhone build are available

1. Godot editor import and GDScript parser pass with zero errors.
2. Run scene `scenes/main.tscn`, walk through geometry collision and camera sweeps.
3. Test left-stick upper/lower/left/right under 0°, 90°, 180°, 270° yaw using real touch.
4. Attack range, combo, hurt immunity on dodge, XP and reward are correct.
5. Chapter flow Elder → 3 wolves → relic → boss → Elder with out-of-order pickup recovery.
6. HUD readability at 852×393 and 932×430 landscape-safe viewports.
7. Safari PWA export from CI, reload persistence, device GPU/thermal profile.
8. Native iOS export through Mac/Xcode, code signing, TestFlight install.
