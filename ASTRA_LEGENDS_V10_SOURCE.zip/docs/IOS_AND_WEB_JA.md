# iPhoneへの公開・アプリ化

## 現在の状況

本ZIPは Godot 4.7.2 の**ソースプロジェクト**です。iPhoneにそのままインストールできる .ipa、Netlifyに直接アップロードできるHTMLビルドではありません。Godotの実行ファイル・Webエクスポートテンプレート・Mac/Xcodeは本ZIPに含めていません。

## A. iPhoneからブラウザで遊べるようにする（Webビルド）

1. Mac / Windows / Linux で Godot 4.7.2 の編集環境を開き、`project.godot` を選択します。
2. 3Dアセットのインポート完了後、F6/F5で起動し、まずPCで移動・戦闘・クエストを確認します。
3. Editor → Manage Export Templates から 4.7.2 の公式テンプレートを導入します。
4. Project → Export → Web （プリセット同梱）から `build/web/index.html` を生成します。
5. **生成された `build/web/` の中身**を Netlify または GitHub Pages に置きます。ソースZIPをそのままNetlify Dropに置いてもゲームとしては動きません。
6. SafariでHTTPS公開URLにアクセスし、共有 → ホーム画面に追加 → Webアプリとして開く を選びます。PWA全画面＋横画面を想定しています。

## B. iPhoneだけを使っている場合：GitHub ActionsによるWebビルド案

`.github/workflows/web-preview.yml` を同梱しています。対応するGitHubリポジトリの `main` にプロジェクト一式をアップロードし、設定の Pages → Build and deployment → GitHub Actions を選ぶと、CIがGodotをインストールしてWebビルド・公開を行う構成です。

GitHubアカウント、リポジトリ作成、ファイルアップロード、Pages設定の操作が必要です。**ワークフローは未実行・未検証**で、必ず初回ビルドログを確認してください。ユーザーのアカウントをこちらで勝手に作成・公開するものではありません。

## C. iOSネイティブアプリ（.ipa）

Godot 4.7.2のエクスポートテンプレート、**macOS + Xcode**、署名用Team ID、Bundle IDと適切なApple開発者設定が必要です。Godot公式ドキュメントに従いProject → Export → iOSを追加、Xcodeプロジェクトを書き出して署名・ビルドします。iPhone単体でXcodeビルドすることはできません。

参考：https://docs.godotengine.org/en/latest/tutorials/export/exporting_for_ios.html

## 推奨実機QA

- 横持ち左右両方向でスティック上→画面奥・右→画面右
- マルチタッチ：左スティック＋右カメラ＋攻撃
- 30/60fpsターゲットに対するフレームタイム、発熱、端末メモリ
- 攻撃コンボ・回避・魔法の効果・敵HP・死亡・復活
- NPC会話→狼3体→遺跡宝箱→ボス→長老の第1章完了
- App起動終了・保存復元とサイト再公開時の保存維持

この環境ではGodotエンジン本体が利用できず、ビルド・WebGL実機動作は確認できていません。
