# ASTRA LEGENDS v10 — リリース手順・完了条件

## 完了している作業
- Godot 4.7.2向けゲームプロジェクト：村／森林／湖／遺跡、3D移動・タッチ操作・戦闘・NPC・第一章クエスト・保存処理のソース。
- モバイル描画の軽量化：森林をMultimeshでまとめて描画。
- 視認性：敵の攻撃範囲を予告する表示を追加。
- 保存データの範囲チェック、ボスの重複生成防止。
- Godot実機実行を前提とした起動・移動スモークテスト（**テストコードのみ。未実行**）。
- GitHub Actions Webエクスポート / GitHub Pages 公開のワークフロー。
- macOS GitHub Actionsで**署名前のXcodeプロジェクト**を生成するワークフロー。

## 未完了（配信できたと表記しない）
- GodotエンジンによるGDScriptの実際のコンパイル・シーン起動・Webエクスポート。
- iPhoneのSafari/PWAにおけるフレームレート・操作・保存確認。
- Appleの署名、.ipa作成、TestFlight、App Store審査と公開。
- 『イース』『ドラゴンクエストX』と同等の商用アセット、ストーリーの物量、専門家による一貫したレベルデザイン。

## iPhoneだけでWebプレビューを公開する方法（GitHub Pages）

すでに接続されているGitHubアカウントにはリポジトリがありません。このため、この場では**公開URLを発行できていません**。

1. iPhoneのSafariで https://github.com/new を開き、新しいリポジトリを作成。
2. このソースZIPをiPhoneの「ファイル」で解凍し、プロジェクトの中身をリポジトリ直下にアップロード（`project.godot`, `scripts`, `scenes`, `assets`, `.github`等）。iPhoneブラウザでフォルダ一括選択ができない場合、下記の一括ZIPアップロード方式を使う。
3. GitHubリポジトリの **Settings → Pages → Build and deployment → Source = GitHub Actions** を設定。
4. **Actions → Godot 4.7.2 | tests + iPhone web preview → Run workflow** を実行。
5. 実行結果が成功しPages URLが発行されたら、Safariで開いてホーム画面に追加。

この操作で初めてWebビルド・公開・端末テストに進めます。GitHub Pagesの設定と署名はGitHub/Appleアカウントの権限が必要です。

### iPhoneでソースをまとめてアップロードする場合
GitHubへ`ASTRA_LEGENDS_V10_SOURCE.zip`を**1ファイルだけ**アップロードし、別添`github-pages-from-zip.yml`をGitHubの「Create new file」で`.github/workflows/build.yml`として保存します。このワークフローはZIPをCI内で展開し、Godotの実行テスト・Webビルド・Pages配信を試みます。ファイル名が一致しないと失敗します。

## iOSネイティブ：TestFlightへの経路

1. Apple Developer Programに加入し、App Store Connectで一意のBundle IDを確保する。
2. GitHubのActions画面で`Godot 4.7.2 | unsigned iOS Xcode project`を手動起動。Apple Team ID（10文字）とBundle IDを入力。
3. macOS GitHub ActionsがGodotで**Xcodeプロジェクト（未署名）**を生成できた場合、artifactを取得。
4. macOS / Xcode環境でApple Distribution証明書・Provisioning Profileを使って署名し、.ipaまたはアーカイブを作成。
5. App Store Connectにアップロード、TestFlightへ提出。外部テスターへの公開にはAppleの審査が必要になる場合があります。
6. 実機でゲームをテストし、クラッシュ・操作・長時間プレイ・課金・プライバシー等を検証してからApp Store審査へ。

**留意**：GitHub ActionsのmacOSランナーはMacを所有せずにXcode処理を行う選択肢ですが、現状の同梱ワークフローはXcodeプロジェクト生成までで、Apple署名・TestFlightアップロードは自動化していません。

## 商用製品品質の品質ゲート

**現在の判定：不合格**。主人公GLB2体の`skeleton/skin`数が0であり、表情morphもありません。手作業アセット・モーション・音響の再制作、以下の合格が必須です。

- 骨格スキニングと実機で破綻しない関節変形、待機・走行・攻撃・回避・魔法の自然な遷移
- オリジナルキャラクターの表情・髪・衣装・装備・演出を統一したアートディレクション
- 戦闘の入力遅延、被弾リアクション、アクションキャンセル、公平な敵予兆、敵行動の多様性
- 地形・建物・植生のLOD／GPUメモリ管理、ロード最適化
- iPhone実機での長時間安定動作、発熱・バッテリー負荷・30/60fps測定
- 第一章以上のストーリー・敵・ダンジョン、QA通しプレイ、データ保存とリカバリ

素材の権利は`ASSET_LICENSES.md`に記載。第三者作品のモデル・ロゴ・音楽はコピーしない。
