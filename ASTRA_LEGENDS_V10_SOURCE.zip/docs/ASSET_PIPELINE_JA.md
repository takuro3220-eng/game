# 制作工程とアニメーション差し替え契約

## v8から実際に移行した素材

- `assets/models/characters/aster.glb` と `lyra.glb`：ゲームオリジナルのスタイライズ人物モデル。各9個のアニメーションクリップを同梱。
- `assets/models/creatures/fox_ccby4.gltf`：Khronos glTF Sample Models / Fox。**骨格付き**、`Survey`・`Walk`・`Run`、CC BY 4.0。`ASSET_LICENSES.md` 参照。
- `assets/models/environment/*.glb`：宿屋・森の門・樹木の独立GLB。
- `assets/audio/celestial_theme.ogg`：v8のオリジナル音楽をGodot用に変換したもの。
- `assets/textures/*.png`：v8のオリジナルテクスチャ。

## 重要：現在の主人公は「プロ仕様のスキニングモデル」ではない

既存の主人公GLBは**階層ノードのアニメーション（skin=0）**です。自然な関節変形、表情ブレンドシェイプ、布・髪の物理表現は未対応です。これを商用ゲーム品質と称することはできません。

## 次に制作・導入するプロ向けアセットの受入条件

| アセット | 受入条件 | 現状 |
|---|---|---|
| 主人公 | 20〜40k triangles/LOD0 を上限目安、統一PBR、Skeleton3D、面/指ボーン、表情BlendShapes、LOD1〜2 | 未達 |
| アニメ | Idle/Run/Attack1〜3/Dodge/Cast/Hit/Jump、foot contact調整、ブレンド・遷移 | clip名9種類は有、品質未達 |
| 敵 | 骨格スキニング、Idle/Walk/Attack/Hit/Death、戦闘当たり判定 | Foxはスキニング有、戦闘モーション未達 |
| 建築 | GLB/GLTF、PBRマテリアル、LOD、衝突メッシュ、日照調整 | 独立GLB、一部補助コリジョン有 |
| 世界 | 地形ストリーミング、LOD、HLOD、焼き込み照明、植生GPUインスタンシング | 一部未達 |

## Godotへの取込み手順

1. Blenderなどで GLB 形式へエクスポート。スケール1 unit ≈ 1m、前方向はゲーム側の -Z に揃える。
2. Heroは `assets/models/characters/aster.glb` 又は `lyra.glb` に新規モデルを置換。
3. 名前が一致する9アニメーションを AnimationPlayer にインポートし、`scripts/player.gd` の `_anim_name` が検出できるか確認。
4. 身長はモデルスケールとカプセルコリジョンを同期調整。現在の簡易モデルは高さ約3mで、表示スケールを0.77にしている。
5. 本番モデルのスキニング/表情は GodotのAnimationTree やSkeleton3Dを用いて別途調整し、iPhoneの実機負荷と破綻を検証。
6. 変更が商用利用可能であることを必ず確認し、ライセンス・原作者表示・改変履歴を維持。

## パフォーマンスと品質計測

実機のMSAA/シャドウ/テクスチャ容量とフレーム時間を計測し、30fps維持に収まるようにLOD・テクスチャ圧縮・可視範囲を調整。3Dループの処理負荷をiPhoneでプロファイルしていない段階で「最適化完了」と宣言しない。
